// Seeds one demo customer with a delivered order + review so the reviews
// flow and admin panels have realistic sample data out of the box.
import "dotenv/config";
import pg from "pg";

const { Pool } = pg;
const pool = new Pool({ connectionString: process.env.DATABASE_URL });

async function main() {
  const client = await pool.connect();
  try {
    const userRes = await client.query(
      `INSERT INTO users (name, email, auth_provider, email_verified)
       VALUES ('Ananya Sharma', 'ananya.demo@example.com', 'email', true)
       ON CONFLICT (email) DO UPDATE SET name = EXCLUDED.name RETURNING id`
    );
    const userId = userRes.rows[0].id;

    const addrRes = await client.query(
      `SELECT id FROM addresses WHERE user_id = $1 LIMIT 1`,
      [userId]
    );
    let addressId = addrRes.rows[0]?.id;
    if (!addressId) {
      const newAddr = await client.query(
        `INSERT INTO addresses (user_id, label, full_name, phone, line1, line2, city, state, pincode, is_default)
         VALUES ($1,'Home','Ananya Sharma','9876543210','221 MG Road','Near City Mall','Bengaluru','Karnataka','560001', true) RETURNING id`,
        [userId]
      );
      addressId = newAddr.rows[0].id;
    }
    const address = await client.query(`SELECT * FROM addresses WHERE id = $1`, [addressId]);
    const a = address.rows[0];

    const products = await client.query(
      `SELECT p.id, p.name, p.price, pi.url as image, pv.id as variant_id, pv.size, pv.color
       FROM products p
       JOIN product_images pi ON pi.product_id = p.id AND pi.position = 0
       JOIN product_variants pv ON pv.product_id = p.id
       ORDER BY p.id LIMIT 2`
    );

    const existingOrder = await client.query(`SELECT id FROM orders WHERE user_id = $1 LIMIT 1`, [userId]);
    let orderId = existingOrder.rows[0]?.id;
    if (!orderId) {
      const subtotal = products.rows.reduce((s, p) => s + parseFloat(p.price), 0);
      const orderRes = await client.query(
        `INSERT INTO orders (order_number, user_id, status, payment_method, payment_status, subtotal, discount, delivery_fee, total, address, created_at)
         VALUES ($1,$2,'Delivered','COD','Pending',$3,0,0,$3,$4, NOW() - interval '6 days') RETURNING id`,
        [
          "VHDEMO1001",
          userId,
          subtotal.toFixed(2),
          JSON.stringify({ fullName: a.full_name, phone: a.phone, line1: a.line1, line2: a.line2, city: a.city, state: a.state, pincode: a.pincode }),
        ]
      );
      orderId = orderRes.rows[0].id;

      for (const p of products.rows) {
        await client.query(
          `INSERT INTO order_items (order_id, product_id, name, image, price, quantity, size, color)
           VALUES ($1,$2,$3,$4,$5,1,$6,$7)`,
          [orderId, p.id, p.name, p.image, p.price, p.size, p.color]
        );
      }
      for (const status of ["Placed", "Confirmed", "Shipped", "Out for delivery", "Delivered"]) {
        await client.query(`INSERT INTO order_status_history (order_id, status, note) VALUES ($1,$2,$3)`, [orderId, status, `Order ${status.toLowerCase()}.`]);
      }
      console.log(`Created demo delivered order #${orderId} for ananya.demo@example.com`);
    }

    if (products.rows[0]) {
      const p = products.rows[0];
      const reviewExists = await client.query(`SELECT id FROM reviews WHERE user_id = $1 AND product_id = $2`, [userId, p.id]);
      if (!reviewExists.rows.length) {
        await client.query(
          `INSERT INTO reviews (product_id, user_id, order_id, rating, title, body)
           VALUES ($1,$2,$3,5,'Great quality for the price','The fabric feels premium and the fit is true to size. Would definitely recommend and order again.')`,
          [p.id, userId, orderId]
        );
        await client.query(
          `UPDATE products SET rating_avg = 5, rating_count = 1 WHERE id = $1`,
          [p.id]
        );
        console.log(`Added a 5-star demo review on "${p.name}".`);
      }
    }

    console.log("Demo order + review seeding complete.");
  } finally {
    client.release();
    await pool.end();
  }
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
