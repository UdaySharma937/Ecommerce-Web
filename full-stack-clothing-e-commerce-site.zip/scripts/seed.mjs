// Seed script for Vastrahaus.
// Run with: node scripts/seed.mjs
// Populates categories, products (with images & variants), a default admin
// account, starter coupons and homepage banners.

import "dotenv/config";
import pg from "pg";
import bcrypt from "bcryptjs";

const { Pool } = pg;
const pool = new Pool({ connectionString: process.env.DATABASE_URL });

function slugify(text) {
  return text
    .toString()
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/(^-|-$)+/g, "");
}

const MEN_IMG = [
  "https://images.pexels.com/photos/16777497/pexels-photo-16777497.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800",
  "https://images.pexels.com/photos/23696193/pexels-photo-23696193.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800",
  "https://images.pexels.com/photos/26984682/pexels-photo-26984682.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800",
  "https://images.pexels.com/photos/27798776/pexels-photo-27798776.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800",
  "https://images.pexels.com/photos/28113612/pexels-photo-28113612.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800",
  "https://images.pexels.com/photos/28050779/pexels-photo-28050779.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800",
];
const SAREE_IMG = [
  "https://images.pexels.com/photos/28316406/pexels-photo-28316406.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800",
  "https://images.pexels.com/photos/8891974/pexels-photo-8891974.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800",
  "https://images.pexels.com/photos/20957555/pexels-photo-20957555.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800",
  "https://images.pexels.com/photos/28316410/pexels-photo-28316410.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800",
  "https://images.pexels.com/photos/34964322/pexels-photo-34964322.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800",
  "https://images.pexels.com/photos/27719401/pexels-photo-27719401.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800",
];
const SHIRT_IMG = [
  "https://images.pexels.com/photos/19852754/pexels-photo-19852754.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800",
  "https://images.pexels.com/photos/2421356/pexels-photo-2421356.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800",
  "https://images.pexels.com/photos/17960004/pexels-photo-17960004.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800",
  "https://images.pexels.com/photos/38876519/pexels-photo-38876519.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800",
  "https://images.pexels.com/photos/17901274/pexels-photo-17901274.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800",
  "https://images.pexels.com/photos/31618286/pexels-photo-31618286.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800",
];
const DRESS_IMG = [
  "https://images.pexels.com/photos/38959988/pexels-photo-38959988.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800",
  "https://images.pexels.com/photos/35761000/pexels-photo-35761000.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800",
  "https://images.pexels.com/photos/39296285/pexels-photo-39296285.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800",
  "https://images.pexels.com/photos/39168902/pexels-photo-39168902.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800",
  "https://images.pexels.com/photos/27580017/pexels-photo-27580017.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800",
  "https://images.pexels.com/photos/27288209/pexels-photo-27288209.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800",
];
const KIDS_IMG = [
  "https://images.pexels.com/photos/38778561/pexels-photo-38778561.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800",
  "https://images.pexels.com/photos/19664810/pexels-photo-19664810.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800",
  "https://images.pexels.com/photos/18545044/pexels-photo-18545044.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800",
  "https://images.pexels.com/photos/5560013/pexels-photo-5560013.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800",
];
const WINTER_IMG = [
  "https://images.pexels.com/photos/6468624/pexels-photo-6468624.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800",
  "https://images.pexels.com/photos/33772484/pexels-photo-33772484.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800",
  "https://images.pexels.com/photos/19441381/pexels-photo-19441381.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800",
  "https://images.pexels.com/photos/36055181/pexels-photo-36055181.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800",
];

const BANNER_IMG = [
  "https://images.pexels.com/photos/33276443/pexels-photo-33276443.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
  "https://images.pexels.com/photos/5698851/pexels-photo-5698851.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
  "https://images.pexels.com/photos/38218759/pexels-photo-38218759.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
];

const CATEGORIES = [
  { name: "Men", icon: "👔" },
  { name: "Women", icon: "👗" },
  { name: "Kids", icon: "🧒" },
  { name: "Ethnic", icon: "🥻" },
  { name: "Winter Wear", icon: "🧥" },
  { name: "Footwear", icon: "👟" },
];

const COLOR_HEX = {
  Black: "#1c1c1c", White: "#f5f5f0", Blue: "#3b5a9a", "Navy": "#1f2a44",
  Red: "#b23b3b", Maroon: "#6e2238", Green: "#3f7a4f", Beige: "#d8c7a8",
  Yellow: "#dcb441", Mustard: "#c99a2e", Pink: "#d98fa3", Grey: "#8a8a85",
  Olive: "#5c5a32", Rust: "#a4532f", Teal: "#2b6e6e", Peach: "#e8b89b",
};

function variants(sizes, colors, stockBase = 18) {
  const out = [];
  for (const s of sizes) {
    for (const c of colors) {
      out.push({ size: s, color: c, colorHex: COLOR_HEX[c] || "#999999", stock: Math.max(0, stockBase - Math.floor(Math.random() * 12)) });
    }
  }
  return out;
}

const ADULT_SIZES = ["S", "M", "L", "XL", "XXL"];
const KIDS_SIZES = ["2-3Y", "4-5Y", "6-7Y", "8-9Y"];

const PRODUCTS = [
  // Men
  { cat: "Men", name: "Men's Pure Cotton Mandarin Kurta", brand: "Vastrahaus", price: 1099, mrp: 1899, desc: "Breathable pure cotton kurta with a mandarin collar and side slits, perfect for festive evenings and everyday comfort.", tags: "kurta,men,cotton,festive", images: [MEN_IMG[0], MEN_IMG[2]], variants: variants(ADULT_SIZES, ["White", "Mustard"]), featured: true },
  { cat: "Men", name: "Men's Chikankari Embroidered Kurta", brand: "Rang Mahal", price: 1799, mrp: 2999, desc: "Hand-embroidered chikankari work on soft georgette fabric, a timeless piece for weddings and festive occasions.", tags: "kurta,men,wedding,ethnic", images: [MEN_IMG[1], MEN_IMG[4]], variants: variants(ADULT_SIZES, ["White", "Beige"]), trending: true },
  { cat: "Men", name: "Men's Slim Fit Checked Casual Shirt", brand: "Urban Thread", price: 899, mrp: 1499, desc: "Slim-fit cotton-blend shirt with a classic checked pattern, tailored for an everyday smart-casual look.", tags: "shirt,men,casual,office", images: [SHIRT_IMG[0], SHIRT_IMG[2]], variants: variants(ADULT_SIZES, ["Blue", "Olive"]) },
  { cat: "Men", name: "Men's Linen Blend Short Sleeve Shirt", brand: "Urban Thread", price: 1199, mrp: 1799, desc: "Lightweight linen-blend shirt that keeps you cool through long summer days without compromising on style.", tags: "shirt,men,linen,summer", images: [SHIRT_IMG[3], SHIRT_IMG[5]], variants: variants(ADULT_SIZES, ["White", "Beige"]), isNew: true },
  { cat: "Men", name: "Men's Classic Straight Fit Denim Jeans", brand: "Urban Thread", price: 1399, mrp: 2199, desc: "Mid-rise straight fit jeans crafted from durable stretch denim for all-day comfort.", tags: "jeans,men,denim,casual", images: [MEN_IMG[5], SHIRT_IMG[1]], variants: variants(ADULT_SIZES, ["Blue", "Black"]) },
  { cat: "Men", name: "Men's Printed Festive Nehru Jacket", brand: "Rang Mahal", price: 1599, mrp: 2599, desc: "A structured Nehru jacket with subtle jacquard print, perfect for layering over kurtas at festive gatherings.", tags: "jacket,men,festive,ethnic", images: [MEN_IMG[3], MEN_IMG[0]], variants: variants(ADULT_SIZES, ["Maroon", "Navy"]), trending: true },
  // Women
  { cat: "Women", name: "Women's Banarasi Silk Saree", brand: "Rang Mahal", price: 2899, mrp: 4999, desc: "Woven on traditional looms, this Banarasi silk saree features a rich zari border and comes with an unstitched blouse piece.", tags: "saree,women,silk,wedding", images: [SAREE_IMG[0], SAREE_IMG[3]], variants: variants(["Free Size"], ["Red", "Maroon"], 12), featured: true },
  { cat: "Women", name: "Women's Chiffon Printed Saree", brand: "Studio Noor", price: 1299, mrp: 2199, desc: "Lightweight chiffon saree with a floral print, finished with a delicate lace border for everyday elegance.", tags: "saree,women,chiffon,office", images: [SAREE_IMG[2], SAREE_IMG[4]], variants: variants(["Free Size"], ["Pink", "Teal"], 15) },
  { cat: "Women", name: "Women's A-Line Floral Midi Dress", brand: "Studio Noor", price: 1499, mrp: 2499, desc: "A flattering A-line midi dress in breathable rayon with an all-over floral print, great for brunch dates.", tags: "dress,women,floral,casual", images: [DRESS_IMG[2], DRESS_IMG[4]], variants: variants(["XS", "S", "M", "L", "XL"], ["Peach", "Teal"]), isNew: true },
  { cat: "Women", name: "Women's Bodycon Party Dress", brand: "Studio Noor", price: 1699, mrp: 2999, desc: "A figure-hugging bodycon dress in stretch fabric, designed to turn heads at your next evening out.", tags: "dress,women,party,evening", images: [DRESS_IMG[0], DRESS_IMG[5]], variants: variants(["XS", "S", "M", "L"], ["Black", "Red"]), trending: true },
  { cat: "Women", name: "Women's Anarkali Embroidered Kurta Set", brand: "Rang Mahal", price: 2199, mrp: 3799, desc: "Floor-length Anarkali kurta with thread embroidery, paired with matching churidar and dupatta.", tags: "kurta,women,ethnic,wedding", images: [SAREE_IMG[5], DRESS_IMG[1]], variants: variants(ADULT_SIZES, ["Mustard", "Teal"]), featured: true },
  { cat: "Women", name: "Women's High-Waist Palazzo Pants", brand: "Urban Thread", price: 799, mrp: 1299, desc: "Flowy high-waist palazzo pants in soft crepe fabric that pair effortlessly with kurtis and crop tops.", tags: "palazzo,women,casual,ethnic", images: [DRESS_IMG[3], SAREE_IMG[1]], variants: variants(["S", "M", "L", "XL"], ["Black", "Beige"]) },
  // Kids
  { cat: "Kids", name: "Kids' Printed Cotton T-Shirt (Pack of 2)", brand: "Little Vastra", price: 599, mrp: 999, desc: "Soft, breathable cotton t-shirts with playful prints — a pack of two in coordinated colours.", tags: "kids,tshirt,cotton,boys", images: [KIDS_IMG[0], KIDS_IMG[1]], variants: variants(KIDS_SIZES, ["Blue", "Yellow"], 20), isNew: true },
  { cat: "Kids", name: "Kids' Denim Dungaree Set", brand: "Little Vastra", price: 899, mrp: 1499, desc: "An adorable denim dungaree with a printed inner tee, built for everyday play and comfort.", tags: "kids,dungaree,denim,girls", images: [KIDS_IMG[3], KIDS_IMG[2]], variants: variants(KIDS_SIZES, ["Blue", "Grey"], 15) },
  { cat: "Kids", name: "Kids' Festive Kurta Pyjama Set", brand: "Rang Mahal", price: 999, mrp: 1699, desc: "A mini version of our adult kurta sets, finished with delicate embroidery for festive family photos.", tags: "kids,kurta,festive,ethnic", images: [KIDS_IMG[1], KIDS_IMG[0]], variants: variants(KIDS_SIZES, ["Mustard", "White"], 14), trending: true },
  // Ethnic
  { cat: "Ethnic", name: "Women's Rajasthani Bandhani Dupatta Suit", brand: "Rang Mahal", price: 1899, mrp: 3199, desc: "A vibrant bandhani-print suit set with matching dupatta, handcrafted by artisans from Rajasthan.", tags: "ethnic,women,bandhani,suit", images: [SAREE_IMG[1], DRESS_IMG[2]], variants: variants(ADULT_SIZES, ["Pink", "Yellow"], 14) },
  { cat: "Ethnic", name: "Men's Silk Blend Wedding Sherwani", brand: "Rang Mahal", price: 4499, mrp: 7999, desc: "A regal silk-blend sherwani with intricate zari embroidery, tailored for the groom's big day.", tags: "ethnic,men,sherwani,wedding", images: [MEN_IMG[4], MEN_IMG[2]], variants: variants(ADULT_SIZES, ["Maroon", "Navy"], 8), featured: true },
  { cat: "Ethnic", name: "Women's Georgette Lehenga Choli", brand: "Rang Mahal", price: 3299, mrp: 5999, desc: "A flared georgette lehenga with sequin embroidery and a matching choli and dupatta, perfect for sangeet nights.", tags: "ethnic,women,lehenga,wedding", images: [SAREE_IMG[4], DRESS_IMG[1]], variants: variants(["S", "M", "L", "XL"], ["Teal", "Pink"], 10), trending: true },
  { cat: "Ethnic", name: "Men's Cotton Silk Nehru Collar Kurta", brand: "Vastrahaus", price: 1299, mrp: 2199, desc: "A cotton-silk blend kurta with a sharp Nehru collar, offering a rich look with everyday comfort.", tags: "ethnic,men,kurta,festive", images: [MEN_IMG[0], MEN_IMG[3]], variants: variants(ADULT_SIZES, ["Olive", "Rust"]) },
  // Winter Wear
  { cat: "Winter Wear", name: "Women's Quilted Puffer Jacket", brand: "Urban Thread", price: 2199, mrp: 3499, desc: "A lightweight quilted puffer jacket with a water-resistant shell, built to handle North Indian winters.", tags: "winter,jacket,women,puffer", images: [WINTER_IMG[0], WINTER_IMG[2]], variants: variants(["S", "M", "L", "XL"], ["Black", "Maroon"]), featured: true },
  { cat: "Winter Wear", name: "Men's Wool Blend Overcoat", brand: "Urban Thread", price: 2899, mrp: 4499, desc: "A tailored wool-blend overcoat with a clean silhouette, ideal for layering over formalwear in winter.", tags: "winter,coat,men,wool", images: [WINTER_IMG[3], MEN_IMG[5]], variants: variants(ADULT_SIZES, ["Grey", "Navy"], 10) },
  { cat: "Winter Wear", name: "Unisex Cable Knit Pullover Sweater", brand: "Vastrahaus", price: 1299, mrp: 1999, desc: "A classic cable-knit pullover in soft acrylic-wool blend, warm enough for chilly mornings.", tags: "winter,sweater,unisex,knit", images: [WINTER_IMG[1], WINTER_IMG[2]], variants: variants(ADULT_SIZES, ["Beige", "Grey"]), isNew: true },
  { cat: "Winter Wear", name: "Women's Faux Fur Hooded Coat", brand: "Studio Noor", price: 2599, mrp: 4299, desc: "A statement faux-fur hooded coat that combines warmth with an elevated winter wardrobe look.", tags: "winter,coat,women,fur", images: [WINTER_IMG[0], WINTER_IMG[2]], variants: variants(["S", "M", "L"], ["Black", "Beige"], 9), trending: true },
  // Footwear
  { cat: "Footwear", name: "Men's Classic Leather Loafers", brand: "Vastrahaus", price: 1799, mrp: 2799, desc: "Genuine leather loafers with a cushioned footbed, equally at home in the office or at a dinner out.", tags: "footwear,men,loafers,leather", images: [SHIRT_IMG[2], MEN_IMG[1]], variants: variants(["6", "7", "8", "9", "10"], ["Black", "Brown"], 12) },
  { cat: "Footwear", name: "Women's Embellished Ethnic Juttis", brand: "Rang Mahal", price: 999, mrp: 1599, desc: "Hand-embellished juttis with cushioned soles, designed to complement your festive and ethnic outfits.", tags: "footwear,women,juttis,ethnic", images: [SAREE_IMG[3], DRESS_IMG[0]], variants: variants(["5", "6", "7", "8"], ["Gold", "Pink"], 12), isNew: true },
  { cat: "Footwear", name: "Unisex Canvas Sneakers", brand: "Urban Thread", price: 1099, mrp: 1799, desc: "Everyday canvas sneakers with a cushioned sole, built for comfort whether you're commuting or running errands.", tags: "footwear,unisex,sneakers,casual", images: [SHIRT_IMG[4], MEN_IMG[5]], variants: variants(["6", "7", "8", "9", "10"], ["White", "Black"], 16) },
];

async function main() {
  const client = await pool.connect();
  try {
    console.log("Seeding Vastrahaus database...");

    // ----- Admin -----
    const adminEmail = "admin@vastrahaus.in";
    const adminPasswordHash = await bcrypt.hash("Admin@123", 10);
    await client.query(
      `INSERT INTO admins (name, email, password_hash) VALUES ($1,$2,$3)
       ON CONFLICT (email) DO NOTHING`,
      ["Store Admin", adminEmail, adminPasswordHash]
    );
    console.log(`Admin ready -> ${adminEmail} / Admin@123`);

    // ----- Categories -----
    const categoryIds = {};
    for (let i = 0; i < CATEGORIES.length; i++) {
      const c = CATEGORIES[i];
      const slug = slugify(c.name);
      const res = await client.query(
        `INSERT INTO categories (name, slug, icon, position) VALUES ($1,$2,$3,$4)
         ON CONFLICT (slug) DO UPDATE SET name = EXCLUDED.name RETURNING id`,
        [c.name, slug, c.icon, i]
      );
      categoryIds[c.name] = res.rows[0].id;
    }
    console.log(`Seeded ${CATEGORIES.length} categories.`);

    // ----- Products -----
    let count = 0;
    for (const p of PRODUCTS) {
      const baseSlug = slugify(p.name);
      const existing = await client.query(`SELECT id FROM products WHERE slug = $1`, [baseSlug]);
      if (existing.rows.length) continue; // already seeded

      const prodRes = await client.query(
        `INSERT INTO products (name, slug, category_id, brand, description, price, mrp, tags, is_featured, is_trending, is_active, created_at)
         VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,true, NOW() - ($11 || ' days')::interval)
         RETURNING id`,
        [
          p.name,
          baseSlug,
          categoryIds[p.cat],
          p.brand,
          p.desc,
          p.price,
          p.mrp,
          p.tags,
          !!p.featured,
          !!p.trending,
          p.isNew ? 1 : Math.floor(Math.random() * 60) + 5,
        ]
      );
      const productId = prodRes.rows[0].id;

      for (let i = 0; i < p.images.length; i++) {
        await client.query(`INSERT INTO product_images (product_id, url, position) VALUES ($1,$2,$3)`, [productId, p.images[i], i]);
      }
      for (const v of p.variants) {
        const sku = `${baseSlug}-${v.size}-${v.color}`.toUpperCase().replace(/\s+/g, "");
        await client.query(
          `INSERT INTO product_variants (product_id, size, color, color_hex, stock, sku) VALUES ($1,$2,$3,$4,$5,$6)`,
          [productId, v.size, v.color, v.colorHex, v.stock, sku]
        );
      }
      count++;
    }
    console.log(`Seeded ${count} new products (skipped already-seeded ones).`);

    // ----- Coupons -----
    const coupons = [
      { code: "WELCOME100", type: "flat", value: 100, min: 999, limit: 500 },
      { code: "FEST20", type: "percent", value: 20, min: 1499, max: 600, limit: 300 },
      { code: "FREESHIP", type: "flat", value: 49, min: 499, limit: 1000 },
    ];
    for (const c of coupons) {
      await client.query(
        `INSERT INTO coupons (code, type, value, min_order_value, max_discount, usage_limit)
         VALUES ($1,$2,$3,$4,$5,$6) ON CONFLICT (code) DO NOTHING`,
        [c.code, c.type, c.value, c.min, c.max || null, c.limit]
      );
    }
    console.log("Seeded starter coupons: WELCOME100, FEST20, FREESHIP.");

    // ----- Banners -----
    const existingBanners = await client.query(`SELECT COUNT(*)::int as count FROM banners`);
    if (existingBanners.rows[0].count === 0) {
      const banners = [
        { title: "The Festive Edit", subtitle: "Kurtas, sarees & sherwanis up to 40% off", image: BANNER_IMG[0], link: "/products?category=ethnic" },
        { title: "New Season Arrivals", subtitle: "Fresh styles added every week", image: BANNER_IMG[1], link: "/products?sort=newest" },
        { title: "Winter Layering Essentials", subtitle: "Jackets & sweaters for every budget", image: BANNER_IMG[2], link: "/products?category=winter-wear" },
      ];
      for (let i = 0; i < banners.length; i++) {
        const b = banners[i];
        await client.query(
          `INSERT INTO banners (title, subtitle, image, link, position) VALUES ($1,$2,$3,$4,$5)`,
          [b.title, b.subtitle, b.image, b.link, i]
        );
      }
      console.log("Seeded homepage banners.");
    }

    console.log("Done.");
  } finally {
    client.release();
    await pool.end();
  }
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
