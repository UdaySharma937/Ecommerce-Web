"use client";

import { useEffect, useState } from "react";
import { formatDate } from "@/lib/format";
import { useToast } from "@/components/toast";

type Coupon = {
  id: number;
  code: string;
  type: string;
  value: string;
  minOrderValue: string;
  usageLimit: number;
  usedCount: number;
  isActive: boolean;
  expiresAt: string | null;
};

export default function AdminCouponsPage() {
  const [items, setItems] = useState<Coupon[]>([]);
  const [form, setForm] = useState({ code: "", type: "percent", value: "", minOrderValue: "0", usageLimit: "1000", expiresAt: "" });
  const { show } = useToast();

  function load() {
    fetch("/api/admin/coupons").then((r) => r.json()).then((d) => setItems(d.items || []));
  }
  useEffect(load, []);

  async function createCoupon() {
    if (!form.code || !form.value) {
      show("Enter coupon code and value.", "error");
      return;
    }
    const res = await fetch("/api/admin/coupons", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        code: form.code,
        type: form.type,
        value: Number(form.value),
        minOrderValue: Number(form.minOrderValue || 0),
        usageLimit: Number(form.usageLimit || 1000),
        expiresAt: form.expiresAt || undefined,
      }),
    });
    const d = await res.json();
    if (!res.ok) {
      show(d.error?.message || "Could not create coupon.", "error");
      return;
    }
    show("Coupon created", "success");
    setForm({ code: "", type: "percent", value: "", minOrderValue: "0", usageLimit: "1000", expiresAt: "" });
    load();
  }

  async function toggleActive(c: Coupon) {
    await fetch(`/api/admin/coupons/${c.id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ isActive: !c.isActive }),
    });
    load();
  }

  async function remove(id: number) {
    if (!confirm("Delete this coupon?")) return;
    await fetch(`/api/admin/coupons/${id}`, { method: "DELETE" });
    load();
  }

  return (
    <div>
      <h1 className="text-xl font-semibold mb-5">Coupons</h1>
      <div className="grid lg:grid-cols-[1fr_320px] gap-6">
        <div className="card overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="text-left" style={{ background: "var(--color-accent-soft)" }}>
                <th className="p-3">Code</th>
                <th className="p-3">Discount</th>
                <th className="p-3">Min order</th>
                <th className="p-3">Used</th>
                <th className="p-3">Expires</th>
                <th className="p-3">Status</th>
                <th className="p-3"></th>
              </tr>
            </thead>
            <tbody>
              {items.map((c) => (
                <tr key={c.id} style={{ borderTop: "1px solid var(--color-border)" }}>
                  <td className="p-3 font-mono font-semibold">{c.code}</td>
                  <td className="p-3">{c.type === "percent" ? `${c.value}%` : `₹${c.value}`}</td>
                  <td className="p-3">₹{c.minOrderValue}</td>
                  <td className="p-3">{c.usedCount}/{c.usageLimit}</td>
                  <td className="p-3">{c.expiresAt ? formatDate(c.expiresAt) : "—"}</td>
                  <td className="p-3">
                    <button className={`badge ${c.isActive ? "badge-success" : "badge-danger"}`} onClick={() => toggleActive(c)}>
                      {c.isActive ? "Active" : "Disabled"}
                    </button>
                  </td>
                  <td className="p-3"><button className="btn btn-danger btn-sm" onClick={() => remove(c.id)}>Delete</button></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <div className="card p-5 h-fit">
          <h2 className="font-semibold mb-3 text-sm">New coupon</h2>
          <label className="label">Code</label>
          <input className="input mb-3" value={form.code} onChange={(e) => setForm((f) => ({ ...f, code: e.target.value.toUpperCase() }))} placeholder="WELCOME100" />
          <label className="label">Type</label>
          <select className="input mb-3" value={form.type} onChange={(e) => setForm((f) => ({ ...f, type: e.target.value }))}>
            <option value="percent">Percentage off</option>
            <option value="flat">Flat amount off</option>
          </select>
          <label className="label">Value</label>
          <input className="input mb-3" type="number" value={form.value} onChange={(e) => setForm((f) => ({ ...f, value: e.target.value }))} />
          <label className="label">Minimum order value (₹)</label>
          <input className="input mb-3" type="number" value={form.minOrderValue} onChange={(e) => setForm((f) => ({ ...f, minOrderValue: e.target.value }))} />
          <label className="label">Usage limit</label>
          <input className="input mb-3" type="number" value={form.usageLimit} onChange={(e) => setForm((f) => ({ ...f, usageLimit: e.target.value }))} />
          <label className="label">Expiry date (optional)</label>
          <input className="input mb-3" type="date" value={form.expiresAt} onChange={(e) => setForm((f) => ({ ...f, expiresAt: e.target.value }))} />
          <button className="btn btn-primary btn-block" onClick={createCoupon}>Create coupon</button>
        </div>
      </div>
    </div>
  );
}
