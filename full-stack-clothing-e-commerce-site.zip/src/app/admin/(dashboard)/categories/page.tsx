"use client";

import { useEffect, useState } from "react";
import { useToast } from "@/components/toast";
import { AdminImageUploader } from "@/components/admin-image-uploader";

type Category = { id: number; name: string; slug: string; image: string | null; icon: string | null; position: number };

export default function AdminCategoriesPage() {
  const [items, setItems] = useState<Category[]>([]);
  const [name, setName] = useState("");
  const [icon, setIcon] = useState("👕");
  const [images, setImages] = useState<string[]>([]);
  const { show } = useToast();

  function load() {
    fetch("/api/admin/categories").then((r) => r.json()).then((d) => setItems(d.items || []));
  }
  useEffect(load, []);

  async function addCategory() {
    if (!name.trim()) return;
    const res = await fetch("/api/admin/categories", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name, icon, image: images[0] }),
    });
    if (res.ok) {
      show("Category added", "success");
      setName("");
      setImages([]);
      load();
    }
  }

  async function removeCategory(id: number) {
    if (!confirm("Delete this category? Products inside it will remain but hidden from browsing.")) return;
    await fetch(`/api/admin/categories/${id}`, { method: "DELETE" });
    show("Category removed", "success");
    load();
  }

  return (
    <div>
      <h1 className="text-xl font-semibold mb-5">Categories</h1>
      <div className="grid lg:grid-cols-[1fr_320px] gap-6">
        <div className="card overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="text-left" style={{ background: "var(--color-accent-soft)" }}>
                <th className="p-3">Icon</th>
                <th className="p-3">Name</th>
                <th className="p-3">Slug</th>
                <th className="p-3">Actions</th>
              </tr>
            </thead>
            <tbody>
              {items.map((c) => (
                <tr key={c.id} style={{ borderTop: "1px solid var(--color-border)" }}>
                  <td className="p-3 text-xl">{c.icon}</td>
                  <td className="p-3 font-medium">{c.name}</td>
                  <td className="p-3" style={{ color: "var(--color-ink-soft)" }}>{c.slug}</td>
                  <td className="p-3"><button className="btn btn-danger btn-sm" onClick={() => removeCategory(c.id)}>Delete</button></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <div className="card p-5 h-fit">
          <h2 className="font-semibold mb-3 text-sm">Add category</h2>
          <label className="label">Name</label>
          <input className="input mb-3" value={name} onChange={(e) => setName(e.target.value)} />
          <label className="label">Icon (emoji)</label>
          <input className="input mb-3" value={icon} onChange={(e) => setIcon(e.target.value)} maxLength={4} />
          <label className="label">Category image (optional)</label>
          <AdminImageUploader images={images} onChange={setImages} />
          <button className="btn btn-primary btn-block mt-3" onClick={addCategory}>Add category</button>
        </div>
      </div>
    </div>
  );
}
