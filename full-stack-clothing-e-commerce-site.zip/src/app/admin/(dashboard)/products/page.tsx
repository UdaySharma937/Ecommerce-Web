"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { formatINR } from "@/lib/format";
import { useToast } from "@/components/toast";

type Product = {
  id: number;
  name: string;
  brand: string;
  price: string;
  mrp: string;
  isActive: boolean;
  isFeatured: boolean;
  isTrending: boolean;
  categoryName: string;
  image: string | null;
  totalStock: number;
};

export default function AdminProductsPage() {
  const [items, setItems] = useState<Product[]>([]);
  const [search, setSearch] = useState("");
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [loading, setLoading] = useState(true);
  const { show } = useToast();

  function load() {
    setLoading(true);
    fetch(`/api/admin/products?search=${encodeURIComponent(search)}&page=${page}`)
      .then((r) => r.json())
      .then((d) => {
        setItems(d.items || []);
        setTotalPages(d.totalPages || 1);
      })
      .finally(() => setLoading(false));
  }

  useEffect(load, [page]);

  async function toggleActive(p: Product) {
    await fetch(`/api/admin/products/${p.id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ isActive: !p.isActive }),
    });
    load();
  }

  async function deleteProduct(id: number) {
    if (!confirm("Delete this product permanently?")) return;
    await fetch(`/api/admin/products/${id}`, { method: "DELETE" });
    show("Product deleted", "success");
    load();
  }

  return (
    <div>
      <div className="flex items-center justify-between mb-5">
        <h1 className="text-xl font-semibold">Products</h1>
        <Link href="/admin/products/new" className="btn btn-primary">+ Add product</Link>
      </div>

      <div className="flex gap-2 mb-4">
        <input
          className="input max-w-xs"
          placeholder="Search products..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && (setPage(1), load())}
        />
        <button className="btn btn-outline" onClick={() => { setPage(1); load(); }}>Search</button>
      </div>

      <div className="card overflow-x-auto">
        <table className="w-full text-sm">
          <thead>
            <tr className="text-left" style={{ background: "var(--color-accent-soft)" }}>
              <th className="p-3">Product</th>
              <th className="p-3">Category</th>
              <th className="p-3">Price</th>
              <th className="p-3">Stock</th>
              <th className="p-3">Status</th>
              <th className="p-3">Actions</th>
            </tr>
          </thead>
          <tbody>
            {loading ? (
              <tr><td className="p-4" colSpan={6}>Loading...</td></tr>
            ) : items.length === 0 ? (
              <tr><td className="p-4" colSpan={6}>No products found.</td></tr>
            ) : (
              items.map((p) => (
                <tr key={p.id} style={{ borderTop: "1px solid var(--color-border)" }}>
                  <td className="p-3 flex items-center gap-3">
                    {p.image ? (
                      // eslint-disable-next-line @next/next/no-img-element
                      <img src={p.image} alt="" className="h-12 w-10 object-cover rounded-md" />
                    ) : (
                      <div className="h-12 w-10 rounded-md" style={{ background: "var(--color-accent-soft)" }} />
                    )}
                    <div>
                      <div className="font-medium">{p.name}</div>
                      <div className="text-xs" style={{ color: "var(--color-ink-soft)" }}>{p.brand}</div>
                    </div>
                  </td>
                  <td className="p-3">{p.categoryName}</td>
                  <td className="p-3">{formatINR(p.price)} <span className="line-through text-xs" style={{ color: "var(--color-ink-soft)" }}>{formatINR(p.mrp)}</span></td>
                  <td className="p-3">
                    <span className={p.totalStock <= 10 ? "badge badge-danger" : "badge badge-success"}>{p.totalStock}</span>
                  </td>
                  <td className="p-3">
                    <button className={`badge ${p.isActive ? "badge-success" : "badge-danger"}`} onClick={() => toggleActive(p)}>
                      {p.isActive ? "Active" : "Disabled"}
                    </button>
                  </td>
                  <td className="p-3">
                    <div className="flex gap-2">
                      <Link href={`/admin/products/${p.id}/edit`} className="btn btn-outline btn-sm">Edit</Link>
                      <button className="btn btn-danger btn-sm" onClick={() => deleteProduct(p.id)}>Delete</button>
                    </div>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      {totalPages > 1 && (
        <div className="flex justify-center gap-2 mt-5">
          {Array.from({ length: totalPages }).map((_, i) => (
            <button key={i} className="btn btn-sm btn-outline" style={{ background: page === i + 1 ? "var(--color-accent)" : undefined, color: page === i + 1 ? "#fff" : undefined }} onClick={() => setPage(i + 1)}>
              {i + 1}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}
