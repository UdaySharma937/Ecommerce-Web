"use client";

import { useRouter } from "next/navigation";
import { AdminProductForm, type ProductFormData } from "@/components/admin-product-form";
import { useToast } from "@/components/toast";

export default function NewProductPage() {
  const router = useRouter();
  const { show } = useToast();

  async function handleSubmit(data: ProductFormData) {
    const res = await fetch("/api/admin/products", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ ...data, categoryId: Number(data.categoryId), price: Number(data.price), mrp: Number(data.mrp) }),
    });
    const d = await res.json();
    if (!res.ok) throw new Error(d.error?.message || "Could not create product.");
    show("Product created", "success");
    router.push("/admin/products");
  }

  return (
    <div>
      <h1 className="text-xl font-semibold mb-5">Add new product</h1>
      <AdminProductForm submitLabel="Create product" onSubmit={handleSubmit} />
    </div>
  );
}
