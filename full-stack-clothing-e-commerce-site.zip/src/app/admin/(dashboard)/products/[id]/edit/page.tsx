"use client";

import { useEffect, useState } from "react";
import { useParams, useRouter } from "next/navigation";
import { AdminProductForm, type ProductFormData } from "@/components/admin-product-form";
import { useToast } from "@/components/toast";

export default function EditProductPage() {
  const { id } = useParams<{ id: string }>();
  const router = useRouter();
  const { show } = useToast();
  const [initial, setInitial] = useState<Partial<ProductFormData> | null>(null);

  useEffect(() => {
    fetch(`/api/admin/products/${id}`)
      .then((r) => r.json())
      .then((d) => {
        const p = d.product;
        setInitial({
          name: p.name,
          categoryId: p.categoryId,
          brand: p.brand,
          description: p.description,
          price: p.price,
          mrp: p.mrp,
          tags: p.tags,
          isFeatured: p.isFeatured,
          isTrending: p.isTrending,
          isActive: p.isActive,
          images: p.images.map((img: { url: string }) => img.url),
          variants: p.variants.map((v: { size: string; color: string; colorHex: string; stock: number }) => ({
            size: v.size,
            color: v.color,
            colorHex: v.colorHex,
            stock: v.stock,
          })),
        });
      });
  }, [id]);

  async function handleSubmit(data: ProductFormData) {
    const res = await fetch(`/api/admin/products/${id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ ...data, categoryId: Number(data.categoryId), price: Number(data.price), mrp: Number(data.mrp) }),
    });
    const d = await res.json();
    if (!res.ok) throw new Error(d.error?.message || "Could not update product.");
    show("Product updated", "success");
    router.push("/admin/products");
  }

  if (!initial) return <div className="skeleton h-96 w-full" />;

  return (
    <div>
      <h1 className="text-xl font-semibold mb-5">Edit product</h1>
      <AdminProductForm initial={initial} submitLabel="Save changes" onSubmit={handleSubmit} />
    </div>
  );
}
