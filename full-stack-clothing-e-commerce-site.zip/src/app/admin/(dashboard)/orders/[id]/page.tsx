"use client";

import { useEffect, useState } from "react";
import { useParams } from "next/navigation";
import { formatDate, formatINR } from "@/lib/format";
import { useToast } from "@/components/toast";

const STATUSES = ["Placed", "Confirmed", "Shipped", "Out for delivery", "Delivered", "Cancelled"];

type OrderDetail = {
  id: number;
  orderNumber: string;
  status: string;
  paymentMethod: string;
  paymentStatus: string;
  subtotal: string;
  discount: string;
  deliveryFee: string;
  total: string;
  couponCode: string | null;
  address: { fullName: string; phone: string; line1: string; line2?: string; city: string; state: string; pincode: string };
  createdAt: string;
  customerName: string | null;
  customerEmail: string | null;
  customerPhone: string | null;
};
type Item = { id: number; name: string; image: string | null; price: string; quantity: number; size: string; color: string };
type History = { id: number; status: string; note: string | null; createdAt: string };

export default function AdminOrderDetailPage() {
  const { id } = useParams<{ id: string }>();
  const { show } = useToast();
  const [order, setOrder] = useState<OrderDetail | null>(null);
  const [items, setItems] = useState<Item[]>([]);
  const [history, setHistory] = useState<History[]>([]);
  const [status, setStatus] = useState("");
  const [updating, setUpdating] = useState(false);

  function load() {
    fetch(`/api/admin/orders/${id}`)
      .then((r) => r.json())
      .then((d) => {
        setOrder(d.order);
        setItems(d.items);
        setHistory(d.history);
        setStatus(d.order.status);
      });
  }
  useEffect(load, [id]);

  async function updateStatus() {
    setUpdating(true);
    try {
      const res = await fetch(`/api/admin/orders/${id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ status }),
      });
      if (!res.ok) {
        const d = await res.json();
        show(d.error?.message || "Could not update status.", "error");
        return;
      }
      show("Order status updated", "success");
      load();
    } finally {
      setUpdating(false);
    }
  }

  if (!order) return <div className="skeleton h-96 w-full" />;

  return (
    <div>
      <div className="flex items-center justify-between mb-5 print:hidden">
        <h1 className="text-xl font-semibold">{order.orderNumber}</h1>
        <button className="btn btn-outline" onClick={() => window.print()}>Print invoice</button>
      </div>

      <div className="grid lg:grid-cols-[1fr_320px] gap-6">
        <div className="flex flex-col gap-4">
          <div className="card p-5">
            <h2 className="font-semibold mb-3 text-sm">Items</h2>
            {items.map((item) => (
              <div key={item.id} className="flex gap-3 items-center py-2" style={{ borderTop: "1px solid var(--color-border)" }}>
                {item.image && (
                  // eslint-disable-next-line @next/next/no-img-element
                  <img src={item.image} alt="" className="h-16 w-14 object-cover rounded-md" />
                )}
                <div className="flex-1 text-sm">
                  <div className="font-medium">{item.name}</div>
                  <div style={{ color: "var(--color-ink-soft)" }}>{item.size} · {item.color} · Qty {item.quantity}</div>
                </div>
                <div className="font-semibold text-sm">{formatINR(item.price)}</div>
              </div>
            ))}
          </div>

          <div className="card p-5 print:hidden">
            <h2 className="font-semibold mb-3 text-sm">Status history</h2>
            {history.map((h) => (
              <div key={h.id} className="flex justify-between text-sm py-1">
                <span>{h.status}{h.note ? ` — ${h.note}` : ""}</span>
                <span style={{ color: "var(--color-ink-soft)" }}>{formatDate(h.createdAt)}</span>
              </div>
            ))}
          </div>
        </div>

        <div className="flex flex-col gap-4">
          <div className="card p-5">
            <h2 className="font-semibold mb-2 text-sm">Customer</h2>
            <p className="text-sm">{order.customerName || "Guest"}</p>
            <p className="text-xs" style={{ color: "var(--color-ink-soft)" }}>{order.customerEmail}</p>
            <p className="text-xs" style={{ color: "var(--color-ink-soft)" }}>{order.customerPhone}</p>
          </div>
          <div className="card p-5">
            <h2 className="font-semibold mb-2 text-sm">Delivery address</h2>
            <p className="text-sm">
              {order.address.fullName} · {order.address.phone}<br />
              {order.address.line1}{order.address.line2 ? `, ${order.address.line2}` : ""}<br />
              {order.address.city}, {order.address.state} - {order.address.pincode}
            </p>
          </div>
          <div className="card p-5">
            <h2 className="font-semibold mb-2 text-sm">Billing</h2>
            <div className="flex justify-between text-sm"><span>Subtotal</span><span>{formatINR(order.subtotal)}</span></div>
            <div className="flex justify-between text-sm"><span>Discount</span><span>−{formatINR(order.discount)}</span></div>
            <div className="flex justify-between text-sm"><span>Delivery</span><span>{formatINR(order.deliveryFee)}</span></div>
            <div className="flex justify-between font-bold mt-2 pt-2" style={{ borderTop: "1px dashed var(--color-border)" }}><span>Total</span><span>{formatINR(order.total)}</span></div>
            <p className="text-xs mt-2" style={{ color: "var(--color-ink-soft)" }}>{order.paymentMethod} · {order.paymentStatus}</p>
          </div>
          <div className="card p-5 print:hidden">
            <h2 className="font-semibold mb-2 text-sm">Update status</h2>
            <select className="input mb-3" value={status} onChange={(e) => setStatus(e.target.value)}>
              {STATUSES.map((s) => <option key={s} value={s}>{s}</option>)}
            </select>
            <button className="btn btn-primary btn-block" disabled={updating} onClick={updateStatus}>Update status</button>
          </div>
        </div>
      </div>
    </div>
  );
}
