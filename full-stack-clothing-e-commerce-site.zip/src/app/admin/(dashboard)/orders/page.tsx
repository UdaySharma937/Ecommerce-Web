"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { formatDate, formatINR } from "@/lib/format";

type Order = {
  id: number;
  orderNumber: string;
  status: string;
  paymentMethod: string;
  total: string;
  createdAt: string;
  customerName: string;
  customerEmail: string | null;
  customerPhone: string | null;
  itemCount: number;
};

const STATUSES = ["Placed", "Confirmed", "Shipped", "Out for delivery", "Delivered", "Cancelled"];

export default function AdminOrdersPage() {
  const [items, setItems] = useState<Order[]>([]);
  const [status, setStatus] = useState("");
  const [search, setSearch] = useState("");
  const [from, setFrom] = useState("");
  const [to, setTo] = useState("");
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [loading, setLoading] = useState(true);

  function load() {
    setLoading(true);
    const params = new URLSearchParams({ page: String(page) });
    if (status) params.set("status", status);
    if (search) params.set("search", search);
    if (from) params.set("from", from);
    if (to) params.set("to", to);
    fetch(`/api/admin/orders?${params.toString()}`)
      .then((r) => r.json())
      .then((d) => {
        setItems(d.items || []);
        setTotalPages(d.totalPages || 1);
      })
      .finally(() => setLoading(false));
  }

  useEffect(load, [page, status]);

  return (
    <div>
      <div className="flex items-center justify-between mb-5">
        <h1 className="text-xl font-semibold">Orders</h1>
        <a href="/api/admin/export/orders" className="btn btn-outline">Export CSV</a>
      </div>

      <div className="flex flex-wrap gap-2 mb-4">
        <input className="input max-w-xs" placeholder="Search order #, customer..." value={search} onChange={(e) => setSearch(e.target.value)} onKeyDown={(e) => e.key === "Enter" && (setPage(1), load())} />
        <select className="input w-auto" value={status} onChange={(e) => { setStatus(e.target.value); setPage(1); }}>
          <option value="">All statuses</option>
          {STATUSES.map((s) => <option key={s} value={s}>{s}</option>)}
        </select>
        <input className="input w-auto" type="date" value={from} onChange={(e) => setFrom(e.target.value)} />
        <input className="input w-auto" type="date" value={to} onChange={(e) => setTo(e.target.value)} />
        <button className="btn btn-outline" onClick={() => { setPage(1); load(); }}>Filter</button>
      </div>

      <div className="card overflow-x-auto">
        <table className="w-full text-sm">
          <thead>
            <tr className="text-left" style={{ background: "var(--color-accent-soft)" }}>
              <th className="p-3">Order</th>
              <th className="p-3">Customer</th>
              <th className="p-3">Items</th>
              <th className="p-3">Payment</th>
              <th className="p-3">Total</th>
              <th className="p-3">Status</th>
              <th className="p-3">Date</th>
            </tr>
          </thead>
          <tbody>
            {loading ? (
              <tr><td className="p-4" colSpan={7}>Loading...</td></tr>
            ) : items.length === 0 ? (
              <tr><td className="p-4" colSpan={7}>No orders found.</td></tr>
            ) : (
              items.map((o) => (
                <tr key={o.id} style={{ borderTop: "1px solid var(--color-border)" }}>
                  <td className="p-3"><Link href={`/admin/orders/${o.id}`} className="font-medium hover:underline">{o.orderNumber}</Link></td>
                  <td className="p-3">
                    <div>{o.customerName}</div>
                    <div className="text-xs" style={{ color: "var(--color-ink-soft)" }}>{o.customerEmail || o.customerPhone}</div>
                  </td>
                  <td className="p-3">{o.itemCount}</td>
                  <td className="p-3">{o.paymentMethod}</td>
                  <td className="p-3">{formatINR(o.total)}</td>
                  <td className="p-3"><span className="badge badge-gold">{o.status}</span></td>
                  <td className="p-3">{formatDate(o.createdAt)}</td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      {totalPages > 1 && (
        <div className="flex justify-center gap-2 mt-5">
          {Array.from({ length: totalPages }).map((_, i) => (
            <button key={i} className="btn btn-sm btn-outline" onClick={() => setPage(i + 1)}>{i + 1}</button>
          ))}
        </div>
      )}
    </div>
  );
}
