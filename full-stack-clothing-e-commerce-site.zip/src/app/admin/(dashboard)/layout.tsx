import type { ReactNode } from "react";
import { redirect } from "next/navigation";
import { getCurrentAdmin } from "@/lib/current-user";
import { AdminSidebar } from "@/components/admin-sidebar";

export default async function AdminDashboardLayout({ children }: { children: ReactNode }) {
  const admin = await getCurrentAdmin();
  if (!admin) redirect("/admin/login");

  return (
    <div className="flex min-h-screen" style={{ background: "var(--color-bg)" }}>
      <AdminSidebar adminName={admin.name} />
      <main className="flex-1 p-6 overflow-x-hidden">{children}</main>
    </div>
  );
}
