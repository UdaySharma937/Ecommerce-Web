"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { useParams } from "next/navigation";
import { formatDate, formatINR } from "@/lib/format";

type Customer = { id: number; name: string | null; email: string | null; phone: string | null; gender: string | null; joinedAt: string };
type Order = { id: number; orderNumber: string; status: string; total: string; createdAt: string };
type Address = { id: number; label: string; fullName: string; phone: string; line1: string; city: string; state: string; pincode: string };

export default function AdminCustomerDetailPage() {
  const { id } = useParams<{ id: string }>();
  const [customer, setCustomer] = useState<Customer | null>(null);
  const [orders, setOrders] = useState<Order[]>([]);
  const [addresses, setAddresses] = useState<Address[]>([]);

  useEffect(() => {
    fetch(`/api/admin/customers/${id}`)
      .then((r) => r.json())
      .then((d) => {
        setCustomer(d.customer);
        setOrders(d.orders);
        setAddresses(d.addresses);
      });
  }, [id]);

  if (!customer) return <div className="skeleton h-96 w-full" />;

  const totalSpent = orders.filter((o) => o.status !== "Cancelled").reduce((s, o) => s + parseFloat(o.total), 0);

  return (
    <div>
      <Link href="/admin/customers" className="text-sm font-semibold mb-4 inline-block" style={{ color: "var(--color-accent)" }}>← All customers</Link>
      <div className="grid lg:grid-cols-[1fr_320px] gap-6">
        <div>
          <div className="card p-5 mb-5">
            <h1 className="text-lg font-semibold">{customer.name || "Unnamed customer"}</h1>
            <p className="text-sm" style={{ color: "var(--color-ink-soft)" }}>{customer.email} {customer.phone && `· ${customer.phone}`}</p>
            <p className="text-xs mt-1" style={{ color: "var(--color-ink-soft)" }}>Joined {formatDate(customer.joinedAt)}</p>
          </div>
          <div className="card p-5">
            <h2 className="font-semibold mb-3 text-sm">Order history ({orders.length})</h2>
            {orders.map((o) => (
              <div key={o.id} className="flex justify-between items-center py-2 text-sm" style={{ borderTop: "1px solid var(--color-border)" }}>
                <Link href={`/admin/orders/${o.id}`} className="font-medium hover:underline">{o.orderNumber}</Link>
                <span className="badge badge-gold">{o.status}</span>
                <span>{formatINR(o.total)}</span>
                <span style={{ color: "var(--color-ink-soft)" }}>{formatDate(o.createdAt)}</span>
              </div>
            ))}
          </div>
        </div>
        <div className="flex flex-col gap-4">
          <div className="card p-5">
            <div className="text-xs font-semibold uppercase" style={{ color: "var(--color-ink-soft)" }}>Total Orders</div>
            <div className="text-xl font-bold">{orders.length}</div>
          </div>
          <div className="card p-5">
            <div className="text-xs font-semibold uppercase" style={{ color: "var(--color-ink-soft)" }}>Total Spent</div>
            <div className="text-xl font-bold">{formatINR(totalSpent)}</div>
          </div>
          <div className="card p-5">
            <h2 className="font-semibold mb-2 text-sm">Addresses</h2>
            {addresses.length === 0 && <p className="text-sm" style={{ color: "var(--color-ink-soft)" }}>No saved addresses.</p>}
            {addresses.map((a) => (
              <p key={a.id} className="text-sm mb-2" style={{ color: "var(--color-ink-soft)" }}>
                <strong style={{ color: "var(--color-ink)" }}>{a.label}:</strong> {a.line1}, {a.city}, {a.state} - {a.pincode}
              </p>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
