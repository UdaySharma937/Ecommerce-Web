"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { formatDate, formatINR } from "@/lib/format";

type Customer = { id: number; name: string | null; email: string | null; phone: string | null; joinedAt: string; totalOrders: number; totalSpent: number };

export default function AdminCustomersPage() {
  const [items, setItems] = useState<Customer[]>([]);
  const [search, setSearch] = useState("");
  const [loading, setLoading] = useState(true);

  function load() {
    setLoading(true);
    fetch(`/api/admin/customers?search=${encodeURIComponent(search)}`)
      .then((r) => r.json())
      .then((d) => setItems(d.items || []))
      .finally(() => setLoading(false));
  }
  useEffect(load, []);

  return (
    <div>
      <div className="flex items-center justify-between mb-5">
        <h1 className="text-xl font-semibold">Customers</h1>
        <a href="/api/admin/export/customers" className="btn btn-outline">Export CSV</a>
      </div>
      <div className="flex gap-2 mb-4">
        <input className="input max-w-xs" placeholder="Search customers..." value={search} onChange={(e) => setSearch(e.target.value)} onKeyDown={(e) => e.key === "Enter" && load()} />
        <button className="btn btn-outline" onClick={load}>Search</button>
      </div>
      <div className="card overflow-x-auto">
        <table className="w-full text-sm">
          <thead>
            <tr className="text-left" style={{ background: "var(--color-accent-soft)" }}>
              <th className="p-3">Name</th>
              <th className="p-3">Contact</th>
              <th className="p-3">Joined</th>
              <th className="p-3">Orders</th>
              <th className="p-3">Total Spent</th>
            </tr>
          </thead>
          <tbody>
            {loading ? (
              <tr><td className="p-4" colSpan={5}>Loading...</td></tr>
            ) : items.length === 0 ? (
              <tr><td className="p-4" colSpan={5}>No customers found.</td></tr>
            ) : (
              items.map((c) => (
                <tr key={c.id} style={{ borderTop: "1px solid var(--color-border)" }}>
                  <td className="p-3"><Link href={`/admin/customers/${c.id}`} className="font-medium hover:underline">{c.name || "Unnamed"}</Link></td>
                  <td className="p-3" style={{ color: "var(--color-ink-soft)" }}>{c.email || c.phone}</td>
                  <td className="p-3">{formatDate(c.joinedAt)}</td>
                  <td className="p-3">{c.totalOrders}</td>
                  <td className="p-3 font-semibold">{formatINR(c.totalSpent)}</td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
