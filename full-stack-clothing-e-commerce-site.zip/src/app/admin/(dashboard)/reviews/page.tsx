"use client";

import { useEffect, useState } from "react";
import { formatDate } from "@/lib/format";
import { StarRating } from "@/components/star-rating";
import { useToast } from "@/components/toast";

type Review = {
  id: number;
  rating: number;
  title: string | null;
  body: string | null;
  isHidden: boolean;
  createdAt: string;
  userName: string;
  productName: string;
};

export default function AdminReviewsPage() {
  const [items, setItems] = useState<Review[]>([]);
  const { show } = useToast();

  function load() {
    fetch("/api/admin/reviews").then((r) => r.json()).then((d) => setItems(d.items || []));
  }
  useEffect(load, []);

  async function toggleHide(r: Review) {
    await fetch(`/api/admin/reviews/${r.id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ isHidden: !r.isHidden }),
    });
    load();
  }

  async function remove(id: number) {
    if (!confirm("Delete this review permanently?")) return;
    await fetch(`/api/admin/reviews/${id}`, { method: "DELETE" });
    show("Review deleted", "success");
    load();
  }

  return (
    <div>
      <h1 className="text-xl font-semibold mb-5">Reviews</h1>
      <div className="flex flex-col gap-3">
        {items.map((r) => (
          <div key={r.id} className="card p-4 flex justify-between gap-4">
            <div>
              <div className="flex items-center gap-2 mb-1">
                <StarRating value={r.rating} />
                <span className="text-xs font-semibold">{r.productName}</span>
                {r.isHidden && <span className="badge badge-danger">Hidden</span>}
              </div>
              {r.title && <div className="font-semibold text-sm">{r.title}</div>}
              {r.body && <p className="text-sm" style={{ color: "var(--color-ink-soft)" }}>{r.body}</p>}
              <p className="text-xs mt-1" style={{ color: "var(--color-ink-soft)" }}>{r.userName} · {formatDate(r.createdAt)}</p>
            </div>
            <div className="flex flex-col gap-2 shrink-0">
              <button className="btn btn-outline btn-sm" onClick={() => toggleHide(r)}>{r.isHidden ? "Unhide" : "Hide"}</button>
              <button className="btn btn-danger btn-sm" onClick={() => remove(r.id)}>Delete</button>
            </div>
          </div>
        ))}
        {items.length === 0 && <p style={{ color: "var(--color-ink-soft)" }}>No reviews yet.</p>}
      </div>
    </div>
  );
}
