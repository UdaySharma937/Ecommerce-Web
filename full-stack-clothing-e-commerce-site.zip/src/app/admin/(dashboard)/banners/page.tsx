"use client";

import { useEffect, useState } from "react";
import { AdminImageUploader } from "@/components/admin-image-uploader";
import { useToast } from "@/components/toast";

type Banner = { id: number; title: string; subtitle: string | null; image: string; link: string | null; isActive: boolean; position: number };

export default function AdminBannersPage() {
  const [items, setItems] = useState<Banner[]>([]);
  const [form, setForm] = useState({ title: "", subtitle: "", link: "/products" });
  const [images, setImages] = useState<string[]>([]);
  const { show } = useToast();

  function load() {
    fetch("/api/admin/banners").then((r) => r.json()).then((d) => setItems(d.items || []));
  }
  useEffect(load, []);

  async function createBanner() {
    if (!form.title || images.length === 0) {
      show("Add a title and banner image.", "error");
      return;
    }
    const res = await fetch("/api/admin/banners", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ ...form, image: images[0] }),
    });
    if (res.ok) {
      show("Banner added", "success");
      setForm({ title: "", subtitle: "", link: "/products" });
      setImages([]);
      load();
    }
  }

  async function toggleActive(b: Banner) {
    await fetch(`/api/admin/banners/${b.id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ isActive: !b.isActive }),
    });
    load();
  }

  async function remove(id: number) {
    if (!confirm("Delete this banner?")) return;
    await fetch(`/api/admin/banners/${id}`, { method: "DELETE" });
    load();
  }

  return (
    <div>
      <h1 className="text-xl font-semibold mb-5">Home Banners</h1>
      <div className="grid lg:grid-cols-[1fr_340px] gap-6">
        <div className="flex flex-col gap-3">
          {items.map((b) => (
            <div key={b.id} className="card p-3 flex gap-3 items-center">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img src={b.image} alt="" className="h-16 w-28 object-cover rounded-lg" />
              <div className="flex-1">
                <div className="font-medium text-sm">{b.title}</div>
                <div className="text-xs" style={{ color: "var(--color-ink-soft)" }}>{b.subtitle}</div>
              </div>
              <button className={`badge ${b.isActive ? "badge-success" : "badge-danger"}`} onClick={() => toggleActive(b)}>
                {b.isActive ? "Active" : "Hidden"}
              </button>
              <button className="btn btn-danger btn-sm" onClick={() => remove(b.id)}>Delete</button>
            </div>
          ))}
          {items.length === 0 && <p style={{ color: "var(--color-ink-soft)" }}>No banners yet. Add one to populate the homepage slider.</p>}
        </div>
        <div className="card p-5 h-fit">
          <h2 className="font-semibold mb-3 text-sm">New banner</h2>
          <label className="label">Title</label>
          <input className="input mb-3" value={form.title} onChange={(e) => setForm((f) => ({ ...f, title: e.target.value }))} />
          <label className="label">Subtitle</label>
          <input className="input mb-3" value={form.subtitle} onChange={(e) => setForm((f) => ({ ...f, subtitle: e.target.value }))} />
          <label className="label">Link (where it points to)</label>
          <input className="input mb-3" value={form.link} onChange={(e) => setForm((f) => ({ ...f, link: e.target.value }))} />
          <label className="label">Banner image</label>
          <AdminImageUploader images={images} onChange={setImages} />
          <button className="btn btn-primary btn-block mt-3" onClick={createBanner}>Add banner</button>
        </div>
      </div>
    </div>
  );
}
