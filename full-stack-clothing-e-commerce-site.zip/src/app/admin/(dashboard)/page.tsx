"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { formatDate, formatINR } from "@/lib/format";

type Dashboard = {
  totals: { totalSales: number; ordersToday: number; pendingOrders: number; totalOrders: number; totalCustomers: number };
  lowStock: { id: number; name: string; size: string; color: string; stock: number }[];
  revenueChart: { label: string; revenue: number }[];
  recentOrders: { id: number; orderNumber: string; status: string; total: string; createdAt: string; customerName: string }[];
};

export default function AdminDashboardPage() {
  const [data, setData] = useState<Dashboard | null>(null);

  useEffect(() => {
    fetch("/api/admin/dashboard").then((r) => r.json()).then(setData);
  }, []);

  if (!data) return <div className="skeleton h-96 w-full" />;

  const maxRevenue = Math.max(1, ...data.revenueChart.map((d) => d.revenue));

  return (
    <div>
      <h1 className="text-xl font-semibold mb-5">Dashboard</h1>
      <div className="grid grid-cols-2 lg:grid-cols-5 gap-4 mb-8">
        <StatCard label="Total Sales" value={formatINR(data.totals.totalSales)} />
        <StatCard label="Orders Today" value={String(data.totals.ordersToday)} />
        <StatCard label="Pending Orders" value={String(data.totals.pendingOrders)} accent="var(--color-gold)" />
        <StatCard label="Total Orders" value={String(data.totals.totalOrders)} />
        <StatCard label="Total Customers" value={String(data.totals.totalCustomers)} />
      </div>

      <div className="grid lg:grid-cols-[2fr_1fr] gap-6 mb-8">
        <div className="card p-5">
          <h2 className="font-semibold mb-4 text-sm">Revenue — last 30 days</h2>
          <div className="flex items-end gap-1 h-40">
            {data.revenueChart.map((d, i) => (
              <div key={i} className="flex-1 flex flex-col items-center justify-end group relative">
                <div
                  className="w-full rounded-t-sm transition-all"
                  style={{ height: `${Math.max(2, (d.revenue / maxRevenue) * 100)}%`, background: "var(--color-accent)" }}
                  title={`${d.label}: ${formatINR(d.revenue)}`}
                />
              </div>
            ))}
          </div>
          <div className="flex justify-between text-[10px] mt-2" style={{ color: "var(--color-ink-soft)" }}>
            <span>{data.revenueChart[0]?.label}</span>
            <span>{data.revenueChart[data.revenueChart.length - 1]?.label}</span>
          </div>
        </div>

        <div className="card p-5">
          <h2 className="font-semibold mb-4 text-sm">Low stock alerts</h2>
          {data.lowStock.length === 0 ? (
            <p className="text-sm" style={{ color: "var(--color-ink-soft)" }}>All variants are well stocked.</p>
          ) : (
            <div className="flex flex-col gap-2">
              {data.lowStock.map((item, i) => (
                <div key={i} className="flex justify-between text-sm">
                  <span>{item.name} ({item.size}/{item.color})</span>
                  <span className="badge badge-danger">{item.stock} left</span>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      <div className="card p-5">
        <div className="flex items-center justify-between mb-4">
          <h2 className="font-semibold text-sm">Recent orders</h2>
          <Link href="/admin/orders" className="text-xs font-semibold" style={{ color: "var(--color-accent)" }}>View all →</Link>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="text-left" style={{ color: "var(--color-ink-soft)" }}>
                <th className="pb-2">Order</th>
                <th className="pb-2">Customer</th>
                <th className="pb-2">Status</th>
                <th className="pb-2">Total</th>
                <th className="pb-2">Date</th>
              </tr>
            </thead>
            <tbody>
              {data.recentOrders.map((o) => (
                <tr key={o.id} style={{ borderTop: "1px solid var(--color-border)" }}>
                  <td className="py-2"><Link href={`/admin/orders/${o.id}`} className="font-medium hover:underline">{o.orderNumber}</Link></td>
                  <td className="py-2">{o.customerName}</td>
                  <td className="py-2"><span className="badge badge-gold">{o.status}</span></td>
                  <td className="py-2">{formatINR(o.total)}</td>
                  <td className="py-2">{formatDate(o.createdAt)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

function StatCard({ label, value, accent }: { label: string; value: string; accent?: string }) {
  return (
    <div className="card p-4">
      <div className="text-xs font-semibold uppercase" style={{ color: "var(--color-ink-soft)" }}>{label}</div>
      <div className="text-xl font-bold mt-1" style={{ color: accent }}>{value}</div>
    </div>
  );
}
