"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";

export default function AdminLoginPage() {
  const [email, setEmail] = useState("admin@vastrahaus.in");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const router = useRouter();

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError("");
    try {
      const res = await fetch("/api/admin/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, password }),
      });
      const d = await res.json();
      if (!res.ok) {
        setError(d.error?.message || "Login failed.");
        return;
      }
      router.push("/admin");
      router.refresh();
    } finally {
      setBusy(false);
    }
  }

  return (
    <div
      className="min-h-screen flex items-center justify-center p-4"
      style={{ background: "var(--color-ink)" }}
    >
      <div className="card w-full max-w-sm p-6">
        <div className="text-center mb-6">
          <h1 style={{ fontFamily: "var(--font-display)", color: "var(--color-accent)" }} className="text-2xl font-bold">
            Vastrahaus
          </h1>
          <p className="text-sm" style={{ color: "var(--color-ink-soft)" }}>Admin Console</p>
        </div>
        <form onSubmit={submit} className="flex flex-col gap-3">
          <div>
            <label className="label" htmlFor="email">Email</label>
            <input id="email" type="email" className="input" value={email} onChange={(e) => setEmail(e.target.value)} required />
          </div>
          <div>
            <label className="label" htmlFor="password">Password</label>
            <input id="password" type="password" className="input" value={password} onChange={(e) => setPassword(e.target.value)} required />
          </div>
          {error && <p className="text-sm" style={{ color: "var(--color-danger)" }}>{error}</p>}
          <button className="btn btn-primary btn-block" disabled={busy}>{busy ? "Signing in..." : "Sign in"}</button>
        </form>
        <p className="text-xs text-center mt-5" style={{ color: "var(--color-ink-soft)" }}>
          Default seeded admin: admin@vastrahaus.in / Admin@123
        </p>
      </div>
    </div>
  );
}
