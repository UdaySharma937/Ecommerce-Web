import type { ReactNode } from "react";
import { Header } from "@/components/header";
import { BottomNav } from "@/components/bottom-nav";
import Link from "next/link";

export default function SiteLayout({ children }: { children: ReactNode }) {
  return (
    <div className="flex min-h-screen flex-col">
      <Header />
      <main className="flex-1 pb-16 sm:pb-0">{children}</main>
      <footer
        className="hidden sm:block mt-10"
        style={{ background: "var(--color-ink)", color: "var(--color-bg)" }}
      >
        <div className="container-page py-10 grid grid-cols-4 gap-8 text-sm">
          <div>
            <div style={{ fontFamily: "var(--font-display)", fontSize: "1.3rem" }} className="mb-3">
              Vastrahaus
            </div>
            <p style={{ color: "#c7bdb3" }}>
              Honest clothing, fair prices. Shipping across India since 2019.
            </p>
          </div>
          <div>
            <div className="font-semibold mb-3">Shop</div>
            <ul className="space-y-2" style={{ color: "#c7bdb3" }}>
              <li><Link href="/products?category=men">Men</Link></li>
              <li><Link href="/products?category=women">Women</Link></li>
              <li><Link href="/products?category=kids">Kids</Link></li>
              <li><Link href="/products?category=ethnic">Ethnic</Link></li>
            </ul>
          </div>
          <div>
            <div className="font-semibold mb-3">Help</div>
            <ul className="space-y-2" style={{ color: "#c7bdb3" }}>
              <li><Link href="/settings">Returns &amp; refunds</Link></li>
              <li><Link href="/settings">Shipping policy</Link></li>
              <li><Link href="/settings">Privacy policy</Link></li>
              <li><Link href="/settings">Contact us</Link></li>
            </ul>
          </div>
          <div>
            <div className="font-semibold mb-3">Account</div>
            <ul className="space-y-2" style={{ color: "#c7bdb3" }}>
              <li><Link href="/orders">Track order</Link></li>
              <li><Link href="/wishlist">Wishlist</Link></li>
              <li><Link href="/admin/login">Admin login</Link></li>
            </ul>
          </div>
        </div>
        <div className="container-page py-4 text-xs" style={{ borderTop: "1px solid #3a332c", color: "#9c9088" }}>
          © {new Date().getFullYear()} Vastrahaus Retail Pvt. Ltd. All prices inclusive of GST.
        </div>
      </footer>
      <BottomNav />
    </div>
  );
}
