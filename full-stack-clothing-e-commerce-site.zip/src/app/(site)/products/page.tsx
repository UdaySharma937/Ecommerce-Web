"use client";

import { Suspense, useCallback, useEffect, useMemo, useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { ProductCard, type ProductCardData } from "@/components/product-card";
import { ProductGridSkeleton } from "@/components/skeletons";
import { EmptyState } from "@/components/empty-state";

type Category = { id: number; name: string; slug: string };

const SIZES = ["XS", "S", "M", "L", "XL", "XXL"];
const COLORS = [
  { name: "Black", hex: "#1c1c1c" },
  { name: "White", hex: "#f5f5f0" },
  { name: "Blue", hex: "#3b5a9a" },
  { name: "Red", hex: "#b23b3b" },
  { name: "Green", hex: "#3f7a4f" },
  { name: "Beige", hex: "#d8c7a8" },
  { name: "Yellow", hex: "#dcb441" },
  { name: "Pink", hex: "#d98fa3" },
];

function ProductsPageInner() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const [items, setItems] = useState<ProductCardData[]>([]);
  const [totalPages, setTotalPages] = useState(1);
  const [total, setTotal] = useState(0);
  const [loading, setLoading] = useState(true);
  const [categories, setCategories] = useState<Category[]>([]);
  const [filtersOpen, setFiltersOpen] = useState(false);

  const search = searchParams.get("search") || "";
  const category = searchParams.getAll("category");
  const size = searchParams.getAll("size");
  const color = searchParams.getAll("color");
  const minPrice = searchParams.get("minPrice") || "";
  const maxPrice = searchParams.get("maxPrice") || "";
  const rating = searchParams.get("rating") || "";
  const discount = searchParams.get("discount") || "";
  const sort = searchParams.get("sort") || "relevance";
  const page = parseInt(searchParams.get("page") || "1", 10);

  useEffect(() => {
    fetch("/api/categories").then((r) => r.json()).then((d) => setCategories(d.items || []));
  }, []);

  useEffect(() => {
    setLoading(true);
    const params = new URLSearchParams(searchParams.toString());
    fetch(`/api/products?${params.toString()}`)
      .then((r) => r.json())
      .then((d) => {
        setItems(d.items || []);
        setTotalPages(d.totalPages || 1);
        setTotal(d.total || 0);
      })
      .finally(() => setLoading(false));
  }, [searchParams]);

  const updateParams = useCallback(
    (mutator: (p: URLSearchParams) => void) => {
      const params = new URLSearchParams(searchParams.toString());
      mutator(params);
      params.delete("page");
      router.push(`/products?${params.toString()}`);
    },
    [router, searchParams]
  );

  function toggleArrayParam(key: string, value: string) {
    updateParams((p) => {
      const current = p.getAll(key);
      p.delete(key);
      if (current.includes(value)) {
        current.filter((v) => v !== value).forEach((v) => p.append(key, v));
      } else {
        [...current, value].forEach((v) => p.append(key, v));
      }
    });
  }

  function goToPage(n: number) {
    const params = new URLSearchParams(searchParams.toString());
    params.set("page", String(n));
    router.push(`/products?${params.toString()}`);
    window.scrollTo({ top: 0, behavior: "smooth" });
  }

  const title = useMemo(() => {
    if (search) return `Results for "${search}"`;
    if (category.length === 1) {
      const c = categories.find((c) => c.slug === category[0]);
      return c?.name || "Products";
    }
    return "All Products";
  }, [search, category, categories]);

  return (
    <div className="container-page py-5">
      <div className="flex items-center justify-between mb-4 sm:hidden">
        <h1 className="text-lg font-semibold">{title}</h1>
        <button className="btn btn-outline btn-sm" onClick={() => setFiltersOpen(true)}>
          Filters
        </button>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-[220px_1fr] gap-6">
        <aside className={`${filtersOpen ? "fixed inset-0 z-50 overflow-y-auto p-4" : "hidden"} sm:static sm:block sm:p-0`} style={filtersOpen ? { background: "var(--color-bg)" } : {}}>
          {filtersOpen && (
            <div className="flex items-center justify-between mb-4 sm:hidden">
              <h2 className="font-semibold">Filters</h2>
              <button className="btn btn-ghost btn-sm" onClick={() => setFiltersOpen(false)}>Close ✕</button>
            </div>
          )}
          <FilterSection title="Category">
            {categories.map((c) => (
              <label key={c.slug} className="flex items-center gap-2 text-sm py-1 cursor-pointer">
                <input type="checkbox" checked={category.includes(c.slug)} onChange={() => toggleArrayParam("category", c.slug)} />
                {c.name}
              </label>
            ))}
          </FilterSection>

          <FilterSection title="Price">
            <div className="flex gap-2 items-center">
              <input
                className="input"
                type="number"
                placeholder="Min"
                defaultValue={minPrice}
                onBlur={(e) => updateParams((p) => (e.target.value ? p.set("minPrice", e.target.value) : p.delete("minPrice")))}
              />
              <span>–</span>
              <input
                className="input"
                type="number"
                placeholder="Max"
                defaultValue={maxPrice}
                onBlur={(e) => updateParams((p) => (e.target.value ? p.set("maxPrice", e.target.value) : p.delete("maxPrice")))}
              />
            </div>
          </FilterSection>

          <FilterSection title="Size">
            <div className="flex flex-wrap gap-2">
              {SIZES.map((s) => (
                <button
                  key={s}
                  onClick={() => toggleArrayParam("size", s)}
                  className="btn btn-sm"
                  style={{
                    border: "1px solid var(--color-border)",
                    background: size.includes(s) ? "var(--color-ink)" : "transparent",
                    color: size.includes(s) ? "var(--color-bg)" : "var(--color-ink)",
                  }}
                >
                  {s}
                </button>
              ))}
            </div>
          </FilterSection>

          <FilterSection title="Color">
            <div className="flex flex-wrap gap-2">
              {COLORS.map((c) => (
                <button
                  key={c.name}
                  onClick={() => toggleArrayParam("color", c.name)}
                  aria-label={c.name}
                  title={c.name}
                  className="h-7 w-7 rounded-full"
                  style={{
                    background: c.hex,
                    border: color.includes(c.name) ? "3px solid var(--color-accent)" : "1px solid var(--color-border)",
                  }}
                />
              ))}
            </div>
          </FilterSection>

          <FilterSection title="Rating">
            {[4, 3, 2].map((r) => (
              <label key={r} className="flex items-center gap-2 text-sm py-1 cursor-pointer">
                <input type="radio" name="rating" checked={rating === String(r)} onChange={() => updateParams((p) => p.set("rating", String(r)))} />
                {r}★ &amp; above
              </label>
            ))}
            {rating && (
              <button className="text-xs underline mt-1" style={{ color: "var(--color-accent)" }} onClick={() => updateParams((p) => p.delete("rating"))}>
                Clear
              </button>
            )}
          </FilterSection>

          <FilterSection title="Discount">
            {[10, 20, 30, 50].map((d) => (
              <label key={d} className="flex items-center gap-2 text-sm py-1 cursor-pointer">
                <input type="radio" name="discount" checked={discount === String(d)} onChange={() => updateParams((p) => p.set("discount", String(d)))} />
                {d}% off or more
              </label>
            ))}
            {discount && (
              <button className="text-xs underline mt-1" style={{ color: "var(--color-accent)" }} onClick={() => updateParams((p) => p.delete("discount"))}>
                Clear
              </button>
            )}
          </FilterSection>

          <button className="btn btn-outline btn-block mt-2 sm:hidden" onClick={() => setFiltersOpen(false)}>
            Show {total} results
          </button>
        </aside>

        <div>
          <div className="hidden sm:flex items-center justify-between mb-4">
            <div>
              <h1 className="text-xl font-semibold">{title}</h1>
              <p className="text-sm" style={{ color: "var(--color-ink-soft)" }}>{total} products</p>
            </div>
            <select
              className="input w-auto"
              value={sort}
              onChange={(e) => updateParams((p) => p.set("sort", e.target.value))}
              aria-label="Sort by"
            >
              <option value="relevance">Sort: Relevance</option>
              <option value="newest">Newest first</option>
              <option value="price-asc">Price: Low to High</option>
              <option value="price-desc">Price: High to Low</option>
              <option value="rating">Customer Rating</option>
              <option value="popularity">Popularity</option>
            </select>
          </div>
          <div className="sm:hidden mb-3">
            <select
              className="input"
              value={sort}
              onChange={(e) => updateParams((p) => p.set("sort", e.target.value))}
              aria-label="Sort by"
            >
              <option value="relevance">Sort: Relevance</option>
              <option value="newest">Newest first</option>
              <option value="price-asc">Price: Low to High</option>
              <option value="price-desc">Price: High to Low</option>
              <option value="rating">Customer Rating</option>
              <option value="popularity">Popularity</option>
            </select>
          </div>

          {loading ? (
            <ProductGridSkeleton count={8} />
          ) : items.length === 0 ? (
            <EmptyState
              title="No products match your filters"
              message="Try removing a filter or searching for something else."
              ctaHref="/products"
              ctaLabel="Clear filters"
            />
          ) : (
            <>
              <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3 sm:gap-4">
                {items.map((p) => (
                  <ProductCard key={p.id} product={p} />
                ))}
              </div>
              {totalPages > 1 && (
                <div className="flex justify-center gap-2 mt-8">
                  {Array.from({ length: totalPages }).map((_, i) => (
                    <button
                      key={i}
                      onClick={() => goToPage(i + 1)}
                      className="btn btn-sm"
                      style={{
                        background: page === i + 1 ? "var(--color-accent)" : "transparent",
                        color: page === i + 1 ? "#fff" : "var(--color-ink)",
                        border: "1px solid var(--color-border)",
                      }}
                    >
                      {i + 1}
                    </button>
                  ))}
                </div>
              )}
            </>
          )}
        </div>
      </div>
    </div>
  );
}

function FilterSection({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="mb-5 pb-5" style={{ borderBottom: "1px solid var(--color-border)" }}>
      <h3 className="text-sm font-bold mb-2">{title}</h3>
      {children}
    </div>
  );
}

export default function ProductsPage() {
  return (
    <Suspense fallback={<div className="container-page py-10"><ProductGridSkeleton /></div>}>
      <ProductsPageInner />
    </Suspense>
  );
}
