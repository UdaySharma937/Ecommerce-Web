"use client";

import { useEffect, useMemo, useState } from "react";
import { useParams, useRouter } from "next/navigation";
import Link from "next/link";
import { discountPct, formatINR, formatDate } from "@/lib/format";
import { StarRating } from "@/components/star-rating";
import { ProductCard, type ProductCardData } from "@/components/product-card";
import { ProductGridSkeleton } from "@/components/skeletons";
import { useToast } from "@/components/toast";
import type { ProductDetail, ReviewItem } from "@/lib/types";

export default function ProductDetailPage() {
  const { slug } = useParams<{ slug: string }>();
  const router = useRouter();
  const { show } = useToast();

  const [product, setProduct] = useState<ProductDetail | null>(null);
  const [loading, setLoading] = useState(true);
  const [activeImg, setActiveImg] = useState(0);
  const [size, setSize] = useState<string | null>(null);
  const [color, setColor] = useState<string | null>(null);
  const [adding, setAdding] = useState(false);
  const [pincode, setPincode] = useState("");
  const [pincodeResult, setPincodeResult] = useState<{ serviceable: boolean; etaText: string } | null>(null);
  const [related, setRelated] = useState<ProductCardData[]>([]);
  const [reviews, setReviews] = useState<ReviewItem[]>([]);
  const [breakdown, setBreakdown] = useState<Record<number, number>>({});
  const [canReview, setCanReview] = useState(false);
  const [hasReviewed, setHasReviewed] = useState(false);
  const [reviewForm, setReviewForm] = useState({ rating: 5, title: "", body: "" });
  const [submittingReview, setSubmittingReview] = useState(false);

  useEffect(() => {
    setLoading(true);
    fetch(`/api/products/${slug}`)
      .then((r) => (r.ok ? r.json() : Promise.reject()))
      .then((d) => setProduct(d.product))
      .catch(() => setProduct(null))
      .finally(() => setLoading(false));
    fetch(`/api/products/${slug}/related`).then((r) => r.json()).then((d) => setRelated(d.items || []));
    loadReviews();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [slug]);

  function loadReviews() {
    fetch(`/api/products/${slug}/reviews`)
      .then((r) => r.json())
      .then((d) => {
        setReviews(d.items || []);
        setBreakdown(d.breakdown || {});
        setCanReview(!!d.canReview);
        setHasReviewed(!!d.hasReviewed);
      });
  }

  const colors = useMemo(() => {
    if (!product) return [];
    return Array.from(new Map(product.variants.map((v) => [v.color, v])).values());
  }, [product]);

  const sizesForColor = useMemo(() => {
    if (!product) return [];
    return product.variants.filter((v) => !color || v.color === color);
  }, [product, color]);

  useEffect(() => {
    if (colors.length && !color) setColor(colors[0].color);
  }, [colors, color]);

  const selectedVariant = product?.variants.find((v) => v.color === color && v.size === size);

  async function handleAddToCart(buyNow = false) {
    if (!product) return;
    if (!color || !size) {
      show("Please select a size and color.", "error");
      return;
    }
    const variant = product.variants.find((v) => v.color === color && v.size === size);
    if (!variant || variant.stock < 1) {
      show("This size/color is out of stock.", "error");
      return;
    }
    setAdding(true);
    try {
      const res = await fetch("/api/cart", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ productId: product.id, variantId: variant.id, quantity: 1 }),
      });
      if (res.status === 401) {
        show("Please log in to continue.", "error");
        router.push("/login");
        return;
      }
      if (!res.ok) {
        const d = await res.json();
        show(d.error?.message || "Could not add to cart.", "error");
        return;
      }
      window.dispatchEvent(new Event("cart:updated"));
      show("Added to cart", "success");
      if (buyNow) router.push("/cart");
    } finally {
      setAdding(false);
    }
  }

  async function checkPincode() {
    if (!/^\d{6}$/.test(pincode)) {
      show("Enter a valid 6-digit pincode.", "error");
      return;
    }
    const res = await fetch(`/api/pincode/check?pincode=${pincode}`);
    const d = await res.json();
    if (!res.ok) {
      show(d.error?.message || "Could not check pincode.", "error");
      return;
    }
    setPincodeResult(d);
  }

  async function submitReview() {
    setSubmittingReview(true);
    try {
      const res = await fetch(`/api/products/${slug}/reviews`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(reviewForm),
      });
      const d = await res.json();
      if (!res.ok) {
        show(d.error?.message || "Could not submit review.", "error");
        return;
      }
      show("Thanks! Your review has been posted.", "success");
      setReviewForm({ rating: 5, title: "", body: "" });
      loadReviews();
    } finally {
      setSubmittingReview(false);
    }
  }

  async function deleteReview(id: number) {
    const res = await fetch(`/api/reviews/${id}`, { method: "DELETE" });
    if (res.ok) {
      show("Review deleted", "success");
      loadReviews();
    }
  }

  if (loading) {
    return (
      <div className="container-page py-10">
        <div className="grid sm:grid-cols-2 gap-8">
          <div className="skeleton aspect-[3/4] w-full" />
          <div className="flex flex-col gap-3">
            <div className="skeleton h-6 w-2/3" />
            <div className="skeleton h-4 w-1/3" />
            <div className="skeleton h-10 w-1/2" />
          </div>
        </div>
      </div>
    );
  }

  if (!product) {
    return (
      <div className="container-page py-16 text-center">
        <p className="text-lg font-semibold mb-2">Product not found</p>
        <Link href="/products" className="btn btn-primary">Browse products</Link>
      </div>
    );
  }

  const pct = discountPct(product.price, product.mrp);
  const totalReviews = Object.values(breakdown).reduce((a, b) => a + b, 0);

  return (
    <div className="container-page py-6">
      <nav className="text-xs mb-4" style={{ color: "var(--color-ink-soft)" }}>
        <Link href="/">Home</Link> / <Link href={`/products?category=${product.categorySlug || ""}`}>{product.categoryName}</Link> / {product.name}
      </nav>

      <div className="grid sm:grid-cols-2 gap-8">
        <div>
          <div className="rounded-xl overflow-hidden mb-3" style={{ background: "var(--color-accent-soft)" }}>
            {product.images[activeImg] ? (
              // eslint-disable-next-line @next/next/no-img-element
              <img
                src={product.images[activeImg].url}
                alt={product.name}
                className="w-full aspect-[3/4] object-cover transition-transform duration-300 hover:scale-110"
              />
            ) : (
              <div className="w-full aspect-[3/4] flex items-center justify-center">No image</div>
            )}
          </div>
          <div className="flex gap-2 overflow-x-auto">
            {product.images.map((img, i) => (
              <button
                key={img.id}
                onClick={() => setActiveImg(i)}
                className="shrink-0 h-16 w-16 rounded-lg overflow-hidden"
                style={{ border: i === activeImg ? "2px solid var(--color-accent)" : "1px solid var(--color-border)" }}
              >
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img src={img.url} alt="" className="h-full w-full object-cover" />
              </button>
            ))}
          </div>
        </div>

        <div>
          <span className="text-xs font-bold uppercase tracking-wide" style={{ color: "var(--color-ink-soft)" }}>{product.brand}</span>
          <h1 className="text-2xl font-semibold mt-1 mb-2" style={{ fontFamily: "var(--font-display)" }}>{product.name}</h1>
          {Number(product.ratingCount) > 0 && (
            <div className="flex items-center gap-2 mb-3">
              <StarRating value={parseFloat(product.ratingAvg)} />
              <span className="text-sm" style={{ color: "var(--color-ink-soft)" }}>
                {product.ratingAvg} ({product.ratingCount} reviews)
              </span>
            </div>
          )}

          <div className="flex items-baseline gap-3 mb-4">
            <span className="text-2xl font-bold">{formatINR(product.price)}</span>
            {pct > 0 && (
              <>
                <span className="line-through text-base" style={{ color: "var(--color-ink-soft)" }}>{formatINR(product.mrp)}</span>
                <span className="badge badge-accent">{pct}% off</span>
              </>
            )}
          </div>

          <div className="mb-4">
            <div className="text-sm font-semibold mb-2">Color: {color}</div>
            <div className="flex gap-2">
              {colors.map((c) => (
                <button
                  key={c.color}
                  onClick={() => { setColor(c.color); setSize(null); }}
                  className="h-9 w-9 rounded-full"
                  style={{ background: c.colorHex, border: color === c.color ? "3px solid var(--color-accent)" : "1px solid var(--color-border)" }}
                  aria-label={c.color}
                  aria-pressed={color === c.color}
                />
              ))}
            </div>
          </div>

          <div className="mb-5">
            <div className="text-sm font-semibold mb-2">Select size</div>
            <div className="flex flex-wrap gap-2">
              {sizesForColor.map((v) => (
                <button
                  key={v.id}
                  disabled={v.stock < 1}
                  onClick={() => setSize(v.size)}
                  className="btn btn-sm"
                  style={{
                    border: "1px solid var(--color-border)",
                    background: size === v.size ? "var(--color-ink)" : "transparent",
                    color: size === v.size ? "var(--color-bg)" : "var(--color-ink)",
                    opacity: v.stock < 1 ? 0.4 : 1,
                    textDecoration: v.stock < 1 ? "line-through" : "none",
                  }}
                >
                  {v.size}
                </button>
              ))}
            </div>
            {selectedVariant && selectedVariant.stock > 0 && selectedVariant.stock <= 5 && (
              <p className="text-xs mt-2" style={{ color: "var(--color-danger)" }}>Only {selectedVariant.stock} left!</p>
            )}
          </div>

          <div className="flex gap-3 mb-6">
            <button className="btn btn-outline flex-1" disabled={adding} onClick={() => handleAddToCart(false)}>
              Add to Cart
            </button>
            <button className="btn btn-primary flex-1" disabled={adding} onClick={() => handleAddToCart(true)}>
              Buy Now
            </button>
          </div>

          <div className="card p-4 mb-6">
            <div className="text-sm font-semibold mb-2">Check delivery availability</div>
            <div className="flex gap-2">
              <input className="input" placeholder="Enter pincode" value={pincode} maxLength={6} onChange={(e) => setPincode(e.target.value.replace(/\D/g, ""))} />
              <button className="btn btn-outline" onClick={checkPincode}>Check</button>
            </div>
            {pincodeResult && (
              <p className="text-sm mt-2" style={{ color: pincodeResult.serviceable ? "var(--color-success)" : "var(--color-danger)" }}>
                {pincodeResult.etaText}
              </p>
            )}
          </div>

          <div>
            <h2 className="font-semibold mb-2">Product details</h2>
            <p className="text-sm leading-relaxed whitespace-pre-line" style={{ color: "var(--color-ink-soft)" }}>{product.description}</p>
          </div>
        </div>
      </div>

      {/* Reviews */}
      <section className="mt-12">
        <h2 className="text-xl font-semibold mb-4" style={{ fontFamily: "var(--font-display)" }}>Ratings &amp; Reviews</h2>
        <div className="grid sm:grid-cols-[260px_1fr] gap-8">
          <div className="card p-5">
            <div className="flex items-center gap-3 mb-4">
              <span className="text-3xl font-bold">{product.ratingAvg}</span>
              <div>
                <StarRating value={parseFloat(product.ratingAvg)} />
                <div className="text-xs" style={{ color: "var(--color-ink-soft)" }}>{totalReviews} reviews</div>
              </div>
            </div>
            {[5, 4, 3, 2, 1].map((n) => {
              const count = breakdown[n] || 0;
              const pctBar = totalReviews ? (count / totalReviews) * 100 : 0;
              return (
                <div key={n} className="flex items-center gap-2 text-xs mb-1.5">
                  <span className="w-8">{n}★</span>
                  <div className="flex-1 h-2 rounded-full" style={{ background: "var(--color-border)" }}>
                    <div className="h-2 rounded-full" style={{ width: `${pctBar}%`, background: "var(--color-gold)" }} />
                  </div>
                  <span className="w-6 text-right">{count}</span>
                </div>
              );
            })}

            {canReview && (
              <div className="mt-5 pt-5" style={{ borderTop: "1px solid var(--color-border)" }}>
                <div className="text-sm font-semibold mb-2">Write a review</div>
                <div className="flex gap-1 mb-2">
                  {[1, 2, 3, 4, 5].map((n) => (
                    <button key={n} onClick={() => setReviewForm((f) => ({ ...f, rating: n }))} aria-label={`${n} star`}>
                      <svg width="22" height="22" viewBox="0 0 24 24" fill={reviewForm.rating >= n ? "var(--color-gold)" : "var(--color-border)"}>
                        <path d="M12 2l2.9 6.3 6.9.8-5.1 4.8 1.4 6.9-6.1-3.5-6.1 3.5 1.4-6.9-5.1-4.8 6.9-.8z" />
                      </svg>
                    </button>
                  ))}
                </div>
                <input className="input mb-2" placeholder="Review title" value={reviewForm.title} onChange={(e) => setReviewForm((f) => ({ ...f, title: e.target.value }))} />
                <textarea className="input mb-2" rows={3} placeholder="Share your experience" value={reviewForm.body} onChange={(e) => setReviewForm((f) => ({ ...f, body: e.target.value }))} />
                <button className="btn btn-primary btn-block" disabled={submittingReview} onClick={submitReview}>
                  Submit review
                </button>
              </div>
            )}
            {hasReviewed && <p className="text-xs mt-4" style={{ color: "var(--color-success)" }}>You've already reviewed this product.</p>}
            {!canReview && !hasReviewed && (
              <p className="text-xs mt-4" style={{ color: "var(--color-ink-soft)" }}>Only customers with a delivered order can write a review.</p>
            )}
          </div>

          <div className="flex flex-col gap-4">
            {reviews.length === 0 && (
              <p className="text-sm" style={{ color: "var(--color-ink-soft)" }}>No reviews yet. Be the first to review this product.</p>
            )}
            {reviews.map((r) => (
              <div key={r.id} className="card p-4">
                <div className="flex items-center justify-between mb-1">
                  <StarRating value={r.rating} />
                  <span className="text-xs" style={{ color: "var(--color-ink-soft)" }}>{formatDate(r.createdAt)}</span>
                </div>
                {r.title && <div className="font-semibold text-sm mt-1">{r.title}</div>}
                {r.body && <p className="text-sm mt-1" style={{ color: "var(--color-ink-soft)" }}>{r.body}</p>}
                <div className="text-xs mt-2 font-medium">{r.userName || "Verified buyer"}</div>
                {r.canEdit && (
                  <button className="text-xs mt-2 underline" style={{ color: "var(--color-danger)" }} onClick={() => deleteReview(r.id)}>
                    Delete my review
                  </button>
                )}
              </div>
            ))}
          </div>
        </div>
      </section>

      {related.length > 0 && (
        <section className="mt-12">
          <h2 className="text-xl font-semibold mb-4" style={{ fontFamily: "var(--font-display)" }}>You may also like</h2>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            {related.map((p) => (
              <ProductCard key={p.id} product={p} />
            ))}
          </div>
        </section>
      )}
    </div>
  );
}
