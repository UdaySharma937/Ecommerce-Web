"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { useCurrentUser } from "@/lib/use-current-user";
import { useToast } from "@/components/toast";

export default function SettingsPage() {
  const { user } = useCurrentUser();
  const router = useRouter();
  const { show } = useToast();
  const [dark, setDark] = useState(false);
  const [notifOrders, setNotifOrders] = useState(true);
  const [notifPromo, setNotifPromo] = useState(false);

  useEffect(() => {
    const saved = localStorage.getItem("vh-theme");
    setDark(saved === "dark");
  }, []);

  function toggleTheme() {
    const next = !dark;
    setDark(next);
    document.documentElement.setAttribute("data-theme", next ? "dark" : "light");
    localStorage.setItem("vh-theme", next ? "dark" : "light");
  }

  async function logout() {
    await fetch("/api/auth/logout", { method: "POST" });
    show("Logged out", "success");
    router.push("/");
    router.refresh();
  }

  async function deleteAccount() {
    if (!confirm("This will permanently delete your account. Continue?")) return;
    show("Account deletion requested. Our team will process this within 48 hours.", "info");
  }

  return (
    <div className="container-page py-6 max-w-2xl">
      <h1 className="text-xl font-semibold mb-5">Settings</h1>

      <div className="card p-5 mb-5">
        <h2 className="font-semibold mb-3 text-sm">Appearance</h2>
        <ToggleRow label="Dark theme" description="Easier on the eyes at night" checked={dark} onChange={toggleTheme} />
      </div>

      <div className="card p-5 mb-5">
        <h2 className="font-semibold mb-3 text-sm">Notifications</h2>
        <ToggleRow label="Order updates" description="Get notified about order status changes" checked={notifOrders} onChange={() => setNotifOrders((v) => !v)} />
        <ToggleRow label="Promotions &amp; offers" description="Sales, new arrivals and coupon alerts" checked={notifPromo} onChange={() => setNotifPromo((v) => !v)} />
      </div>

      <div className="card p-5 mb-5">
        <h2 className="font-semibold mb-3 text-sm">Language</h2>
        <select className="input" defaultValue="en">
          <option value="en">English</option>
          <option value="hi">हिंदी (coming soon)</option>
          <option value="ta">தமிழ் (coming soon)</option>
        </select>
      </div>

      <div className="card p-5 mb-5">
        <h2 className="font-semibold mb-3 text-sm">Help &amp; Legal</h2>
        <div className="flex flex-col gap-2 text-sm">
          <Link href="#" className="hover:underline">Privacy Policy</Link>
          <Link href="#" className="hover:underline">Terms of Service</Link>
          <Link href="#" className="hover:underline">Returns &amp; Refunds</Link>
          <Link href="#" className="hover:underline">Contact Support</Link>
        </div>
      </div>

      <div className="card p-5">
        {user ? (
          <>
            <button className="btn btn-outline btn-block mb-3" onClick={logout}>Log out</button>
            <button className="text-xs underline" style={{ color: "var(--color-danger)" }} onClick={deleteAccount}>
              Delete my account
            </button>
          </>
        ) : (
          <Link href="/login" className="btn btn-primary btn-block">Login / Register</Link>
        )}
      </div>
    </div>
  );
}

function ToggleRow({ label, description, checked, onChange }: { label: string; description: string; checked: boolean; onChange: () => void }) {
  return (
    <div className="flex items-center justify-between py-2">
      <div>
        <div className="text-sm font-medium">{label}</div>
        <div className="text-xs" style={{ color: "var(--color-ink-soft)" }}>{description}</div>
      </div>
      <button
        role="switch"
        aria-checked={checked}
        onClick={onChange}
        className="h-6 w-11 rounded-full relative transition-colors"
        style={{ background: checked ? "var(--color-accent)" : "var(--color-border)" }}
      >
        <span className="absolute top-0.5 h-5 w-5 rounded-full bg-white transition-all" style={{ left: checked ? 22 : 2 }} />
      </button>
    </div>
  );
}
