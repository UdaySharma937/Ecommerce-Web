"use client";

import { Suspense } from "react";
import Link from "next/link";
import { useSearchParams } from "next/navigation";

function SuccessInner() {
  const searchParams = useSearchParams();
  const order = searchParams.get("order");

  return (
    <div className="container-page py-16 flex flex-col items-center text-center">
      <div
        className="h-16 w-16 rounded-full flex items-center justify-center mb-4"
        style={{ background: "var(--color-success-soft)" }}
      >
        <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="var(--color-success)" strokeWidth="3">
          <path d="M5 13l4 4L19 7" />
        </svg>
      </div>
      <h1 className="text-2xl font-semibold mb-2" style={{ fontFamily: "var(--font-display)" }}>
        Order placed successfully!
      </h1>
      <p style={{ color: "var(--color-ink-soft)" }} className="mb-1">
        Your order number is
      </p>
      <p className="font-mono font-bold text-lg mb-6">{order}</p>
      <p style={{ color: "var(--color-ink-soft)" }} className="max-w-md mb-6 text-sm">
        We've sent the order confirmation to your account. You can track delivery status anytime from your Orders page.
      </p>
      <div className="flex gap-3">
        <Link href="/orders" className="btn btn-primary">Track my order</Link>
        <Link href="/products" className="btn btn-outline">Continue shopping</Link>
      </div>
    </div>
  );
}

export default function CheckoutSuccessPage() {
  return (
    <Suspense fallback={null}>
      <SuccessInner />
    </Suspense>
  );
}
