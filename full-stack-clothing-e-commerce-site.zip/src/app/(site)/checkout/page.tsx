"use client";

import { Suspense, useEffect, useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { formatINR } from "@/lib/format";
import { useToast } from "@/components/toast";
import type { Address, CartLine } from "@/lib/types";

function CheckoutInner() {
  const [addresses, setAddresses] = useState<Address[]>([]);
  const [items, setItems] = useState<CartLine[]>([]);
  const [selectedAddress, setSelectedAddress] = useState<number | null>(null);
  const [paymentMethod, setPaymentMethod] = useState<"COD" | "ONLINE">("COD");
  const [showForm, setShowForm] = useState(false);
  const [placing, setPlacing] = useState(false);
  const [form, setForm] = useState({
    label: "Home",
    fullName: "",
    phone: "",
    line1: "",
    line2: "",
    city: "",
    state: "",
    pincode: "",
  });
  const { show } = useToast();
  const router = useRouter();
  const searchParams = useSearchParams();
  const couponCode = searchParams.get("coupon") || "";
  const [discount, setDiscount] = useState(0);

  function loadAddresses() {
    fetch("/api/addresses")
      .then((r) => r.json())
      .then((d) => {
        setAddresses(d.items || []);
        const def = d.items?.find((a: Address) => a.isDefault) || d.items?.[0];
        if (def) setSelectedAddress(def.id);
        if (!d.items?.length) setShowForm(true);
      });
  }

  useEffect(() => {
    fetch("/api/cart").then((r) => r.json()).then((d) => setItems(d.items || []));
    loadAddresses();
  }, []);

  const subtotal = items.reduce((s, i) => s + parseFloat(i.product.price) * i.quantity, 0);

  useEffect(() => {
    if (!couponCode) return;
    fetch("/api/coupons/apply", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ code: couponCode, subtotal }),
    })
      .then((r) => r.json())
      .then((d) => d.discount && setDiscount(d.discount));
  }, [couponCode, subtotal]);

  const deliveryFee = subtotal - discount >= 999 || items.length === 0 ? 0 : 49;
  const total = Math.max(0, Math.round(subtotal - discount + deliveryFee));

  async function saveAddress() {
    if (!form.fullName || !form.phone || !form.line1 || !form.city || !form.state || !/^\d{6}$/.test(form.pincode)) {
      show("Please fill all address fields correctly.", "error");
      return;
    }
    const res = await fetch("/api/addresses", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(form),
    });
    const d = await res.json();
    if (!res.ok) {
      show(d.error?.message || "Could not save address.", "error");
      return;
    }
    show("Address saved", "success");
    setShowForm(false);
    setForm({ label: "Home", fullName: "", phone: "", line1: "", line2: "", city: "", state: "", pincode: "" });
    loadAddresses();
  }

  async function placeOrder() {
    if (!selectedAddress) {
      show("Please select or add a delivery address.", "error");
      return;
    }
    setPlacing(true);
    try {
      const res = await fetch("/api/orders", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ addressId: selectedAddress, paymentMethod, couponCode: couponCode || undefined }),
      });
      const d = await res.json();
      if (!res.ok) {
        show(d.error?.message || "Could not place order.", "error");
        return;
      }
      window.dispatchEvent(new Event("cart:updated"));
      router.push(`/checkout/success?order=${d.order.orderNumber}`);
    } finally {
      setPlacing(false);
    }
  }

  if (items.length === 0) {
    return (
      <div className="container-page py-16 text-center">
        <p className="mb-4">Your cart is empty.</p>
        <button className="btn btn-primary" onClick={() => router.push("/products")}>Shop now</button>
      </div>
    );
  }

  return (
    <div className="container-page py-6">
      <h1 className="text-xl font-semibold mb-5">Checkout</h1>
      <div className="grid lg:grid-cols-[1fr_340px] gap-6">
        <div className="flex flex-col gap-6">
          <section className="card p-4">
            <h2 className="font-semibold mb-3">1. Delivery Address</h2>
            <div className="flex flex-col gap-2">
              {addresses.map((a) => (
                <label key={a.id} className="flex gap-3 p-3 rounded-lg cursor-pointer" style={{ border: selectedAddress === a.id ? "2px solid var(--color-accent)" : "1px solid var(--color-border)" }}>
                  <input type="radio" name="address" checked={selectedAddress === a.id} onChange={() => setSelectedAddress(a.id)} className="mt-1" />
                  <div className="text-sm">
                    <span className="badge badge-gold mr-2">{a.label}</span>
                    <span className="font-semibold">{a.fullName}</span> · {a.phone}
                    <div style={{ color: "var(--color-ink-soft)" }}>
                      {a.line1}, {a.line2 ? `${a.line2}, ` : ""}{a.city}, {a.state} - {a.pincode}
                    </div>
                  </div>
                </label>
              ))}
            </div>
            {!showForm && (
              <button className="btn btn-outline btn-sm mt-3" onClick={() => setShowForm(true)}>+ Add new address</button>
            )}
            {showForm && (
              <div className="mt-4 grid sm:grid-cols-2 gap-3">
                <input className="input" placeholder="Full name" value={form.fullName} onChange={(e) => setForm((f) => ({ ...f, fullName: e.target.value }))} />
                <input className="input" placeholder="Phone number" value={form.phone} onChange={(e) => setForm((f) => ({ ...f, phone: e.target.value }))} />
                <input className="input sm:col-span-2" placeholder="Address line 1 (house no., street)" value={form.line1} onChange={(e) => setForm((f) => ({ ...f, line1: e.target.value }))} />
                <input className="input sm:col-span-2" placeholder="Address line 2 (optional)" value={form.line2} onChange={(e) => setForm((f) => ({ ...f, line2: e.target.value }))} />
                <input className="input" placeholder="City" value={form.city} onChange={(e) => setForm((f) => ({ ...f, city: e.target.value }))} />
                <input className="input" placeholder="State" value={form.state} onChange={(e) => setForm((f) => ({ ...f, state: e.target.value }))} />
                <input className="input" placeholder="Pincode" value={form.pincode} maxLength={6} onChange={(e) => setForm((f) => ({ ...f, pincode: e.target.value.replace(/\D/g, "") }))} />
                <select className="input" value={form.label} onChange={(e) => setForm((f) => ({ ...f, label: e.target.value }))}>
                  <option>Home</option>
                  <option>Work</option>
                  <option>Other</option>
                </select>
                <div className="sm:col-span-2 flex gap-2">
                  <button className="btn btn-primary" onClick={saveAddress}>Save address</button>
                  {addresses.length > 0 && <button className="btn btn-ghost" onClick={() => setShowForm(false)}>Cancel</button>}
                </div>
              </div>
            )}
          </section>

          <section className="card p-4">
            <h2 className="font-semibold mb-3">2. Payment Method</h2>
            <label className="flex items-center gap-3 p-3 rounded-lg cursor-pointer mb-2" style={{ border: paymentMethod === "COD" ? "2px solid var(--color-accent)" : "1px solid var(--color-border)" }}>
              <input type="radio" name="payment" checked={paymentMethod === "COD"} onChange={() => setPaymentMethod("COD")} />
              <div className="text-sm">
                <div className="font-semibold">Cash on Delivery</div>
                <div style={{ color: "var(--color-ink-soft)" }}>Pay with cash when your order arrives</div>
              </div>
            </label>
            <label className="flex items-center gap-3 p-3 rounded-lg cursor-pointer" style={{ border: paymentMethod === "ONLINE" ? "2px solid var(--color-accent)" : "1px solid var(--color-border)" }}>
              <input type="radio" name="payment" checked={paymentMethod === "ONLINE"} onChange={() => setPaymentMethod("ONLINE")} />
              <div className="text-sm">
                <div className="font-semibold">Pay Online (Razorpay — test mode)</div>
                <div style={{ color: "var(--color-ink-soft)" }}>UPI, cards &amp; netbanking. Simulated for this demo store.</div>
              </div>
            </label>
          </section>

          <section className="card p-4">
            <h2 className="font-semibold mb-3">3. Order Items ({items.length})</h2>
            <div className="flex flex-col gap-3">
              {items.map((item) => (
                <div key={item.id} className="flex gap-3 items-center text-sm">
                  {item.product.image && (
                    // eslint-disable-next-line @next/next/no-img-element
                    <img src={item.product.image} alt="" className="h-14 w-12 object-cover rounded-md" />
                  )}
                  <div className="flex-1">
                    <div className="font-medium">{item.product.name}</div>
                    <div style={{ color: "var(--color-ink-soft)" }}>{item.variant.size} · {item.variant.color} · Qty {item.quantity}</div>
                  </div>
                  <div className="font-semibold">{formatINR(parseFloat(item.product.price) * item.quantity)}</div>
                </div>
              ))}
            </div>
          </section>
        </div>

        <div className="card p-4 h-fit">
          <h2 className="font-semibold mb-3">Order Summary</h2>
          <div className="flex justify-between text-sm mb-1.5">
            <span>Subtotal</span>
            <span>{formatINR(subtotal)}</span>
          </div>
          {discount > 0 && (
            <div className="flex justify-between text-sm mb-1.5" style={{ color: "var(--color-success)" }}>
              <span>Coupon ({couponCode})</span>
              <span>−{formatINR(discount)}</span>
            </div>
          )}
          <div className="flex justify-between text-sm mb-1.5">
            <span>Delivery</span>
            <span>{deliveryFee === 0 ? "FREE" : formatINR(deliveryFee)}</span>
          </div>
          <div className="flex justify-between font-bold text-base pt-3 mt-2" style={{ borderTop: "1px dashed var(--color-border)" }}>
            <span>Total Payable</span>
            <span>{formatINR(total)}</span>
          </div>
          <button className="btn btn-primary btn-block mt-4" disabled={placing} onClick={placeOrder}>
            {placing ? "Placing order..." : paymentMethod === "COD" ? "Place Order" : `Pay ${formatINR(total)}`}
          </button>
        </div>
      </div>
    </div>
  );
}

export default function CheckoutPage() {
  return (
    <Suspense fallback={<div className="container-page py-10">Loading...</div>}>
      <CheckoutInner />
    </Suspense>
  );
}
