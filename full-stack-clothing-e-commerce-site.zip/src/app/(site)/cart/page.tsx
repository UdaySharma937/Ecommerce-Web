"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { formatINR } from "@/lib/format";
import { EmptyState } from "@/components/empty-state";
import { useToast } from "@/components/toast";
import type { CartLine } from "@/lib/types";

export default function CartPage() {
  const [items, setItems] = useState<CartLine[]>([]);
  const [loading, setLoading] = useState(true);
  const [coupon, setCoupon] = useState("");
  const [applied, setApplied] = useState<{ code: string; discount: number } | null>(null);
  const [applying, setApplying] = useState(false);
  const { show } = useToast();
  const router = useRouter();

  function load() {
    setLoading(true);
    fetch("/api/cart")
      .then((r) => r.json())
      .then((d) => setItems(d.items || []))
      .finally(() => setLoading(false));
  }

  useEffect(load, []);

  const subtotal = items.reduce((s, i) => s + parseFloat(i.product.price) * i.quantity, 0);
  const mrpTotal = items.reduce((s, i) => s + parseFloat(i.product.mrp) * i.quantity, 0);
  const savings = mrpTotal - subtotal;
  const discount = applied?.discount || 0;
  const deliveryFee = subtotal - discount >= 999 || items.length === 0 ? 0 : 49;
  const total = Math.max(0, Math.round(subtotal - discount + deliveryFee));

  async function updateQty(id: number, quantity: number) {
    if (quantity < 1) return;
    await fetch(`/api/cart/${id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ quantity }),
    });
    window.dispatchEvent(new Event("cart:updated"));
    load();
  }

  async function removeItem(id: number) {
    await fetch(`/api/cart/${id}`, { method: "DELETE" });
    window.dispatchEvent(new Event("cart:updated"));
    show("Removed from cart", "success");
    load();
  }

  async function applyCoupon() {
    if (!coupon.trim()) return;
    setApplying(true);
    try {
      const res = await fetch("/api/coupons/apply", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ code: coupon, subtotal }),
      });
      const d = await res.json();
      if (!res.ok) {
        show(d.error?.message || "Invalid coupon", "error");
        setApplied(null);
        return;
      }
      setApplied({ code: d.code, discount: d.discount });
      show(`Coupon ${d.code} applied!`, "success");
    } finally {
      setApplying(false);
    }
  }

  if (loading) {
    return <div className="container-page py-10"><div className="skeleton h-40 w-full" /></div>;
  }

  if (items.length === 0) {
    return (
      <EmptyState
        title="Your cart is empty"
        message="Looks like you haven't added anything yet. Explore our collection and find something you'll love."
        ctaHref="/products"
        ctaLabel="Start shopping"
      />
    );
  }

  return (
    <div className="container-page py-6">
      <h1 className="text-xl font-semibold mb-5">My Cart ({items.length})</h1>
      <div className="grid lg:grid-cols-[1fr_340px] gap-6">
        <div className="flex flex-col gap-3">
          {items.map((item) => (
            <div key={item.id} className="card p-3 flex gap-3">
              <Link href={`/products/${item.product.slug}`} className="shrink-0">
                {item.product.image ? (
                  // eslint-disable-next-line @next/next/no-img-element
                  <img src={item.product.image} alt={item.product.name} className="h-24 w-20 object-cover rounded-lg" />
                ) : (
                  <div className="h-24 w-20 rounded-lg" style={{ background: "var(--color-accent-soft)" }} />
                )}
              </Link>
              <div className="flex-1">
                <Link href={`/products/${item.product.slug}`} className="font-medium text-sm hover:underline">
                  {item.product.name}
                </Link>
                <div className="text-xs mt-1" style={{ color: "var(--color-ink-soft)" }}>
                  Size: {item.variant.size} · Color: {item.variant.color}
                </div>
                <div className="flex items-baseline gap-2 mt-1">
                  <span className="font-semibold">{formatINR(item.product.price)}</span>
                  <span className="text-xs line-through" style={{ color: "var(--color-ink-soft)" }}>{formatINR(item.product.mrp)}</span>
                </div>
                <div className="flex items-center justify-between mt-2">
                  <div className="flex items-center gap-2">
                    <button className="btn btn-outline btn-sm" onClick={() => updateQty(item.id, item.quantity - 1)} aria-label="Decrease quantity">−</button>
                    <span className="w-6 text-center text-sm">{item.quantity}</span>
                    <button className="btn btn-outline btn-sm" onClick={() => updateQty(item.id, item.quantity + 1)} disabled={item.quantity >= item.variant.stock} aria-label="Increase quantity">+</button>
                  </div>
                  <button className="text-xs underline" style={{ color: "var(--color-danger)" }} onClick={() => removeItem(item.id)}>
                    Remove
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="card p-4 h-fit">
          <div className="mb-3">
            <div className="text-sm font-semibold mb-2">Have a coupon?</div>
            <div className="flex gap-2">
              <input className="input" placeholder="Enter code e.g. WELCOME100" value={coupon} onChange={(e) => setCoupon(e.target.value)} />
              <button className="btn btn-outline" disabled={applying} onClick={applyCoupon}>Apply</button>
            </div>
            {applied && (
              <p className="text-xs mt-2" style={{ color: "var(--color-success)" }}>
                "{applied.code}" applied — you saved {formatINR(applied.discount)}
              </p>
            )}
          </div>
          <h2 className="font-semibold mb-3">Price Details</h2>
          <div className="flex justify-between text-sm mb-1.5">
            <span>Price ({items.length} items)</span>
            <span>{formatINR(mrpTotal)}</span>
          </div>
          <div className="flex justify-between text-sm mb-1.5" style={{ color: "var(--color-success)" }}>
            <span>Discount</span>
            <span>−{formatINR(savings)}</span>
          </div>
          {discount > 0 && (
            <div className="flex justify-between text-sm mb-1.5" style={{ color: "var(--color-success)" }}>
              <span>Coupon discount</span>
              <span>−{formatINR(discount)}</span>
            </div>
          )}
          <div className="flex justify-between text-sm mb-1.5">
            <span>Delivery</span>
            <span>{deliveryFee === 0 ? "FREE" : formatINR(deliveryFee)}</span>
          </div>
          <div className="flex justify-between font-bold text-base pt-3 mt-2" style={{ borderTop: "1px dashed var(--color-border)" }}>
            <span>Total Amount</span>
            <span>{formatINR(total)}</span>
          </div>
          <button
            className="btn btn-primary btn-block mt-4"
            onClick={() => router.push(`/checkout${applied ? `?coupon=${applied.code}` : ""}`)}
          >
            Proceed to Checkout
          </button>
        </div>
      </div>
    </div>
  );
}
