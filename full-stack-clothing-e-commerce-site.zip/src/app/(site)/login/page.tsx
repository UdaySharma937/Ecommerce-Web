"use client";

import { Suspense, useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { useToast } from "@/components/toast";

type Tab = "email" | "phone" | "google";

function LoginInner() {
  const [tab, setTab] = useState<Tab>("email");
  const router = useRouter();
  const searchParams = useSearchParams();
  const { show } = useToast();

  function onSuccess() {
    show("Welcome to Vastrahaus!", "success");
    router.push(searchParams.get("next") || "/");
    router.refresh();
  }

  return (
    <div className="container-page py-10 flex justify-center">
      <div className="card w-full max-w-md p-6">
        <div className="text-center mb-6">
          <h1 style={{ fontFamily: "var(--font-display)", color: "var(--color-accent)" }} className="text-2xl font-bold mb-1">
            Vastrahaus
          </h1>
          <p className="text-sm" style={{ color: "var(--color-ink-soft)" }}>Login or create an account to continue</p>
        </div>

        <div className="flex mb-6 rounded-lg overflow-hidden" style={{ border: "1px solid var(--color-border)" }}>
          {(["email", "phone", "google"] as Tab[]).map((t) => (
            <button
              key={t}
              onClick={() => setTab(t)}
              className="flex-1 py-2 text-sm font-semibold capitalize"
              style={{
                background: tab === t ? "var(--color-ink)" : "transparent",
                color: tab === t ? "var(--color-bg)" : "var(--color-ink)",
              }}
            >
              {t}
            </button>
          ))}
        </div>

        {tab === "email" && <EmailTab onSuccess={onSuccess} show={show} />}
        {tab === "phone" && <PhoneTab onSuccess={onSuccess} show={show} />}
        {tab === "google" && <GoogleTab onSuccess={onSuccess} show={show} />}

        <p className="text-xs text-center mt-6" style={{ color: "var(--color-ink-soft)" }}>
          By continuing, you agree to Vastrahaus's Terms of Use and Privacy Policy.
        </p>
      </div>
    </div>
  );
}

type ShowFn = (message: string, kind?: "info" | "success" | "error") => void;

function EmailTab({ onSuccess, show }: { onSuccess: () => void; show: ShowFn }) {
  const [mode, setMode] = useState<"password" | "otp">("password");
  const [isRegister, setIsRegister] = useState(false);
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);
  const [otpSent, setOtpSent] = useState(false);
  const [otp, setOtp] = useState("");
  const [devOtp, setDevOtp] = useState("");

  async function submitPassword(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    try {
      const url = isRegister ? "/api/auth/register" : "/api/auth/login";
      const body = isRegister ? { name, email, password } : { email, password };
      const res = await fetch(url, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });
      const d = await res.json();
      if (!res.ok) {
        show(d.error?.message || "Something went wrong.", "error");
        return;
      }
      onSuccess();
    } finally {
      setBusy(false);
    }
  }

  async function sendOtp() {
    if (!/^\S+@\S+\.\S+$/.test(email)) {
      show("Enter a valid email address.", "error");
      return;
    }
    setBusy(true);
    try {
      const res = await fetch("/api/auth/otp/request", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ identifier: email, purpose: "login" }),
      });
      const d = await res.json();
      if (!res.ok) {
        show(d.error?.message || "Could not send OTP.", "error");
        return;
      }
      setOtpSent(true);
      setDevOtp(d.devOtp || "");
      show(d.message, "success");
    } finally {
      setBusy(false);
    }
  }

  async function verifyOtp() {
    setBusy(true);
    try {
      const res = await fetch("/api/auth/otp/verify", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ identifier: email, code: otp, purpose: "login", name }),
      });
      const d = await res.json();
      if (!res.ok) {
        show(d.error?.message || "Invalid code.", "error");
        return;
      }
      onSuccess();
    } finally {
      setBusy(false);
    }
  }

  return (
    <div>
      <div className="flex gap-2 mb-4">
        <button className="text-xs font-semibold underline" onClick={() => setMode("password")} style={{ color: mode === "password" ? "var(--color-accent)" : "var(--color-ink-soft)" }}>Password</button>
        <span>·</span>
        <button className="text-xs font-semibold underline" onClick={() => setMode("otp")} style={{ color: mode === "otp" ? "var(--color-accent)" : "var(--color-ink-soft)" }}>OTP login</button>
      </div>

      {mode === "password" ? (
        <form onSubmit={submitPassword} className="flex flex-col gap-3">
          {isRegister && (
            <div>
              <label className="label" htmlFor="name">Full name</label>
              <input id="name" className="input" value={name} onChange={(e) => setName(e.target.value)} required />
            </div>
          )}
          <div>
            <label className="label" htmlFor="email">Email</label>
            <input id="email" type="email" className="input" value={email} onChange={(e) => setEmail(e.target.value)} required />
          </div>
          <div>
            <label className="label" htmlFor="password">Password</label>
            <input id="password" type="password" className="input" value={password} onChange={(e) => setPassword(e.target.value)} required minLength={6} />
          </div>
          <button className="btn btn-primary btn-block" disabled={busy}>
            {isRegister ? "Create account" : "Login"}
          </button>
          <button type="button" className="text-xs underline" onClick={() => setIsRegister((v) => !v)}>
            {isRegister ? "Already have an account? Login" : "New here? Create an account"}
          </button>
        </form>
      ) : (
        <div className="flex flex-col gap-3">
          <div>
            <label className="label" htmlFor="otp-email">Email</label>
            <input id="otp-email" type="email" className="input" value={email} onChange={(e) => setEmail(e.target.value)} disabled={otpSent} />
          </div>
          {!otpSent ? (
            <button className="btn btn-primary btn-block" disabled={busy} onClick={sendOtp}>Send OTP</button>
          ) : (
            <>
              <div>
                <label className="label" htmlFor="otp-name">Your name (for new accounts)</label>
                <input id="otp-name" className="input" value={name} onChange={(e) => setName(e.target.value)} placeholder="Optional" />
              </div>
              <div>
                <label className="label" htmlFor="code">6-digit code</label>
                <input id="code" className="input" value={otp} maxLength={6} onChange={(e) => setOtp(e.target.value.replace(/\D/g, ""))} />
                {devOtp && (
                  <p className="text-xs mt-1" style={{ color: "var(--color-ink-soft)" }}>
                    Sandbox mode (no SMTP configured): your code is <strong>{devOtp}</strong>
                  </p>
                )}
              </div>
              <button className="btn btn-primary btn-block" disabled={busy || otp.length !== 6} onClick={verifyOtp}>Verify &amp; continue</button>
              <button className="text-xs underline" onClick={sendOtp}>Resend code</button>
            </>
          )}
        </div>
      )}
    </div>
  );
}

function PhoneTab({ onSuccess, show }: { onSuccess: () => void; show: ShowFn }) {
  const [phone, setPhone] = useState("");
  const [otpSent, setOtpSent] = useState(false);
  const [otp, setOtp] = useState("");
  const [name, setName] = useState("");
  const [devOtp, setDevOtp] = useState("");
  const [busy, setBusy] = useState(false);
  const [timer, setTimer] = useState(0);

  function startTimer() {
    setTimer(30);
    const t = setInterval(() => {
      setTimer((v) => {
        if (v <= 1) {
          clearInterval(t);
          return 0;
        }
        return v - 1;
      });
    }, 1000);
  }

  async function sendOtp() {
    if (!/^\d{10}$/.test(phone)) {
      show("Enter a valid 10-digit mobile number.", "error");
      return;
    }
    setBusy(true);
    try {
      const identifier = `+91${phone}`;
      const res = await fetch("/api/auth/otp/request", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ identifier, purpose: "phone-login" }),
      });
      const d = await res.json();
      if (!res.ok) {
        show(d.error?.message || "Could not send OTP.", "error");
        return;
      }
      setOtpSent(true);
      setDevOtp(d.devOtp || "");
      startTimer();
      show(d.message, "success");
    } finally {
      setBusy(false);
    }
  }

  async function verifyOtp() {
    setBusy(true);
    try {
      const identifier = `+91${phone}`;
      const res = await fetch("/api/auth/otp/verify", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ identifier, code: otp, purpose: "phone-login", name }),
      });
      const d = await res.json();
      if (!res.ok) {
        show(d.error?.message || "Invalid code.", "error");
        return;
      }
      onSuccess();
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="flex flex-col gap-3">
      <div>
        <label className="label" htmlFor="phone">Mobile number</label>
        <div className="flex gap-2">
          <span className="input w-16 flex items-center justify-center" style={{ background: "var(--color-accent-soft)" }}>+91</span>
          <input id="phone" className="input" value={phone} maxLength={10} disabled={otpSent} onChange={(e) => setPhone(e.target.value.replace(/\D/g, ""))} />
        </div>
      </div>
      {!otpSent ? (
        <button className="btn btn-primary btn-block" disabled={busy} onClick={sendOtp}>Send OTP</button>
      ) : (
        <>
          <div>
            <label className="label" htmlFor="phone-name">Your name (for new accounts)</label>
            <input id="phone-name" className="input" value={name} onChange={(e) => setName(e.target.value)} placeholder="Optional" />
          </div>
          <div>
            <label className="label" htmlFor="phone-otp">Enter OTP</label>
            <input id="phone-otp" className="input" value={otp} maxLength={6} onChange={(e) => setOtp(e.target.value.replace(/\D/g, ""))} />
            {devOtp && (
              <p className="text-xs mt-1" style={{ color: "var(--color-ink-soft)" }}>
                Sandbox mode (no SMS gateway configured): your code is <strong>{devOtp}</strong>
              </p>
            )}
          </div>
          <button className="btn btn-primary btn-block" disabled={busy || otp.length !== 6} onClick={verifyOtp}>Verify &amp; continue</button>
          <button className="text-xs underline disabled:opacity-40" disabled={timer > 0} onClick={sendOtp}>
            {timer > 0 ? `Resend OTP in ${timer}s` : "Resend OTP"}
          </button>
        </>
      )}
    </div>
  );
}

function GoogleTab({ onSuccess, show }: { onSuccess: () => void; show: ShowFn }) {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [busy, setBusy] = useState(false);

  async function continueWithGoogle() {
    if (!name || !/^\S+@\S+\.\S+$/.test(email)) {
      show("Enter your Google account name and email.", "error");
      return;
    }
    setBusy(true);
    try {
      const res = await fetch("/api/auth/google-demo", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name, email }),
      });
      const d = await res.json();
      if (!res.ok) {
        show(d.error?.message || "Could not continue with Google.", "error");
        return;
      }
      onSuccess();
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="flex flex-col gap-3">
      <p className="text-xs rounded-lg p-3" style={{ background: "var(--color-gold-soft)", color: "var(--color-gold)" }}>
        Firebase Google Sign-In requires OAuth client keys that aren't configured in this sandbox. Confirm your
        Google account details below to continue with a simulated Google session.
      </p>
      <div>
        <label className="label" htmlFor="g-name">Name</label>
        <input id="g-name" className="input" value={name} onChange={(e) => setName(e.target.value)} />
      </div>
      <div>
        <label className="label" htmlFor="g-email">Email</label>
        <input id="g-email" type="email" className="input" value={email} onChange={(e) => setEmail(e.target.value)} />
      </div>
      <button className="btn btn-secondary btn-block" disabled={busy} onClick={continueWithGoogle}>
        <GoogleIcon /> Continue with Google
      </button>
    </div>
  );
}

function GoogleIcon() {
  return (
    <svg width="16" height="16" viewBox="0 0 48 48">
      <path fill="#FFC107" d="M43.6 20.5H42V20H24v8h11.3c-1.6 4.7-6 8-11.3 8-6.6 0-12-5.4-12-12s5.4-12 12-12c3.1 0 5.8 1.1 8 3l5.7-5.7C34.4 6.1 29.5 4 24 4 12.9 4 4 12.9 4 24s8.9 20 20 20 20-8.9 20-20c0-1.3-.1-2.7-.4-3.5z" />
      <path fill="#FF3D00" d="M6.3 14.7l6.6 4.8C14.7 15.5 19 12 24 12c3.1 0 5.8 1.1 8 3l5.7-5.7C34.4 6.1 29.5 4 24 4c-7.4 0-13.8 4.2-17 10.3z" />
      <path fill="#4CAF50" d="M24 44c5.4 0 10.2-1.8 13.9-5l-6.4-5.4C29.4 35.4 26.9 36 24 36c-5.2 0-9.6-3.3-11.2-8l-6.6 5.1C9.1 39.7 16 44 24 44z" />
      <path fill="#1976D2" d="M43.6 20.5H42V20H24v8h11.3c-.8 2.3-2.2 4.3-4 5.7l6.4 5.4C40.9 36.6 44 30.9 44 24c0-1.3-.1-2.7-.4-3.5z" />
    </svg>
  );
}

export default function LoginPage() {
  return (
    <Suspense fallback={null}>
      <LoginInner />
    </Suspense>
  );
}
