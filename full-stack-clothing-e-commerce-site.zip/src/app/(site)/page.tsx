"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { ProductCard, type ProductCardData } from "@/components/product-card";
import { ProductGridSkeleton } from "@/components/skeletons";

type Banner = { id: number; title: string; subtitle: string | null; image: string; link: string | null };
type Category = { id: number; name: string; slug: string; image: string | null; icon: string | null };

export default function HomePage() {
  const [banners, setBanners] = useState<Banner[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [newArrivals, setNewArrivals] = useState<ProductCardData[]>([]);
  const [trending, setTrending] = useState<ProductCardData[]>([]);
  const [deals, setDeals] = useState<ProductCardData[]>([]);
  const [loading, setLoading] = useState(true);
  const [slide, setSlide] = useState(0);

  useEffect(() => {
    Promise.all([
      fetch("/api/banners").then((r) => r.json()),
      fetch("/api/categories").then((r) => r.json()),
      fetch("/api/products?sort=newest&limit=8").then((r) => r.json()),
      fetch("/api/products?trending=true&limit=8").then((r) => r.json()),
      fetch("/api/products?discount=30&sort=popularity&limit=8").then((r) => r.json()),
    ])
      .then(([b, c, n, t, d]) => {
        setBanners(b.items || []);
        setCategories(c.items || []);
        setNewArrivals(n.items || []);
        setTrending(t.items || []);
        setDeals(d.items || []);
      })
      .finally(() => setLoading(false));
  }, []);

  useEffect(() => {
    if (banners.length < 2) return;
    const t = setInterval(() => setSlide((s) => (s + 1) % banners.length), 4500);
    return () => clearInterval(t);
  }, [banners.length]);

  return (
    <div>
      {/* Hero slider */}
      <section className="container-page pt-4">
        <div className="relative overflow-hidden rounded-2xl" style={{ minHeight: 260 }}>
          {banners.length === 0 && !loading && (
            <div
              className="flex h-full min-h-[260px] items-center rounded-2xl px-8"
              style={{ background: "linear-gradient(120deg, var(--color-accent-soft), var(--color-gold-soft))" }}
            >
              <div>
                <h1 style={{ fontFamily: "var(--font-display)" }} className="text-3xl font-semibold mb-2">
                  New season, new wardrobe
                </h1>
                <p style={{ color: "var(--color-ink-soft)" }} className="mb-4 max-w-md">
                  Festive kurtas, everyday basics and winter layers — shop the edit curated for you.
                </p>
                <Link href="/products" className="btn btn-primary">Shop now</Link>
              </div>
            </div>
          )}
          {banners.map((b, i) => (
            <Link
              key={b.id}
              href={b.link || "/products"}
              className="absolute inset-0 transition-opacity duration-500"
              style={{ opacity: i === slide ? 1 : 0, pointerEvents: i === slide ? "auto" : "none" }}
            >
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img src={b.image} alt={b.title} className="h-full min-h-[260px] w-full object-cover rounded-2xl" />
              <div className="absolute inset-0 flex flex-col justify-end rounded-2xl p-6" style={{ background: "linear-gradient(0deg, rgba(20,16,12,0.65), transparent 60%)" }}>
                <h2 className="text-white text-2xl font-semibold" style={{ fontFamily: "var(--font-display)" }}>{b.title}</h2>
                {b.subtitle && <p className="text-white/85 text-sm mt-1">{b.subtitle}</p>}
              </div>
            </Link>
          ))}
          {banners.length > 1 && (
            <div className="absolute bottom-3 right-4 flex gap-1.5">
              {banners.map((_, i) => (
                <button
                  key={i}
                  aria-label={`Go to slide ${i + 1}`}
                  onClick={() => setSlide(i)}
                  className="h-1.5 rounded-full transition-all"
                  style={{ width: i === slide ? 18 : 8, background: "#fff", opacity: i === slide ? 1 : 0.5 }}
                />
              ))}
            </div>
          )}
        </div>
      </section>

      {/* Category strip */}
      <section className="container-page mt-8">
        <div className="flex gap-4 overflow-x-auto pb-2 sm:grid sm:grid-cols-6">
          {(categories.length ? categories : Array.from({ length: 6 })).map((c, i) => (
            <Link
              key={c ? (c as Category).slug : i}
              href={c ? `/products?category=${(c as Category).slug}` : "#"}
              className="flex shrink-0 flex-col items-center gap-2 w-20 sm:w-auto"
            >
              <div
                className="flex h-16 w-16 items-center justify-center rounded-full text-2xl"
                style={{ background: "var(--color-accent-soft)" }}
              >
                {c ? (c as Category).icon || "👕" : "👕"}
              </div>
              <span className="text-xs font-medium text-center">{c ? (c as Category).name : ""}</span>
            </Link>
          ))}
        </div>
      </section>

      <ProductSection title="New Arrivals" subtitle="Fresh drops, straight off the rack" items={newArrivals} loading={loading} viewAllHref="/products?sort=newest" />
      <ProductSection title="Trending Now" subtitle="What everyone's adding to cart" items={trending} loading={loading} viewAllHref="/products?trending=true" />
      <ProductSection title="Deals — 30% off or more" subtitle="Limited-time price drops" items={deals} loading={loading} viewAllHref="/products?discount=30" accent />
    </div>
  );
}

function ProductSection({
  title,
  subtitle,
  items,
  loading,
  viewAllHref,
  accent,
}: {
  title: string;
  subtitle: string;
  items: ProductCardData[];
  loading: boolean;
  viewAllHref: string;
  accent?: boolean;
}) {
  if (!loading && items.length === 0) return null;
  return (
    <section className="container-page mt-10">
      <div className="flex items-end justify-between mb-4">
        <div>
          <h2 className="text-xl font-semibold" style={{ fontFamily: "var(--font-display)", color: accent ? "var(--color-accent)" : undefined }}>
            {title}
          </h2>
          <p className="text-sm" style={{ color: "var(--color-ink-soft)" }}>{subtitle}</p>
        </div>
        <Link href={viewAllHref} className="text-sm font-semibold hover:underline" style={{ color: "var(--color-accent)" }}>
          View all →
        </Link>
      </div>
      {loading ? (
        <ProductGridSkeleton count={4} />
      ) : (
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3 sm:gap-4">
          {items.map((p) => (
            <ProductCard key={p.id} product={p} />
          ))}
        </div>
      )}
    </section>
  );
}
