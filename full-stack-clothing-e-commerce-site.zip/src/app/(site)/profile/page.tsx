"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { useCurrentUser } from "@/lib/use-current-user";
import { useToast } from "@/components/toast";
import type { Address } from "@/lib/types";

export default function ProfilePage() {
  const { user, loading, setUser } = useCurrentUser();
  const router = useRouter();
  const { show } = useToast();
  const [name, setName] = useState("");
  const [gender, setGender] = useState("");
  const [saving, setSaving] = useState(false);
  const [addresses, setAddresses] = useState<Address[]>([]);

  useEffect(() => {
    if (!loading && !user) router.push("/login?next=/profile");
    if (user) {
      setName(user.name || "");
      setGender(user.gender || "");
    }
  }, [user, loading, router]);

  useEffect(() => {
    fetch("/api/addresses").then((r) => r.json()).then((d) => setAddresses(d.items || []));
  }, []);

  async function saveProfile() {
    setSaving(true);
    try {
      const res = await fetch("/api/me", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name, gender }),
      });
      const d = await res.json();
      if (!res.ok) {
        show(d.error?.message || "Could not save profile.", "error");
        return;
      }
      setUser(d.user);
      show("Profile updated", "success");
    } finally {
      setSaving(false);
    }
  }

  async function removeAddress(id: number) {
    await fetch(`/api/addresses/${id}`, { method: "DELETE" });
    setAddresses((prev) => prev.filter((a) => a.id !== id));
    show("Address removed", "success");
  }

  if (loading || !user) return <div className="container-page py-10"><div className="skeleton h-40 w-full" /></div>;

  return (
    <div className="container-page py-6 max-w-2xl">
      <h1 className="text-xl font-semibold mb-5">My Profile</h1>

      <div className="card p-5 mb-6">
        <div className="flex items-center gap-4 mb-5">
          <div className="h-16 w-16 rounded-full flex items-center justify-center text-2xl font-bold" style={{ background: "var(--color-accent-soft)", color: "var(--color-accent)" }}>
            {(user.name || user.email || "U")[0]?.toUpperCase()}
          </div>
          <div>
            <div className="font-semibold">{user.name || "Add your name"}</div>
            <div className="text-sm" style={{ color: "var(--color-ink-soft)" }}>{user.email || user.phone}</div>
          </div>
        </div>
        <div className="grid sm:grid-cols-2 gap-3">
          <div>
            <label className="label" htmlFor="name">Full name</label>
            <input id="name" className="input" value={name} onChange={(e) => setName(e.target.value)} />
          </div>
          <div>
            <label className="label" htmlFor="gender">Gender (optional)</label>
            <select id="gender" className="input" value={gender} onChange={(e) => setGender(e.target.value)}>
              <option value="">Prefer not to say</option>
              <option value="female">Female</option>
              <option value="male">Male</option>
              <option value="other">Other</option>
            </select>
          </div>
          <div>
            <label className="label">Email</label>
            <input className="input" value={user.email || "—"} disabled />
          </div>
          <div>
            <label className="label">Phone</label>
            <input className="input" value={user.phone || "—"} disabled />
          </div>
        </div>
        <button className="btn btn-primary mt-4" disabled={saving} onClick={saveProfile}>Save changes</button>
      </div>

      <div className="card p-5">
        <h2 className="font-semibold mb-3">Saved Addresses</h2>
        {addresses.length === 0 ? (
          <p className="text-sm" style={{ color: "var(--color-ink-soft)" }}>No saved addresses yet. Add one at checkout.</p>
        ) : (
          <div className="flex flex-col gap-3">
            {addresses.map((a) => (
              <div key={a.id} className="flex justify-between items-start p-3 rounded-lg" style={{ border: "1px solid var(--color-border)" }}>
                <div className="text-sm">
                  <span className="badge badge-gold mr-2">{a.label}</span>
                  <strong>{a.fullName}</strong> · {a.phone}
                  <div style={{ color: "var(--color-ink-soft)" }}>{a.line1}, {a.city}, {a.state} - {a.pincode}</div>
                </div>
                <button className="text-xs underline" style={{ color: "var(--color-danger)" }} onClick={() => removeAddress(a.id)}>Remove</button>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
