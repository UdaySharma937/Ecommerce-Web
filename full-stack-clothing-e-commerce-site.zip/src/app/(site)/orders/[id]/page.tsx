"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { useParams, useRouter } from "next/navigation";
import { formatDate, formatINR } from "@/lib/format";
import { useToast } from "@/components/toast";

const STAGES = ["Placed", "Confirmed", "Shipped", "Out for delivery", "Delivered"];

type OrderData = {
  id: number;
  orderNumber: string;
  status: string;
  paymentMethod: string;
  paymentStatus: string;
  subtotal: string;
  discount: string;
  deliveryFee: string;
  total: string;
  couponCode: string | null;
  address: { fullName: string; phone: string; line1: string; line2?: string; city: string; state: string; pincode: string };
  createdAt: string;
};
type OrderItem = { id: number; name: string; image: string | null; price: string; quantity: number; size: string; color: string; productId: number; productSlug: string | null };
type HistoryItem = { id: number; status: string; note: string | null; createdAt: string };

export default function OrderDetailPage() {
  const { id } = useParams<{ id: string }>();
  const router = useRouter();
  const { show } = useToast();
  const [order, setOrder] = useState<OrderData | null>(null);
  const [items, setItems] = useState<OrderItem[]>([]);
  const [history, setHistory] = useState<HistoryItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [cancelling, setCancelling] = useState(false);

  function load() {
    fetch(`/api/orders/${id}`)
      .then((r) => (r.ok ? r.json() : Promise.reject()))
      .then((d) => {
        setOrder(d.order);
        setItems(d.items);
        setHistory(d.history);
      })
      .catch(() => setOrder(null))
      .finally(() => setLoading(false));
  }

  useEffect(load, [id]);

  async function cancelOrder() {
    if (!confirm("Cancel this order?")) return;
    setCancelling(true);
    try {
      const res = await fetch(`/api/orders/${id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "cancel" }),
      });
      const d = await res.json();
      if (!res.ok) {
        show(d.error?.message || "Could not cancel order.", "error");
        return;
      }
      show("Order cancelled", "success");
      load();
    } finally {
      setCancelling(false);
    }
  }

  if (loading) return <div className="container-page py-10"><div className="skeleton h-40 w-full" /></div>;
  if (!order) {
    return (
      <div className="container-page py-16 text-center">
        <p className="mb-4">Order not found.</p>
        <Link href="/orders" className="btn btn-primary">Back to orders</Link>
      </div>
    );
  }

  const isCancelled = order.status === "Cancelled";
  const currentStageIndex = STAGES.indexOf(order.status);
  const canCancel = ["Placed", "Confirmed"].includes(order.status);

  return (
    <div className="container-page py-6">
      <Link href="/orders" className="text-sm font-semibold mb-4 inline-block" style={{ color: "var(--color-accent)" }}>← Back to orders</Link>
      <div className="flex flex-wrap items-center justify-between gap-2 mb-6">
        <div>
          <h1 className="text-xl font-semibold">{order.orderNumber}</h1>
          <p className="text-sm" style={{ color: "var(--color-ink-soft)" }}>Placed on {formatDate(order.createdAt)}</p>
        </div>
        {canCancel && (
          <button className="btn btn-danger btn-sm" disabled={cancelling} onClick={cancelOrder}>Cancel order</button>
        )}
      </div>

      {/* Tracking timeline */}
      <div className="card p-5 mb-6">
        {isCancelled ? (
          <p className="font-semibold" style={{ color: "var(--color-danger)" }}>This order was cancelled.</p>
        ) : (
          <div className="flex items-center">
            {STAGES.map((stage, i) => (
              <div key={stage} className="flex-1 flex flex-col items-center relative">
                {i > 0 && (
                  <div
                    className="absolute top-3 right-1/2 h-0.5 w-full"
                    style={{ background: i <= currentStageIndex ? "var(--color-success)" : "var(--color-border)" }}
                  />
                )}
                <div
                  className="h-6 w-6 rounded-full flex items-center justify-center text-[10px] font-bold z-10"
                  style={{
                    background: i <= currentStageIndex ? "var(--color-success)" : "var(--color-border)",
                    color: i <= currentStageIndex ? "#fff" : "var(--color-ink-soft)",
                  }}
                >
                  {i <= currentStageIndex ? "✓" : i + 1}
                </div>
                <span className="text-[11px] text-center mt-2" style={{ color: i <= currentStageIndex ? "var(--color-ink)" : "var(--color-ink-soft)" }}>
                  {stage}
                </span>
              </div>
            ))}
          </div>
        )}
        <div className="mt-6 flex flex-col gap-2">
          {history.map((h) => (
            <div key={h.id} className="flex justify-between text-xs" style={{ color: "var(--color-ink-soft)" }}>
              <span>{h.status}{h.note ? ` — ${h.note}` : ""}</span>
              <span>{formatDate(h.createdAt)}</span>
            </div>
          ))}
        </div>
      </div>

      <div className="grid sm:grid-cols-[1fr_300px] gap-6">
        <div className="flex flex-col gap-3">
          {items.map((item) => (
            <div key={item.id} className="card p-3 flex gap-3 items-center">
              {item.image ? (
                // eslint-disable-next-line @next/next/no-img-element
                <img src={item.image} alt="" className="h-20 w-16 object-cover rounded-lg" />
              ) : (
                <div className="h-20 w-16 rounded-lg" style={{ background: "var(--color-accent-soft)" }} />
              )}
              <div className="flex-1">
                <div className="font-medium text-sm">{item.name}</div>
                <div className="text-xs" style={{ color: "var(--color-ink-soft)" }}>{item.size} · {item.color} · Qty {item.quantity}</div>
                <div className="font-semibold mt-1">{formatINR(item.price)}</div>
              </div>
              {order.status === "Delivered" && item.productSlug && (
                <Link href={`/products/${item.productSlug}`} className="btn btn-outline btn-sm">
                  Rate &amp; Review
                </Link>
              )}
            </div>
          ))}
        </div>

        <div className="flex flex-col gap-4">
          <div className="card p-4">
            <h2 className="font-semibold mb-2 text-sm">Delivery Address</h2>
            <p className="text-sm" style={{ color: "var(--color-ink-soft)" }}>
              <strong style={{ color: "var(--color-ink)" }}>{order.address.fullName}</strong> · {order.address.phone}
              <br />
              {order.address.line1}{order.address.line2 ? `, ${order.address.line2}` : ""}
              <br />
              {order.address.city}, {order.address.state} - {order.address.pincode}
            </p>
          </div>
          <div className="card p-4">
            <h2 className="font-semibold mb-2 text-sm">Payment</h2>
            <p className="text-sm" style={{ color: "var(--color-ink-soft)" }}>
              {order.paymentMethod === "COD" ? "Cash on Delivery" : "Paid Online"} · {order.paymentStatus}
            </p>
          </div>
          <div className="card p-4">
            <h2 className="font-semibold mb-2 text-sm">Bill Details</h2>
            <div className="flex justify-between text-sm mb-1"><span>Subtotal</span><span>{formatINR(order.subtotal)}</span></div>
            {parseFloat(order.discount) > 0 && (
              <div className="flex justify-between text-sm mb-1" style={{ color: "var(--color-success)" }}><span>Discount</span><span>−{formatINR(order.discount)}</span></div>
            )}
            <div className="flex justify-between text-sm mb-1"><span>Delivery</span><span>{parseFloat(order.deliveryFee) === 0 ? "FREE" : formatINR(order.deliveryFee)}</span></div>
            <div className="flex justify-between font-bold pt-2 mt-2" style={{ borderTop: "1px dashed var(--color-border)" }}><span>Total</span><span>{formatINR(order.total)}</span></div>
          </div>
          <button className="btn btn-outline" onClick={() => window.print()}>Print invoice</button>
        </div>
      </div>
    </div>
  );
}
