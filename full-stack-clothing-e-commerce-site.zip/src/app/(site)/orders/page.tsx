"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { formatDate, formatINR } from "@/lib/format";
import { EmptyState } from "@/components/empty-state";
import type { OrderSummary } from "@/lib/types";

const STATUS_COLORS: Record<string, string> = {
  Placed: "badge-gold",
  Confirmed: "badge-gold",
  Shipped: "badge-accent",
  "Out for delivery": "badge-accent",
  Delivered: "badge-success",
  Cancelled: "badge-danger",
};

export default function OrdersPage() {
  const [orders, setOrders] = useState<OrderSummary[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch("/api/orders")
      .then((r) => r.json())
      .then((d) => setOrders(d.items || []))
      .finally(() => setLoading(false));
  }, []);

  if (loading) {
    return <div className="container-page py-10"><div className="skeleton h-40 w-full" /></div>;
  }

  if (orders.length === 0) {
    return (
      <EmptyState
        title="No orders yet"
        message="When you place an order, it will show up here with live tracking."
        ctaHref="/products"
        ctaLabel="Start shopping"
      />
    );
  }

  return (
    <div className="container-page py-6">
      <h1 className="text-xl font-semibold mb-5">My Orders</h1>
      <div className="flex flex-col gap-3">
        {orders.map((o) => (
          <Link key={o.id} href={`/orders/${o.id}`} className="card p-4 flex items-center gap-4 hover:shadow-md transition-shadow">
            {o.firstImage ? (
              // eslint-disable-next-line @next/next/no-img-element
              <img src={o.firstImage} alt="" className="h-16 w-14 object-cover rounded-lg" />
            ) : (
              <div className="h-16 w-14 rounded-lg" style={{ background: "var(--color-accent-soft)" }} />
            )}
            <div className="flex-1">
              <div className="font-semibold text-sm">{o.orderNumber}</div>
              <div className="text-xs" style={{ color: "var(--color-ink-soft)" }}>
                {o.itemCount} item{o.itemCount > 1 ? "s" : ""} · Placed on {formatDate(o.createdAt)}
              </div>
              <div className="font-semibold mt-1">{formatINR(o.total)}</div>
            </div>
            <span className={`badge ${STATUS_COLORS[o.status] || "badge-gold"}`}>{o.status}</span>
          </Link>
        ))}
      </div>
    </div>
  );
}
