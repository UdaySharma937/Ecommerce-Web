"use client";

import { useEffect, useState } from "react";
import { ProductCard, type ProductCardData } from "@/components/product-card";
import { EmptyState } from "@/components/empty-state";
import { ProductGridSkeleton } from "@/components/skeletons";

export default function WishlistPage() {
  const [items, setItems] = useState<ProductCardData[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch("/api/wishlist")
      .then((r) => r.json())
      .then((d) => setItems(d.items || []))
      .finally(() => setLoading(false));
  }, []);

  return (
    <div className="container-page py-6">
      <h1 className="text-xl font-semibold mb-5">My Wishlist</h1>
      {loading ? (
        <ProductGridSkeleton count={4} />
      ) : items.length === 0 ? (
        <EmptyState
          title="Your wishlist is empty"
          message="Save items you love so you can find them easily later."
          ctaHref="/products"
          ctaLabel="Discover products"
        />
      ) : (
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
          {items.map((p) => (
            <ProductCard
              key={p.id}
              product={p}
              wishlisted
              onToggleWishlist={(id, next) => {
                if (!next) setItems((prev) => prev.filter((x) => x.id !== id));
              }}
            />
          ))}
        </div>
      )}
    </div>
  );
}
