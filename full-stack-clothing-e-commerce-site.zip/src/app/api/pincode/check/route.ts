import { apiError, apiOk } from "@/lib/api";

// Mock pincode serviceability check. In a real system this would call a
// logistics partner API. Here we deterministically simulate ETAs so the UI
// flow can be fully tested without external dependencies.
export async function GET(req: Request) {
  const { searchParams } = new URL(req.url);
  const pincode = searchParams.get("pincode") || "";
  if (!/^\d{6}$/.test(pincode)) {
    return apiError("Enter a valid 6-digit pincode.", 422);
  }
  const lastDigit = parseInt(pincode[pincode.length - 1], 10);
  const serviceable = lastDigit !== 0;
  const days = serviceable ? 2 + (lastDigit % 4) : 0;
  const eta = new Date();
  eta.setDate(eta.getDate() + days);

  return apiOk({
    pincode,
    serviceable,
    codAvailable: serviceable,
    etaText: serviceable
      ? `Usually delivered by ${eta.toLocaleDateString("en-IN", { day: "numeric", month: "short" })}`
      : "Currently not serviceable at this pincode.",
  });
}
