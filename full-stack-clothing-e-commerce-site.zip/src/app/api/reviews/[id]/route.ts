import { db } from "@/db";
import { reviews } from "@/db/schema";
import { apiError, apiOk } from "@/lib/api";
import { getCurrentUser } from "@/lib/current-user";
import { recomputeRating } from "@/lib/ratings";
import { and, eq } from "drizzle-orm";
import { z } from "zod";

const schema = z.object({
  rating: z.number().int().min(1).max(5).optional(),
  title: z.string().max(150).optional(),
  body: z.string().max(2000).optional(),
  photoUrl: z.string().url().optional().nullable(),
});

export async function PATCH(req: Request, { params }: { params: Promise<{ id: string }> }) {
  const current = await getCurrentUser();
  if (!current) return apiError("Please log in.", 401);
  const { id } = await params;
  const reviewId = parseInt(id, 10);

  const [existing] = await db.select().from(reviews).where(eq(reviews.id, reviewId)).limit(1);
  if (!existing || existing.userId !== current.id) return apiError("Review not found.", 404);

  const body = await req.json().catch(() => null);
  const parsed = schema.safeParse(body);
  if (!parsed.success) return apiError("Invalid review data.", 422);

  await db.update(reviews).set(parsed.data).where(eq(reviews.id, reviewId));
  if (parsed.data.rating) await recomputeRating(existing.productId);
  return apiOk({ ok: true });
}

export async function DELETE(_req: Request, { params }: { params: Promise<{ id: string }> }) {
  const current = await getCurrentUser();
  if (!current) return apiError("Please log in.", 401);
  const { id } = await params;
  const reviewId = parseInt(id, 10);

  const [existing] = await db.select().from(reviews).where(eq(reviews.id, reviewId)).limit(1);
  if (!existing || existing.userId !== current.id) return apiError("Review not found.", 404);

  await db.delete(reviews).where(and(eq(reviews.id, reviewId), eq(reviews.userId, current.id)));
  await recomputeRating(existing.productId);
  return apiOk({ ok: true });
}
