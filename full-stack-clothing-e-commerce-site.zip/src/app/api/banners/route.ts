import { db } from "@/db";
import { banners } from "@/db/schema";
import { apiOk } from "@/lib/api";
import { asc, eq } from "drizzle-orm";

export async function GET() {
  const rows = await db
    .select()
    .from(banners)
    .where(eq(banners.isActive, true))
    .orderBy(asc(banners.position));
  return apiOk({ items: rows });
}
