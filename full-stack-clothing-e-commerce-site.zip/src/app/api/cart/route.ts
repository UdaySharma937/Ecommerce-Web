import { db } from "@/db";
import { cartItems, productImages, productVariants, products } from "@/db/schema";
import { apiError, apiOk } from "@/lib/api";
import { getCurrentUser } from "@/lib/current-user";
import { and, asc, eq } from "drizzle-orm";
import { z } from "zod";

export async function GET() {
  const user = await getCurrentUser();
  if (!user) return apiOk({ items: [] });

  const rows = await db
    .select({
      id: cartItems.id,
      productId: cartItems.productId,
      variantId: cartItems.variantId,
      quantity: cartItems.quantity,
      name: products.name,
      slug: products.slug,
      price: products.price,
      mrp: products.mrp,
      size: productVariants.size,
      color: productVariants.color,
      stock: productVariants.stock,
    })
    .from(cartItems)
    .innerJoin(products, eq(products.id, cartItems.productId))
    .innerJoin(productVariants, eq(productVariants.id, cartItems.variantId))
    .where(eq(cartItems.userId, user.id))
    .orderBy(asc(cartItems.id));

  const items = await Promise.all(
    rows.map(async (r) => {
      const [img] = await db
        .select({ url: productImages.url })
        .from(productImages)
        .where(eq(productImages.productId, r.productId))
        .orderBy(asc(productImages.position))
        .limit(1);
      return {
        id: r.id,
        productId: r.productId,
        variantId: r.variantId,
        quantity: r.quantity,
        product: { name: r.name, slug: r.slug, price: r.price, mrp: r.mrp, image: img?.url ?? null },
        variant: { size: r.size, color: r.color, stock: r.stock },
      };
    })
  );

  return apiOk({ items });
}

const addSchema = z.object({
  productId: z.number().int(),
  variantId: z.number().int(),
  quantity: z.number().int().min(1).max(10).default(1),
});

export async function POST(req: Request) {
  const user = await getCurrentUser();
  if (!user) return apiError("Please log in to add items to your cart.", 401);

  const body = await req.json().catch(() => null);
  const parsed = addSchema.safeParse(body);
  if (!parsed.success) return apiError("Invalid item.", 422);

  const [variant] = await db
    .select()
    .from(productVariants)
    .where(eq(productVariants.id, parsed.data.variantId))
    .limit(1);
  if (!variant || variant.productId !== parsed.data.productId) {
    return apiError("Selected variant is unavailable.", 404);
  }
  if (variant.stock < 1) return apiError("This size/color is out of stock.", 409);

  const [existing] = await db
    .select()
    .from(cartItems)
    .where(and(eq(cartItems.userId, user.id), eq(cartItems.variantId, variant.id)))
    .limit(1);

  if (existing) {
    const newQty = Math.min(variant.stock, existing.quantity + parsed.data.quantity);
    await db.update(cartItems).set({ quantity: newQty }).where(eq(cartItems.id, existing.id));
  } else {
    await db.insert(cartItems).values({
      userId: user.id,
      productId: parsed.data.productId,
      variantId: variant.id,
      quantity: Math.min(variant.stock, parsed.data.quantity),
    });
  }

  return apiOk({ ok: true }, 201);
}
