import { db } from "@/db";
import { cartItems, productVariants } from "@/db/schema";
import { apiError, apiOk } from "@/lib/api";
import { getCurrentUser } from "@/lib/current-user";
import { and, eq } from "drizzle-orm";
import { z } from "zod";

const schema = z.object({ quantity: z.number().int().min(1).max(10) });

export async function PATCH(req: Request, { params }: { params: Promise<{ id: string }> }) {
  const user = await getCurrentUser();
  if (!user) return apiError("Please log in.", 401);
  const { id } = await params;
  const itemId = parseInt(id, 10);

  const [item] = await db.select().from(cartItems).where(eq(cartItems.id, itemId)).limit(1);
  if (!item || item.userId !== user.id) return apiError("Cart item not found.", 404);

  const body = await req.json().catch(() => null);
  const parsed = schema.safeParse(body);
  if (!parsed.success) return apiError("Invalid quantity.", 422);

  const [variant] = await db.select().from(productVariants).where(eq(productVariants.id, item.variantId)).limit(1);
  const qty = Math.min(parsed.data.quantity, variant?.stock ?? parsed.data.quantity);

  await db.update(cartItems).set({ quantity: qty }).where(eq(cartItems.id, itemId));
  return apiOk({ ok: true, quantity: qty });
}

export async function DELETE(_req: Request, { params }: { params: Promise<{ id: string }> }) {
  const user = await getCurrentUser();
  if (!user) return apiError("Please log in.", 401);
  const { id } = await params;
  const itemId = parseInt(id, 10);

  await db.delete(cartItems).where(and(eq(cartItems.id, itemId), eq(cartItems.userId, user.id)));
  return apiOk({ ok: true });
}
