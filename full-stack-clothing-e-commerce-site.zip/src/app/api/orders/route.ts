import { db } from "@/db";
import {
  addresses,
  cartItems,
  coupons,
  orderItems,
  orderStatusHistory,
  orders,
  productImages,
  productVariants,
  products,
} from "@/db/schema";
import { apiError, apiOk, genOrderNumber } from "@/lib/api";
import { getCurrentUser } from "@/lib/current-user";
import { asc, desc, eq, and, sql } from "drizzle-orm";
import { z } from "zod";

export async function GET() {
  const user = await getCurrentUser();
  if (!user) return apiOk({ items: [] });

  const rows = await db
    .select({
      id: orders.id,
      orderNumber: orders.orderNumber,
      status: orders.status,
      total: orders.total,
      createdAt: orders.createdAt,
    })
    .from(orders)
    .where(eq(orders.userId, user.id))
    .orderBy(desc(orders.id));

  const items = await Promise.all(
    rows.map(async (o) => {
      const lineItems = await db.select().from(orderItems).where(eq(orderItems.orderId, o.id));
      return {
        ...o,
        itemCount: lineItems.reduce((s, i) => s + i.quantity, 0),
        firstImage: lineItems[0]?.image ?? null,
      };
    })
  );

  return apiOk({ items });
}

const schema = z.object({
  addressId: z.number().int(),
  paymentMethod: z.enum(["COD", "ONLINE"]),
  couponCode: z.string().optional(),
});

export async function POST(req: Request) {
  const user = await getCurrentUser();
  if (!user) return apiError("Please log in to place an order.", 401);

  const body = await req.json().catch(() => null);
  const parsed = schema.safeParse(body);
  if (!parsed.success) return apiError("Select a delivery address and payment method.", 422);

  const [address] = await db
    .select()
    .from(addresses)
    .where(and(eq(addresses.id, parsed.data.addressId), eq(addresses.userId, user.id)))
    .limit(1);
  if (!address) return apiError("Delivery address not found.", 404);

  const lines = await db
    .select({
      productId: cartItems.productId,
      variantId: cartItems.variantId,
      quantity: cartItems.quantity,
      name: products.name,
      price: products.price,
      size: productVariants.size,
      color: productVariants.color,
      stock: productVariants.stock,
    })
    .from(cartItems)
    .innerJoin(products, eq(products.id, cartItems.productId))
    .innerJoin(productVariants, eq(productVariants.id, cartItems.variantId))
    .where(eq(cartItems.userId, user.id));

  if (!lines.length) return apiError("Your cart is empty.", 422);

  for (const line of lines) {
    if (line.quantity > line.stock) {
      return apiError(`${line.name} (${line.size}) is no longer available in that quantity.`, 409);
    }
  }

  const images = await Promise.all(
    lines.map((l) =>
      db
        .select({ url: productImages.url })
        .from(productImages)
        .where(eq(productImages.productId, l.productId))
        .orderBy(asc(productImages.position))
        .limit(1)
    )
  );

  const subtotal = lines.reduce((s, l) => s + parseFloat(l.price) * l.quantity, 0);

  let discount = 0;
  let appliedCode: string | null = null;
  if (parsed.data.couponCode) {
    const code = parsed.data.couponCode.trim().toUpperCase();
    const [coupon] = await db
      .select()
      .from(coupons)
      .where(and(eq(coupons.code, code), eq(coupons.isActive, true)))
      .limit(1);
    if (coupon && (!coupon.expiresAt || new Date(coupon.expiresAt) >= new Date()) && coupon.usedCount < coupon.usageLimit && subtotal >= parseFloat(coupon.minOrderValue)) {
      discount = coupon.type === "percent" ? (subtotal * parseFloat(coupon.value)) / 100 : parseFloat(coupon.value);
      if (coupon.maxDiscount) discount = Math.min(discount, parseFloat(coupon.maxDiscount));
      discount = Math.min(discount, subtotal);
      appliedCode = coupon.code;
      await db.update(coupons).set({ usedCount: coupon.usedCount + 1 }).where(eq(coupons.id, coupon.id));
    }
  }

  const deliveryFee = subtotal - discount >= 999 ? 0 : 49;
  const total = Math.round(subtotal - discount + deliveryFee);

  const [order] = await db
    .insert(orders)
    .values({
      orderNumber: genOrderNumber(),
      userId: user.id,
      status: "Placed",
      paymentMethod: parsed.data.paymentMethod,
      paymentStatus: parsed.data.paymentMethod === "ONLINE" ? "Paid" : "Pending",
      subtotal: subtotal.toFixed(2),
      discount: discount.toFixed(2),
      deliveryFee: deliveryFee.toFixed(2),
      total: total.toFixed(2),
      couponCode: appliedCode,
      address: {
        fullName: address.fullName,
        phone: address.phone,
        line1: address.line1,
        line2: address.line2,
        city: address.city,
        state: address.state,
        pincode: address.pincode,
      },
    })
    .returning();

  await db.insert(orderItems).values(
    lines.map((l, i) => ({
      orderId: order.id,
      productId: l.productId,
      name: l.name,
      image: images[i][0]?.url ?? null,
      price: l.price,
      quantity: l.quantity,
      size: l.size,
      color: l.color,
    }))
  );

  await db.insert(orderStatusHistory).values({ orderId: order.id, status: "Placed", note: "Order placed successfully." });

  for (const l of lines) {
    await db
      .update(productVariants)
      .set({ stock: sql`${productVariants.stock} - ${l.quantity}` })
      .where(eq(productVariants.id, l.variantId));
    await db
      .update(products)
      .set({ soldCount: sql`${products.soldCount} + ${l.quantity}` })
      .where(eq(products.id, l.productId));
  }

  await db.delete(cartItems).where(eq(cartItems.userId, user.id));

  return apiOk({ order: { id: order.id, orderNumber: order.orderNumber } }, 201);
}
