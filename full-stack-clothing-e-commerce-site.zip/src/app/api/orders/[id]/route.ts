import { db } from "@/db";
import { orderItems, orderStatusHistory, orders, productVariants, products } from "@/db/schema";
import { apiError, apiOk } from "@/lib/api";
import { getCurrentUser } from "@/lib/current-user";
import { asc, eq, sql } from "drizzle-orm";

export async function GET(_req: Request, { params }: { params: Promise<{ id: string }> }) {
  const user = await getCurrentUser();
  if (!user) return apiError("Please log in.", 401);
  const { id } = await params;
  const orderId = parseInt(id, 10);

  const [order] = await db.select().from(orders).where(eq(orders.id, orderId)).limit(1);
  if (!order || order.userId !== user.id) return apiError("Order not found.", 404);

  const [items, history] = await Promise.all([
    db
      .select({
        id: orderItems.id,
        orderId: orderItems.orderId,
        productId: orderItems.productId,
        name: orderItems.name,
        image: orderItems.image,
        price: orderItems.price,
        quantity: orderItems.quantity,
        size: orderItems.size,
        color: orderItems.color,
        productSlug: products.slug,
      })
      .from(orderItems)
      .leftJoin(products, eq(products.id, orderItems.productId))
      .where(eq(orderItems.orderId, orderId)),
    db.select().from(orderStatusHistory).where(eq(orderStatusHistory.orderId, orderId)).orderBy(asc(orderStatusHistory.id)),
  ]);

  return apiOk({ order, items, history });
}

export async function PATCH(req: Request, { params }: { params: Promise<{ id: string }> }) {
  const user = await getCurrentUser();
  if (!user) return apiError("Please log in.", 401);
  const { id } = await params;
  const orderId = parseInt(id, 10);

  const body = await req.json().catch(() => ({}));
  if (body.action !== "cancel") return apiError("Unsupported action.", 400);

  const [order] = await db.select().from(orders).where(eq(orders.id, orderId)).limit(1);
  if (!order || order.userId !== user.id) return apiError("Order not found.", 404);
  if (!["Placed", "Confirmed"].includes(order.status)) {
    return apiError("This order can no longer be cancelled.", 409);
  }

  await db.update(orders).set({ status: "Cancelled" }).where(eq(orders.id, orderId));
  await db.insert(orderStatusHistory).values({ orderId, status: "Cancelled", note: "Cancelled by customer." });

  const items = await db.select().from(orderItems).where(eq(orderItems.orderId, orderId));
  for (const item of items) {
    // Restock: find a variant for the same product/size/color combination.
    await db
      .update(productVariants)
      .set({ stock: sql`${productVariants.stock} + ${item.quantity}` })
      .where(sql`${productVariants.productId} = ${item.productId} AND ${productVariants.size} = ${item.size} AND ${productVariants.color} = ${item.color}`);
  }

  return apiOk({ ok: true });
}
