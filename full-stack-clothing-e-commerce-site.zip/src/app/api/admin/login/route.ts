import { db } from "@/db";
import { admins } from "@/db/schema";
import { apiError, apiOk } from "@/lib/api";
import { createAdminSession } from "@/lib/auth";
import { verifySecret } from "@/lib/password";
import { eq } from "drizzle-orm";
import { z } from "zod";

const schema = z.object({ email: z.string().email(), password: z.string().min(1) });

export async function POST(req: Request) {
  const body = await req.json().catch(() => null);
  const parsed = schema.safeParse(body);
  if (!parsed.success) return apiError("Enter a valid email and password.", 422);

  const [admin] = await db
    .select()
    .from(admins)
    .where(eq(admins.email, parsed.data.email.toLowerCase().trim()))
    .limit(1);
  if (!admin) return apiError("Invalid admin credentials.", 401);

  const ok = await verifySecret(parsed.data.password, admin.passwordHash);
  if (!ok) return apiError("Invalid admin credentials.", 401);

  await createAdminSession(admin.id);
  return apiOk({ admin: { id: admin.id, name: admin.name, email: admin.email } });
}
