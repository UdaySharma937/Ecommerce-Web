import { apiError, apiOk } from "@/lib/api";
import { requireAdmin } from "@/lib/require-admin";
import { mkdir, writeFile } from "fs/promises";
import path from "path";

const ALLOWED_TYPES = new Set(["image/jpeg", "image/png", "image/webp", "image/gif"]);
const MAX_SIZE = 5 * 1024 * 1024; // 5MB

export async function POST(req: Request) {
  const { errorResponse } = await requireAdmin();
  if (errorResponse) return errorResponse;

  const form = await req.formData().catch(() => null);
  const file = form?.get("file");
  if (!file || !(file instanceof File)) return apiError("No file uploaded.", 422);
  if (!ALLOWED_TYPES.has(file.type)) return apiError("Only JPG, PNG, GIF or WEBP images are allowed.", 422);
  if (file.size > MAX_SIZE) return apiError("Image must be smaller than 5MB.", 422);

  const bytes = Buffer.from(await file.arrayBuffer());
  const ext = file.type.split("/")[1] === "jpeg" ? "jpg" : file.type.split("/")[1];
  const filename = `${Date.now()}-${Math.random().toString(36).slice(2, 9)}.${ext}`;

  const uploadDir = path.join(process.cwd(), "public", "uploads");
  await mkdir(uploadDir, { recursive: true });
  await writeFile(path.join(uploadDir, filename), bytes);

  return apiOk({ url: `/uploads/${filename}` }, 201);
}
