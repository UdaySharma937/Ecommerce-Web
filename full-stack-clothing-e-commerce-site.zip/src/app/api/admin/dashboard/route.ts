import { db } from "@/db";
import { apiOk } from "@/lib/api";
import { requireAdmin } from "@/lib/require-admin";
import { sql } from "drizzle-orm";

export async function GET() {
  const { errorResponse } = await requireAdmin();
  if (errorResponse) return errorResponse;

  const [totals] = (
    await db.execute(sql`
    SELECT
      COALESCE(SUM(total) FILTER (WHERE status != 'Cancelled'), 0)::float as "totalSales",
      COUNT(*) FILTER (WHERE created_at::date = CURRENT_DATE)::int as "ordersToday",
      COUNT(*) FILTER (WHERE status IN ('Placed','Confirmed'))::int as "pendingOrders",
      COUNT(*)::int as "totalOrders"
    FROM orders
  `)
  ).rows as { totalSales: number; ordersToday: number; pendingOrders: number; totalOrders: number }[];

  const [customerCount] = (await db.execute(sql`SELECT COUNT(*)::int as count FROM users`)).rows as {
    count: number;
  }[];

  const lowStock = (
    await db.execute(sql`
    SELECT p.id, p.name, pv.size, pv.color, pv.stock
    FROM product_variants pv
    JOIN products p ON p.id = pv.product_id
    WHERE pv.stock <= 5
    ORDER BY pv.stock ASC
    LIMIT 8
  `)
  ).rows;

  const revenueChart = (
    await db.execute(sql`
    SELECT TO_CHAR(d.day, 'DD Mon') as label,
      COALESCE(SUM(o.total), 0)::float as revenue
    FROM generate_series(CURRENT_DATE - INTERVAL '29 days', CURRENT_DATE, INTERVAL '1 day') d(day)
    LEFT JOIN orders o ON o.created_at::date = d.day AND o.status != 'Cancelled'
    GROUP BY d.day
    ORDER BY d.day
  `)
  ).rows;

  const recentOrders = (
    await db.execute(sql`
    SELECT o.id, o.order_number as "orderNumber", o.status, o.total, o.created_at as "createdAt",
      COALESCE(u.name, 'Guest') as "customerName"
    FROM orders o
    LEFT JOIN users u ON u.id = o.user_id
    ORDER BY o.id DESC
    LIMIT 8
  `)
  ).rows;

  return apiOk({
    totals: { ...totals, totalCustomers: customerCount.count },
    lowStock,
    revenueChart,
    recentOrders,
  });
}
