import { db } from "@/db";
import { orderItems, orderStatusHistory, orders, users } from "@/db/schema";
import { apiError, apiOk } from "@/lib/api";
import { requireAdmin } from "@/lib/require-admin";
import { asc, eq } from "drizzle-orm";
import { z } from "zod";

export async function GET(_req: Request, { params }: { params: Promise<{ id: string }> }) {
  const { errorResponse } = await requireAdmin();
  if (errorResponse) return errorResponse;
  const { id } = await params;
  const orderId = parseInt(id, 10);

  const [order] = await db
    .select({
      id: orders.id,
      orderNumber: orders.orderNumber,
      status: orders.status,
      paymentMethod: orders.paymentMethod,
      paymentStatus: orders.paymentStatus,
      subtotal: orders.subtotal,
      discount: orders.discount,
      deliveryFee: orders.deliveryFee,
      total: orders.total,
      couponCode: orders.couponCode,
      address: orders.address,
      createdAt: orders.createdAt,
      customerName: users.name,
      customerEmail: users.email,
      customerPhone: users.phone,
    })
    .from(orders)
    .leftJoin(users, eq(users.id, orders.userId))
    .where(eq(orders.id, orderId))
    .limit(1);
  if (!order) return apiError("Order not found.", 404);

  const [items, history] = await Promise.all([
    db.select().from(orderItems).where(eq(orderItems.orderId, orderId)),
    db.select().from(orderStatusHistory).where(eq(orderStatusHistory.orderId, orderId)).orderBy(asc(orderStatusHistory.id)),
  ]);

  return apiOk({ order, items, history });
}

const STATUSES = ["Placed", "Confirmed", "Shipped", "Out for delivery", "Delivered", "Cancelled"];
const schema = z.object({ status: z.enum(STATUSES as [string, ...string[]]), note: z.string().max(300).optional() });

export async function PATCH(req: Request, { params }: { params: Promise<{ id: string }> }) {
  const { errorResponse } = await requireAdmin();
  if (errorResponse) return errorResponse;
  const { id } = await params;
  const orderId = parseInt(id, 10);

  const body = await req.json().catch(() => null);
  const parsed = schema.safeParse(body);
  if (!parsed.success) return apiError("Invalid status.", 422);

  const [existing] = await db.select().from(orders).where(eq(orders.id, orderId)).limit(1);
  if (!existing) return apiError("Order not found.", 404);

  await db.update(orders).set({ status: parsed.data.status }).where(eq(orders.id, orderId));
  await db.insert(orderStatusHistory).values({
    orderId,
    status: parsed.data.status,
    note: parsed.data.note || `Status updated to ${parsed.data.status}.`,
  });

  return apiOk({ ok: true });
}
