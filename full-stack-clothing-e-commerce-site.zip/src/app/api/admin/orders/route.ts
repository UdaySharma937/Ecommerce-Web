import { db } from "@/db";
import { apiOk } from "@/lib/api";
import { requireAdmin } from "@/lib/require-admin";
import { sql } from "drizzle-orm";

export async function GET(req: Request) {
  const { errorResponse } = await requireAdmin();
  if (errorResponse) return errorResponse;

  const { searchParams } = new URL(req.url);
  const status = searchParams.get("status") || "";
  const search = searchParams.get("search")?.trim() || "";
  const from = searchParams.get("from") || "";
  const to = searchParams.get("to") || "";
  const page = Math.max(1, parseInt(searchParams.get("page") || "1", 10) || 1);
  const limit = 20;
  const offset = (page - 1) * limit;

  const conditions = [sql`1=1`];
  if (status) conditions.push(sql`o.status = ${status}`);
  if (search) {
    conditions.push(
      sql`(o.order_number ILIKE ${"%" + search + "%"} OR u.name ILIKE ${"%" + search + "%"} OR u.email ILIKE ${"%" + search + "%"} OR u.phone ILIKE ${"%" + search + "%"})`
    );
  }
  if (from) conditions.push(sql`o.created_at >= ${from}`);
  if (to) conditions.push(sql`o.created_at <= ${to}::date + interval '1 day'`);
  const whereClause = sql.join(conditions, sql` AND `);

  const items = (
    await db.execute(sql`
    SELECT o.id, o.order_number as "orderNumber", o.status, o.payment_method as "paymentMethod",
      o.payment_status as "paymentStatus", o.total, o.created_at as "createdAt",
      COALESCE(u.name, 'Guest') as "customerName", u.email as "customerEmail", u.phone as "customerPhone",
      (SELECT COALESCE(SUM(oi.quantity),0)::int FROM order_items oi WHERE oi.order_id = o.id) as "itemCount"
    FROM orders o
    LEFT JOIN users u ON u.id = o.user_id
    WHERE ${whereClause}
    ORDER BY o.id DESC
    LIMIT ${limit} OFFSET ${offset}
  `)
  ).rows;

  const [countRow] = (
    await db.execute(sql`
    SELECT COUNT(*)::int as count FROM orders o LEFT JOIN users u ON u.id = o.user_id WHERE ${whereClause}
  `)
  ).rows as { count: number }[];

  return apiOk({ items, page, limit, total: countRow.count, totalPages: Math.max(1, Math.ceil(countRow.count / limit)) });
}
