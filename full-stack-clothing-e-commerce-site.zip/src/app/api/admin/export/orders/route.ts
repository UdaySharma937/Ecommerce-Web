import { db } from "@/db";
import { requireAdmin } from "@/lib/require-admin";
import { sql } from "drizzle-orm";

function toCsvRow(values: (string | number)[]) {
  return values
    .map((v) => `"${String(v).replace(/"/g, '""')}"`)
    .join(",");
}

export async function GET() {
  const { errorResponse } = await requireAdmin();
  if (errorResponse) return errorResponse;

  const rows = (
    await db.execute(sql`
    SELECT o.order_number as "orderNumber", COALESCE(u.name,'Guest') as "customerName",
      COALESCE(u.email,'') as "customerEmail", COALESCE(u.phone,'') as "customerPhone",
      o.status, o.payment_method as "paymentMethod", o.total, o.created_at as "createdAt"
    FROM orders o
    LEFT JOIN users u ON u.id = o.user_id
    ORDER BY o.id DESC
  `)
  ).rows as Record<string, string | number>[];

  const header = toCsvRow(["Order Number", "Customer", "Email", "Phone", "Status", "Payment Method", "Total", "Date"]);
  const lines = rows.map((r) =>
    toCsvRow([r.orderNumber, r.customerName, r.customerEmail, r.customerPhone, r.status, r.paymentMethod, r.total, String(r.createdAt)])
  );
  const csv = [header, ...lines].join("\n");

  return new Response(csv, {
    headers: {
      "Content-Type": "text/csv",
      "Content-Disposition": `attachment; filename="orders.csv"`,
    },
  });
}
