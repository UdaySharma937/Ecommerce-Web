import { db } from "@/db";
import { requireAdmin } from "@/lib/require-admin";
import { sql } from "drizzle-orm";

function toCsvRow(values: (string | number)[]) {
  return values.map((v) => `"${String(v).replace(/"/g, '""')}"`).join(",");
}

export async function GET() {
  const { errorResponse } = await requireAdmin();
  if (errorResponse) return errorResponse;

  const rows = (
    await db.execute(sql`
    SELECT COALESCE(u.name,'') as name, COALESCE(u.email,'') as email, COALESCE(u.phone,'') as phone,
      u.created_at as "joinedAt", COALESCE(COUNT(o.id),0)::int as "totalOrders",
      COALESCE(SUM(o.total) FILTER (WHERE o.status != 'Cancelled'),0)::float as "totalSpent"
    FROM users u
    LEFT JOIN orders o ON o.user_id = u.id
    GROUP BY u.id
    ORDER BY "totalSpent" DESC
  `)
  ).rows as Record<string, string | number>[];

  const header = toCsvRow(["Name", "Email", "Phone", "Joined", "Total Orders", "Total Spent"]);
  const lines = rows.map((r) => toCsvRow([r.name, r.email, r.phone, String(r.joinedAt), r.totalOrders, r.totalSpent]));
  const csv = [header, ...lines].join("\n");

  return new Response(csv, {
    headers: { "Content-Type": "text/csv", "Content-Disposition": `attachment; filename="customers.csv"` },
  });
}
