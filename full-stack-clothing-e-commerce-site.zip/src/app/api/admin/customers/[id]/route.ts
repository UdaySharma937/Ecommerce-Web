import { db } from "@/db";
import { addresses, orders, users } from "@/db/schema";
import { apiError, apiOk } from "@/lib/api";
import { requireAdmin } from "@/lib/require-admin";
import { desc, eq } from "drizzle-orm";

export async function GET(_req: Request, { params }: { params: Promise<{ id: string }> }) {
  const { errorResponse } = await requireAdmin();
  if (errorResponse) return errorResponse;
  const { id } = await params;
  const userId = parseInt(id, 10);

  const [user] = await db.select().from(users).where(eq(users.id, userId)).limit(1);
  if (!user) return apiError("Customer not found.", 404);

  const [userOrders, userAddresses] = await Promise.all([
    db
      .select({
        id: orders.id,
        orderNumber: orders.orderNumber,
        status: orders.status,
        total: orders.total,
        createdAt: orders.createdAt,
      })
      .from(orders)
      .where(eq(orders.userId, userId))
      .orderBy(desc(orders.id)),
    db.select().from(addresses).where(eq(addresses.userId, userId)),
  ]);

  return apiOk({
    customer: {
      id: user.id,
      name: user.name,
      email: user.email,
      phone: user.phone,
      gender: user.gender,
      joinedAt: user.createdAt,
    },
    orders: userOrders,
    addresses: userAddresses,
  });
}
