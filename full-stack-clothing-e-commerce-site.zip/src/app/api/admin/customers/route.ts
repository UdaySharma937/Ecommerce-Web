import { db } from "@/db";
import { apiOk } from "@/lib/api";
import { requireAdmin } from "@/lib/require-admin";
import { sql } from "drizzle-orm";

export async function GET(req: Request) {
  const { errorResponse } = await requireAdmin();
  if (errorResponse) return errorResponse;

  const { searchParams } = new URL(req.url);
  const search = searchParams.get("search")?.trim() || "";
  const page = Math.max(1, parseInt(searchParams.get("page") || "1", 10) || 1);
  const limit = 20;
  const offset = (page - 1) * limit;

  const whereSql = search
    ? sql`WHERE u.name ILIKE ${"%" + search + "%"} OR u.email ILIKE ${"%" + search + "%"} OR u.phone ILIKE ${"%" + search + "%"}`
    : sql``;

  const items = (
    await db.execute(sql`
    SELECT u.id, u.name, u.email, u.phone, u.created_at as "joinedAt",
      COALESCE(COUNT(o.id),0)::int as "totalOrders",
      COALESCE(SUM(o.total) FILTER (WHERE o.status != 'Cancelled'), 0)::float as "totalSpent"
    FROM users u
    LEFT JOIN orders o ON o.user_id = u.id
    ${whereSql}
    GROUP BY u.id
    ORDER BY "totalSpent" DESC
    LIMIT ${limit} OFFSET ${offset}
  `)
  ).rows;

  const [countRow] = (await db.execute(sql`SELECT COUNT(*)::int as count FROM users u ${whereSql}`)).rows as {
    count: number;
  }[];

  return apiOk({ items, page, limit, total: countRow.count, totalPages: Math.max(1, Math.ceil(countRow.count / limit)) });
}
