import { apiOk } from "@/lib/api";
import { getCurrentAdmin } from "@/lib/current-user";

export async function GET() {
  const admin = await getCurrentAdmin();
  if (!admin) return apiOk({ admin: null });
  return apiOk({ admin: { id: admin.id, name: admin.name, email: admin.email } });
}
