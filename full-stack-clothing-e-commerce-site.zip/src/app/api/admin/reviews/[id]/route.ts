import { db } from "@/db";
import { reviews } from "@/db/schema";
import { apiError, apiOk } from "@/lib/api";
import { requireAdmin } from "@/lib/require-admin";
import { recomputeRating } from "@/lib/ratings";
import { eq } from "drizzle-orm";
import { z } from "zod";

const schema = z.object({ isHidden: z.boolean() });

export async function PATCH(req: Request, { params }: { params: Promise<{ id: string }> }) {
  const { errorResponse } = await requireAdmin();
  if (errorResponse) return errorResponse;
  const { id } = await params;
  const reviewId = parseInt(id, 10);

  const body = await req.json().catch(() => null);
  const parsed = schema.safeParse(body);
  if (!parsed.success) return apiError("Invalid data.", 422);

  const [existing] = await db.select().from(reviews).where(eq(reviews.id, reviewId)).limit(1);
  if (!existing) return apiError("Review not found.", 404);

  await db.update(reviews).set({ isHidden: parsed.data.isHidden }).where(eq(reviews.id, reviewId));
  await recomputeRating(existing.productId);
  return apiOk({ ok: true });
}

export async function DELETE(_req: Request, { params }: { params: Promise<{ id: string }> }) {
  const { errorResponse } = await requireAdmin();
  if (errorResponse) return errorResponse;
  const { id } = await params;
  const reviewId = parseInt(id, 10);

  const [existing] = await db.select().from(reviews).where(eq(reviews.id, reviewId)).limit(1);
  if (!existing) return apiError("Review not found.", 404);

  await db.delete(reviews).where(eq(reviews.id, reviewId));
  await recomputeRating(existing.productId);
  return apiOk({ ok: true });
}
