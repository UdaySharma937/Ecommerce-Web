import { db } from "@/db";
import { apiOk } from "@/lib/api";
import { requireAdmin } from "@/lib/require-admin";
import { sql } from "drizzle-orm";

export async function GET(req: Request) {
  const { errorResponse } = await requireAdmin();
  if (errorResponse) return errorResponse;

  const { searchParams } = new URL(req.url);
  const hidden = searchParams.get("hidden");
  const conditions = [sql`1=1`];
  if (hidden === "true") conditions.push(sql`r.is_hidden = true`);
  if (hidden === "false") conditions.push(sql`r.is_hidden = false`);
  const whereClause = sql.join(conditions, sql` AND `);

  const items = (
    await db.execute(sql`
    SELECT r.id, r.rating, r.title, r.body, r.photo_url as "photoUrl", r.is_hidden as "isHidden",
      r.created_at as "createdAt", u.name as "userName", p.name as "productName", p.slug as "productSlug"
    FROM reviews r
    JOIN users u ON u.id = r.user_id
    JOIN products p ON p.id = r.product_id
    WHERE ${whereClause}
    ORDER BY r.id DESC
    LIMIT 100
  `)
  ).rows;

  return apiOk({ items });
}
