import { db } from "@/db";
import { categories } from "@/db/schema";
import { apiError, apiOk } from "@/lib/api";
import { requireAdmin } from "@/lib/require-admin";
import { slugify } from "@/lib/format";
import { asc } from "drizzle-orm";
import { z } from "zod";

export async function GET() {
  const { errorResponse } = await requireAdmin();
  if (errorResponse) return errorResponse;
  const rows = await db.select().from(categories).orderBy(asc(categories.position));
  return apiOk({ items: rows });
}

const schema = z.object({
  name: z.string().min(2).max(80),
  image: z.string().optional(),
  icon: z.string().max(10).optional(),
  position: z.number().int().default(0),
});

export async function POST(req: Request) {
  const { errorResponse } = await requireAdmin();
  if (errorResponse) return errorResponse;
  const body = await req.json().catch(() => null);
  const parsed = schema.safeParse(body);
  if (!parsed.success) return apiError("Enter a category name.", 422);

  const [row] = await db
    .insert(categories)
    .values({ ...parsed.data, slug: slugify(parsed.data.name) })
    .returning();
  return apiOk({ category: row }, 201);
}
