import { db } from "@/db";
import { categories } from "@/db/schema";
import { apiError, apiOk } from "@/lib/api";
import { requireAdmin } from "@/lib/require-admin";
import { eq } from "drizzle-orm";
import { z } from "zod";

const schema = z.object({
  name: z.string().min(2).max(80).optional(),
  image: z.string().optional().nullable(),
  icon: z.string().max(10).optional().nullable(),
  position: z.number().int().optional(),
});

export async function PATCH(req: Request, { params }: { params: Promise<{ id: string }> }) {
  const { errorResponse } = await requireAdmin();
  if (errorResponse) return errorResponse;
  const { id } = await params;
  const body = await req.json().catch(() => null);
  const parsed = schema.safeParse(body);
  if (!parsed.success) return apiError("Invalid category data.", 422);

  const [row] = await db.update(categories).set(parsed.data).where(eq(categories.id, parseInt(id, 10))).returning();
  if (!row) return apiError("Category not found.", 404);
  return apiOk({ category: row });
}

export async function DELETE(_req: Request, { params }: { params: Promise<{ id: string }> }) {
  const { errorResponse } = await requireAdmin();
  if (errorResponse) return errorResponse;
  const { id } = await params;
  await db.delete(categories).where(eq(categories.id, parseInt(id, 10)));
  return apiOk({ ok: true });
}
