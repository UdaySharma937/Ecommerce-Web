import { db } from "@/db";
import { coupons } from "@/db/schema";
import { apiError, apiOk } from "@/lib/api";
import { requireAdmin } from "@/lib/require-admin";
import { eq } from "drizzle-orm";
import { z } from "zod";

const schema = z.object({
  isActive: z.boolean().optional(),
  value: z.number().positive().optional(),
  minOrderValue: z.number().nonnegative().optional(),
  usageLimit: z.number().int().positive().optional(),
  expiresAt: z.string().optional().nullable(),
});

export async function PATCH(req: Request, { params }: { params: Promise<{ id: string }> }) {
  const { errorResponse } = await requireAdmin();
  if (errorResponse) return errorResponse;
  const { id } = await params;
  const body = await req.json().catch(() => null);
  const parsed = schema.safeParse(body);
  if (!parsed.success) return apiError("Invalid coupon data.", 422);

  const { value, minOrderValue, expiresAt, ...rest } = parsed.data;
  const updates: Record<string, unknown> = { ...rest };
  if (value !== undefined) updates.value = value.toFixed(2);
  if (minOrderValue !== undefined) updates.minOrderValue = minOrderValue.toFixed(2);
  if (expiresAt !== undefined) updates.expiresAt = expiresAt ? new Date(expiresAt) : null;

  const [row] = await db.update(coupons).set(updates).where(eq(coupons.id, parseInt(id, 10))).returning();
  if (!row) return apiError("Coupon not found.", 404);
  return apiOk({ coupon: row });
}

export async function DELETE(_req: Request, { params }: { params: Promise<{ id: string }> }) {
  const { errorResponse } = await requireAdmin();
  if (errorResponse) return errorResponse;
  const { id } = await params;
  await db.delete(coupons).where(eq(coupons.id, parseInt(id, 10)));
  return apiOk({ ok: true });
}
