import { db } from "@/db";
import { coupons } from "@/db/schema";
import { apiError, apiOk } from "@/lib/api";
import { requireAdmin } from "@/lib/require-admin";
import { desc } from "drizzle-orm";
import { z } from "zod";

export async function GET() {
  const { errorResponse } = await requireAdmin();
  if (errorResponse) return errorResponse;
  const rows = await db.select().from(coupons).orderBy(desc(coupons.id));
  return apiOk({ items: rows });
}

const schema = z.object({
  code: z.string().min(3).max(40),
  type: z.enum(["percent", "flat"]),
  value: z.number().positive(),
  minOrderValue: z.number().nonnegative().default(0),
  maxDiscount: z.number().positive().optional(),
  expiresAt: z.string().optional(),
  usageLimit: z.number().int().positive().default(1000),
  isActive: z.boolean().default(true),
});

export async function POST(req: Request) {
  const { errorResponse } = await requireAdmin();
  if (errorResponse) return errorResponse;
  const body = await req.json().catch(() => null);
  const parsed = schema.safeParse(body);
  if (!parsed.success) return apiError("Please fill all coupon fields correctly.", 422);

  const [row] = await db
    .insert(coupons)
    .values({
      code: parsed.data.code.toUpperCase(),
      type: parsed.data.type,
      value: parsed.data.value.toFixed(2),
      minOrderValue: parsed.data.minOrderValue.toFixed(2),
      maxDiscount: parsed.data.maxDiscount?.toFixed(2),
      expiresAt: parsed.data.expiresAt ? new Date(parsed.data.expiresAt) : null,
      usageLimit: parsed.data.usageLimit,
      isActive: parsed.data.isActive,
    })
    .returning();
  return apiOk({ coupon: row }, 201);
}
