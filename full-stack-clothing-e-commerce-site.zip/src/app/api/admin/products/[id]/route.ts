import { db } from "@/db";
import { productImages, productVariants, products } from "@/db/schema";
import { apiError, apiOk } from "@/lib/api";
import { requireAdmin } from "@/lib/require-admin";
import { asc, eq } from "drizzle-orm";
import { z } from "zod";

export async function GET(_req: Request, { params }: { params: Promise<{ id: string }> }) {
  const { errorResponse } = await requireAdmin();
  if (errorResponse) return errorResponse;
  const { id } = await params;
  const productId = parseInt(id, 10);

  const [product] = await db.select().from(products).where(eq(products.id, productId)).limit(1);
  if (!product) return apiError("Product not found.", 404);

  const [images, variants] = await Promise.all([
    db.select().from(productImages).where(eq(productImages.productId, productId)).orderBy(asc(productImages.position)),
    db.select().from(productVariants).where(eq(productVariants.productId, productId)),
  ]);

  return apiOk({ product: { ...product, images, variants } });
}

const variantSchema = z.object({
  id: z.number().int().optional(),
  size: z.string().min(1).max(20),
  color: z.string().min(1).max(40),
  colorHex: z.string().max(10).default("#999999"),
  stock: z.number().int().min(0),
});

const schema = z.object({
  name: z.string().min(2).max(200).optional(),
  categoryId: z.number().int().optional(),
  brand: z.string().min(1).max(80).optional(),
  description: z.string().max(5000).optional(),
  price: z.number().positive().optional(),
  mrp: z.number().positive().optional(),
  tags: z.string().max(300).optional(),
  isFeatured: z.boolean().optional(),
  isTrending: z.boolean().optional(),
  isActive: z.boolean().optional(),
  images: z.array(z.string()).optional(),
  variants: z.array(variantSchema).optional(),
});

export async function PATCH(req: Request, { params }: { params: Promise<{ id: string }> }) {
  const { errorResponse } = await requireAdmin();
  if (errorResponse) return errorResponse;
  const { id } = await params;
  const productId = parseInt(id, 10);

  const [existing] = await db.select().from(products).where(eq(products.id, productId)).limit(1);
  if (!existing) return apiError("Product not found.", 404);

  const body = await req.json().catch(() => null);
  const parsed = schema.safeParse(body);
  if (!parsed.success) return apiError("Invalid product data.", 422);

  const { images, variants, price, mrp, ...rest } = parsed.data;
  const updates: Record<string, unknown> = { ...rest };
  if (price !== undefined) updates.price = price.toFixed(2);
  if (mrp !== undefined) updates.mrp = mrp.toFixed(2);

  if (Object.keys(updates).length) {
    await db.update(products).set(updates).where(eq(products.id, productId));
  }

  if (images) {
    await db.delete(productImages).where(eq(productImages.productId, productId));
    if (images.length) {
      await db.insert(productImages).values(images.map((url, position) => ({ productId, url, position })));
    }
  }

  if (variants) {
    await db.delete(productVariants).where(eq(productVariants.productId, productId));
    if (variants.length) {
      await db.insert(productVariants).values(
        variants.map((v) => ({
          productId,
          size: v.size,
          color: v.color,
          colorHex: v.colorHex,
          stock: v.stock,
          sku: `${existing.slug}-${v.size}-${v.color}`.toUpperCase().replace(/\s+/g, ""),
        }))
      );
    }
  }

  return apiOk({ ok: true });
}

export async function DELETE(_req: Request, { params }: { params: Promise<{ id: string }> }) {
  const { errorResponse } = await requireAdmin();
  if (errorResponse) return errorResponse;
  const { id } = await params;
  await db.delete(products).where(eq(products.id, parseInt(id, 10)));
  return apiOk({ ok: true });
}
