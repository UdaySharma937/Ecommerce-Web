import { db } from "@/db";
import { productImages, productVariants, products } from "@/db/schema";
import { apiError, apiOk } from "@/lib/api";
import { requireAdmin } from "@/lib/require-admin";
import { slugify } from "@/lib/format";
import { sql } from "drizzle-orm";
import { z } from "zod";

export async function GET(req: Request) {
  const { errorResponse } = await requireAdmin();
  if (errorResponse) return errorResponse;

  const { searchParams } = new URL(req.url);
  const search = searchParams.get("search")?.trim() || "";
  const page = Math.max(1, parseInt(searchParams.get("page") || "1", 10) || 1);
  const limit = 20;
  const offset = (page - 1) * limit;

  const whereSql = search
    ? sql`WHERE p.name ILIKE ${"%" + search + "%"} OR p.brand ILIKE ${"%" + search + "%"}`
    : sql``;

  const items = (
    await db.execute(sql`
    SELECT p.id, p.name, p.slug, p.brand, p.price, p.mrp, p.is_active as "isActive",
      p.is_featured as "isFeatured", p.is_trending as "isTrending", c.name as "categoryName",
      (SELECT pi.url FROM product_images pi WHERE pi.product_id = p.id ORDER BY pi.position ASC LIMIT 1) as image,
      (SELECT COALESCE(SUM(pv.stock),0)::int FROM product_variants pv WHERE pv.product_id = p.id) as "totalStock"
    FROM products p
    JOIN categories c ON c.id = p.category_id
    ${whereSql}
    ORDER BY p.id DESC
    LIMIT ${limit} OFFSET ${offset}
  `)
  ).rows;

  const [countRow] = (
    await db.execute(sql`SELECT COUNT(*)::int as count FROM products p ${whereSql}`)
  ).rows as { count: number }[];

  return apiOk({ items, page, limit, total: countRow.count, totalPages: Math.max(1, Math.ceil(countRow.count / limit)) });
}

const variantSchema = z.object({
  size: z.string().min(1).max(20),
  color: z.string().min(1).max(40),
  colorHex: z.string().max(10).default("#999999"),
  stock: z.number().int().min(0),
});

const schema = z.object({
  name: z.string().min(2).max(200),
  categoryId: z.number().int(),
  brand: z.string().min(1).max(80).default("Vastrahaus"),
  description: z.string().max(5000).default(""),
  price: z.number().positive(),
  mrp: z.number().positive(),
  tags: z.string().max(300).default(""),
  isFeatured: z.boolean().default(false),
  isTrending: z.boolean().default(false),
  isActive: z.boolean().default(true),
  images: z.array(z.string()).min(1),
  variants: z.array(variantSchema).min(1),
});

export async function POST(req: Request) {
  const { errorResponse } = await requireAdmin();
  if (errorResponse) return errorResponse;

  const body = await req.json().catch(() => null);
  const parsed = schema.safeParse(body);
  if (!parsed.success) return apiError("Please complete all required product fields.", 422, { details: parsed.error.flatten() });

  let slug = slugify(parsed.data.name);
  const existingSlugResult = await db.execute(sql`SELECT id FROM products WHERE slug = ${slug}`);
  if (existingSlugResult.rows.length) slug = `${slug}-${Math.floor(Math.random() * 10000)}`;

  const [product] = await db
    .insert(products)
    .values({
      name: parsed.data.name,
      slug,
      categoryId: parsed.data.categoryId,
      brand: parsed.data.brand,
      description: parsed.data.description,
      price: parsed.data.price.toFixed(2),
      mrp: parsed.data.mrp.toFixed(2),
      tags: parsed.data.tags,
      isFeatured: parsed.data.isFeatured,
      isTrending: parsed.data.isTrending,
      isActive: parsed.data.isActive,
    })
    .returning();

  await db.insert(productImages).values(
    parsed.data.images.map((url, position) => ({ productId: product.id, url, position }))
  );
  await db.insert(productVariants).values(
    parsed.data.variants.map((v) => ({
      productId: product.id,
      size: v.size,
      color: v.color,
      colorHex: v.colorHex,
      stock: v.stock,
      sku: `${slug}-${v.size}-${v.color}`.toUpperCase().replace(/\s+/g, ""),
    }))
  );

  return apiOk({ product }, 201);
}
