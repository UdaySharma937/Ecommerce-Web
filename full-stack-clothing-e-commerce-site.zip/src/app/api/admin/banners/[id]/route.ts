import { db } from "@/db";
import { banners } from "@/db/schema";
import { apiError, apiOk } from "@/lib/api";
import { requireAdmin } from "@/lib/require-admin";
import { eq } from "drizzle-orm";
import { z } from "zod";

const schema = z.object({
  title: z.string().min(2).max(150).optional(),
  subtitle: z.string().max(200).optional().nullable(),
  image: z.string().min(1).optional(),
  link: z.string().max(200).optional().nullable(),
  position: z.number().int().optional(),
  isActive: z.boolean().optional(),
});

export async function PATCH(req: Request, { params }: { params: Promise<{ id: string }> }) {
  const { errorResponse } = await requireAdmin();
  if (errorResponse) return errorResponse;
  const { id } = await params;
  const body = await req.json().catch(() => null);
  const parsed = schema.safeParse(body);
  if (!parsed.success) return apiError("Invalid banner data.", 422);

  const [row] = await db.update(banners).set(parsed.data).where(eq(banners.id, parseInt(id, 10))).returning();
  if (!row) return apiError("Banner not found.", 404);
  return apiOk({ banner: row });
}

export async function DELETE(_req: Request, { params }: { params: Promise<{ id: string }> }) {
  const { errorResponse } = await requireAdmin();
  if (errorResponse) return errorResponse;
  const { id } = await params;
  await db.delete(banners).where(eq(banners.id, parseInt(id, 10)));
  return apiOk({ ok: true });
}
