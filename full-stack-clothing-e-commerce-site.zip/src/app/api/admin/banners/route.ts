import { db } from "@/db";
import { banners } from "@/db/schema";
import { apiError, apiOk } from "@/lib/api";
import { requireAdmin } from "@/lib/require-admin";
import { asc } from "drizzle-orm";
import { z } from "zod";

export async function GET() {
  const { errorResponse } = await requireAdmin();
  if (errorResponse) return errorResponse;
  const rows = await db.select().from(banners).orderBy(asc(banners.position));
  return apiOk({ items: rows });
}

const schema = z.object({
  title: z.string().min(2).max(150),
  subtitle: z.string().max(200).optional(),
  image: z.string().min(1),
  link: z.string().max(200).optional(),
  position: z.number().int().default(0),
  isActive: z.boolean().default(true),
});

export async function POST(req: Request) {
  const { errorResponse } = await requireAdmin();
  if (errorResponse) return errorResponse;
  const body = await req.json().catch(() => null);
  const parsed = schema.safeParse(body);
  if (!parsed.success) return apiError("Please provide a title and banner image.", 422);

  const [row] = await db.insert(banners).values(parsed.data).returning();
  return apiOk({ banner: row }, 201);
}
