import { db } from "@/db";
import { categories } from "@/db/schema";
import { apiOk } from "@/lib/api";
import { asc } from "drizzle-orm";

export async function GET() {
  const rows = await db.select().from(categories).orderBy(asc(categories.position));
  return apiOk({ items: rows });
}
