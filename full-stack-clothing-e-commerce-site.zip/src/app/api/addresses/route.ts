import { db } from "@/db";
import { addresses } from "@/db/schema";
import { apiError, apiOk } from "@/lib/api";
import { getCurrentUser } from "@/lib/current-user";
import { desc, eq } from "drizzle-orm";
import { z } from "zod";

export async function GET() {
  const user = await getCurrentUser();
  if (!user) return apiOk({ items: [] });
  const rows = await db
    .select()
    .from(addresses)
    .where(eq(addresses.userId, user.id))
    .orderBy(desc(addresses.isDefault), desc(addresses.id));
  return apiOk({ items: rows });
}

const schema = z.object({
  label: z.string().min(1).max(20).default("Home"),
  fullName: z.string().min(2).max(120),
  phone: z.string().min(10).max(15),
  line1: z.string().min(4).max(200),
  line2: z.string().max(200).optional(),
  city: z.string().min(2).max(80),
  state: z.string().min(2).max(80),
  pincode: z.string().regex(/^\d{6}$/),
  isDefault: z.boolean().optional(),
});

export async function POST(req: Request) {
  const user = await getCurrentUser();
  if (!user) return apiError("Please log in.", 401);
  const body = await req.json().catch(() => null);
  const parsed = schema.safeParse(body);
  if (!parsed.success) return apiError("Please fill all required address fields correctly.", 422);

  if (parsed.data.isDefault) {
    await db.update(addresses).set({ isDefault: false }).where(eq(addresses.userId, user.id));
  }

  const [existingCount] = await db.select().from(addresses).where(eq(addresses.userId, user.id));
  const [row] = await db
    .insert(addresses)
    .values({ ...parsed.data, userId: user.id, isDefault: parsed.data.isDefault || !existingCount })
    .returning();

  return apiOk({ address: row }, 201);
}
