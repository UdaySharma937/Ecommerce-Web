import { db } from "@/db";
import { addresses } from "@/db/schema";
import { apiError, apiOk } from "@/lib/api";
import { getCurrentUser } from "@/lib/current-user";
import { and, eq } from "drizzle-orm";
import { z } from "zod";

const schema = z.object({
  label: z.string().min(1).max(20).optional(),
  fullName: z.string().min(2).max(120).optional(),
  phone: z.string().min(10).max(15).optional(),
  line1: z.string().min(4).max(200).optional(),
  line2: z.string().max(200).optional().nullable(),
  city: z.string().min(2).max(80).optional(),
  state: z.string().min(2).max(80).optional(),
  pincode: z.string().regex(/^\d{6}$/).optional(),
  isDefault: z.boolean().optional(),
});

export async function PATCH(req: Request, { params }: { params: Promise<{ id: string }> }) {
  const user = await getCurrentUser();
  if (!user) return apiError("Please log in.", 401);
  const { id } = await params;
  const addressId = parseInt(id, 10);

  const [existing] = await db.select().from(addresses).where(eq(addresses.id, addressId)).limit(1);
  if (!existing || existing.userId !== user.id) return apiError("Address not found.", 404);

  const body = await req.json().catch(() => null);
  const parsed = schema.safeParse(body);
  if (!parsed.success) return apiError("Invalid address data.", 422);

  if (parsed.data.isDefault) {
    await db.update(addresses).set({ isDefault: false }).where(eq(addresses.userId, user.id));
  }

  const [row] = await db.update(addresses).set(parsed.data).where(eq(addresses.id, addressId)).returning();
  return apiOk({ address: row });
}

export async function DELETE(_req: Request, { params }: { params: Promise<{ id: string }> }) {
  const user = await getCurrentUser();
  if (!user) return apiError("Please log in.", 401);
  const { id } = await params;
  await db.delete(addresses).where(and(eq(addresses.id, parseInt(id, 10)), eq(addresses.userId, user.id)));
  return apiOk({ ok: true });
}
