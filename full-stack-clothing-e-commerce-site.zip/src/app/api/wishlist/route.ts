import { db } from "@/db";
import { productImages, products, wishlistItems } from "@/db/schema";
import { apiError, apiOk } from "@/lib/api";
import { getCurrentUser } from "@/lib/current-user";
import { and, asc, desc, eq } from "drizzle-orm";
import { z } from "zod";

export async function GET() {
  const user = await getCurrentUser();
  if (!user) return apiOk({ items: [] });

  const rows = await db
    .select({
      id: products.id,
      name: products.name,
      slug: products.slug,
      brand: products.brand,
      price: products.price,
      mrp: products.mrp,
      ratingAvg: products.ratingAvg,
      ratingCount: products.ratingCount,
    })
    .from(wishlistItems)
    .innerJoin(products, eq(products.id, wishlistItems.productId))
    .where(eq(wishlistItems.userId, user.id))
    .orderBy(desc(wishlistItems.id));

  const items = await Promise.all(
    rows.map(async (p) => {
      const [img] = await db
        .select({ url: productImages.url })
        .from(productImages)
        .where(eq(productImages.productId, p.id))
        .orderBy(asc(productImages.position))
        .limit(1);
      return { ...p, image: img?.url ?? null };
    })
  );

  return apiOk({ items });
}

const schema = z.object({ productId: z.number().int() });

export async function POST(req: Request) {
  const user = await getCurrentUser();
  if (!user) return apiError("Please log in to use your wishlist.", 401);
  const body = await req.json().catch(() => null);
  const parsed = schema.safeParse(body);
  if (!parsed.success) return apiError("Invalid product.", 422);

  const [existing] = await db
    .select()
    .from(wishlistItems)
    .where(and(eq(wishlistItems.userId, user.id), eq(wishlistItems.productId, parsed.data.productId)))
    .limit(1);

  if (existing) {
    await db.delete(wishlistItems).where(eq(wishlistItems.id, existing.id));
    return apiOk({ wishlisted: false });
  }
  await db.insert(wishlistItems).values({ userId: user.id, productId: parsed.data.productId });
  return apiOk({ wishlisted: true }, 201);
}
