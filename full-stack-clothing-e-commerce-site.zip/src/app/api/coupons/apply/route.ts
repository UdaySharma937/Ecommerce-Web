import { db } from "@/db";
import { coupons } from "@/db/schema";
import { apiError, apiOk } from "@/lib/api";
import { and, eq } from "drizzle-orm";
import { z } from "zod";

const schema = z.object({ code: z.string().min(2).max(40), subtotal: z.number().nonnegative() });

export async function POST(req: Request) {
  const body = await req.json().catch(() => null);
  const parsed = schema.safeParse(body);
  if (!parsed.success) return apiError("Enter a coupon code.", 422);

  const code = parsed.data.code.trim().toUpperCase();
  const [coupon] = await db
    .select()
    .from(coupons)
    .where(and(eq(coupons.code, code), eq(coupons.isActive, true)))
    .limit(1);

  if (!coupon) return apiError("Invalid coupon code.", 404);
  if (coupon.expiresAt && new Date(coupon.expiresAt) < new Date()) {
    return apiError("This coupon has expired.", 410);
  }
  if (coupon.usedCount >= coupon.usageLimit) {
    return apiError("This coupon has reached its usage limit.", 410);
  }
  if (parsed.data.subtotal < parseFloat(coupon.minOrderValue)) {
    return apiError(`Minimum order value for this coupon is ₹${coupon.minOrderValue}.`, 422);
  }

  let discount = 0;
  if (coupon.type === "percent") {
    discount = (parsed.data.subtotal * parseFloat(coupon.value)) / 100;
    if (coupon.maxDiscount) discount = Math.min(discount, parseFloat(coupon.maxDiscount));
  } else {
    discount = parseFloat(coupon.value);
  }
  discount = Math.min(discount, parsed.data.subtotal);

  return apiOk({ code: coupon.code, type: coupon.type, value: coupon.value, discount: Math.round(discount) });
}
