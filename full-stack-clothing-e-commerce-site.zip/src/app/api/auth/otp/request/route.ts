import { apiError, apiOk } from "@/lib/api";
import { issueOtp } from "@/lib/otp";
import { z } from "zod";

const schema = z.object({
  identifier: z.string().min(4),
  purpose: z.enum(["login", "phone-login"]).default("login"),
});

// Simple in-memory rate limit per identifier to avoid OTP spam.
const lastRequest = new Map<string, number>();

export async function POST(req: Request) {
  const body = await req.json().catch(() => null);
  const parsed = schema.safeParse(body);
  if (!parsed.success) return apiError("Enter a valid email or phone number.", 422);

  const { identifier, purpose } = parsed.data;
  const key = `${purpose}:${identifier}`;
  const last = lastRequest.get(key) ?? 0;
  if (Date.now() - last < 30_000) {
    return apiError("Please wait before requesting another OTP.", 429);
  }
  lastRequest.set(key, Date.now());

  const code = await issueOtp(identifier, purpose);

  return apiOk({
    ok: true,
    message: `A 6-digit code was sent to ${identifier}.`,
    // Sandbox fallback: no SMTP/SMS gateway is configured in this environment,
    // so the code is surfaced here (and logged server-side) for testing.
    devOtp: code,
  });
}
