import { db } from "@/db";
import { users } from "@/db/schema";
import { apiError, apiOk } from "@/lib/api";
import { createUserSession } from "@/lib/auth";
import { verifyOtp } from "@/lib/otp";
import { eq } from "drizzle-orm";
import { z } from "zod";

const schema = z.object({
  identifier: z.string().min(4),
  code: z.string().length(6),
  purpose: z.enum(["login", "phone-login"]).default("login"),
  name: z.string().optional(),
});

export async function POST(req: Request) {
  const body = await req.json().catch(() => null);
  const parsed = schema.safeParse(body);
  if (!parsed.success) return apiError("Enter the 6-digit code.", 422);

  const { identifier, code, purpose, name } = parsed.data;
  const result = await verifyOtp(identifier, purpose, code);
  if (!result.ok) {
    const messages: Record<string, string> = {
      expired: "This code has expired. Please request a new one.",
      locked: "Too many incorrect attempts. Please request a new code.",
      invalid: "That code is incorrect. Please try again.",
    };
    return apiError(messages[result.reason] || "Invalid code.", 400);
  }

  const isPhone = purpose === "phone-login";
  const column = isPhone ? users.phone : users.email;
  const [existing] = await db.select().from(users).where(eq(column, identifier)).limit(1);

  let user = existing;
  if (!user) {
    const insertValues = isPhone
      ? { phone: identifier, name: name || null, authProvider: "phone" as const, emailVerified: false }
      : { email: identifier, name: name || null, authProvider: "email" as const, emailVerified: true };
    const [created] = await db.insert(users).values(insertValues).returning();
    user = created;
  } else if (!isPhone && !user.emailVerified) {
    await db.update(users).set({ emailVerified: true }).where(eq(users.id, user.id));
  }

  await createUserSession(user.id);
  return apiOk({ user: { id: user.id, name: user.name, email: user.email, phone: user.phone } });
}
