import { apiOk } from "@/lib/api";
import { clearUserSession } from "@/lib/auth";

export async function POST() {
  await clearUserSession();
  return apiOk({ ok: true });
}
