import { db } from "@/db";
import { users } from "@/db/schema";
import { apiError, apiOk } from "@/lib/api";
import { createUserSession } from "@/lib/auth";
import { verifySecret } from "@/lib/password";
import { eq } from "drizzle-orm";
import { z } from "zod";

const schema = z.object({
  email: z.string().email(),
  password: z.string().min(1),
});

export async function POST(req: Request) {
  const body = await req.json().catch(() => null);
  const parsed = schema.safeParse(body);
  if (!parsed.success) return apiError("Enter a valid email and password.", 422);

  const normalizedEmail = parsed.data.email.toLowerCase().trim();
  const [user] = await db.select().from(users).where(eq(users.email, normalizedEmail)).limit(1);

  if (!user || !user.passwordHash) {
    return apiError("No password-based account found for this email. Try OTP or Google login.", 401);
  }
  const ok = await verifySecret(parsed.data.password, user.passwordHash);
  if (!ok) return apiError("Incorrect email or password.", 401);

  await createUserSession(user.id);
  return apiOk({ user: { id: user.id, name: user.name, email: user.email } });
}
