import { db } from "@/db";
import { users } from "@/db/schema";
import { apiError, apiOk } from "@/lib/api";
import { createUserSession } from "@/lib/auth";
import { eq } from "drizzle-orm";
import { z } from "zod";

// This project has no Firebase/Google OAuth client configured in the sandbox
// environment, so "Continue with Google" uses a lightweight simulated
// identity step (the user confirms the Google account details) and creates
// a normal session the same way real OAuth would after token verification.
const schema = z.object({
  name: z.string().min(2).max(80),
  email: z.string().email(),
});

export async function POST(req: Request) {
  const body = await req.json().catch(() => null);
  const parsed = schema.safeParse(body);
  if (!parsed.success) return apiError("Enter a valid name and email.", 422);

  const normalizedEmail = parsed.data.email.toLowerCase().trim();
  const [existing] = await db.select().from(users).where(eq(users.email, normalizedEmail)).limit(1);

  let user = existing;
  if (!user) {
    const [created] = await db
      .insert(users)
      .values({ name: parsed.data.name, email: normalizedEmail, authProvider: "google", emailVerified: true })
      .returning();
    user = created;
  }

  await createUserSession(user.id);
  return apiOk({ user: { id: user.id, name: user.name, email: user.email } });
}
