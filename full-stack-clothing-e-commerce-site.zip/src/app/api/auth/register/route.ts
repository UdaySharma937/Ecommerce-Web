import { db } from "@/db";
import { users } from "@/db/schema";
import { apiError, apiOk } from "@/lib/api";
import { createUserSession } from "@/lib/auth";
import { hashSecret } from "@/lib/password";
import { eq } from "drizzle-orm";
import { z } from "zod";

const schema = z.object({
  name: z.string().min(2).max(80),
  email: z.string().email(),
  password: z.string().min(6).max(72),
});

export async function POST(req: Request) {
  const body = await req.json().catch(() => null);
  const parsed = schema.safeParse(body);
  if (!parsed.success) {
    return apiError("Please enter a valid name, email and a password with at least 6 characters.", 422);
  }
  const { name, email, password } = parsed.data;
  const normalizedEmail = email.toLowerCase().trim();

  const [existing] = await db.select().from(users).where(eq(users.email, normalizedEmail)).limit(1);
  if (existing) {
    return apiError("An account with this email already exists. Try logging in instead.", 409);
  }

  const passwordHash = await hashSecret(password);
  const [user] = await db
    .insert(users)
    .values({ name, email: normalizedEmail, passwordHash, authProvider: "email" })
    .returning();

  await createUserSession(user.id);
  return apiOk({ user: { id: user.id, name: user.name, email: user.email } }, 201);
}
