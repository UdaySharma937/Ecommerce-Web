import { db } from "@/db";
import { users } from "@/db/schema";
import { apiError, apiOk } from "@/lib/api";
import { getCurrentUser } from "@/lib/current-user";
import { eq } from "drizzle-orm";
import { z } from "zod";

export async function GET() {
  const user = await getCurrentUser();
  if (!user) return apiOk({ user: null });
  return apiOk({
    user: {
      id: user.id,
      name: user.name,
      email: user.email,
      phone: user.phone,
      photoUrl: user.photoUrl,
      gender: user.gender,
    },
  });
}

const schema = z.object({
  name: z.string().min(1).max(80).optional(),
  gender: z.string().max(20).optional().nullable(),
  phone: z.string().max(20).optional().nullable(),
  photoUrl: z.string().url().optional().nullable(),
});

export async function PATCH(req: Request) {
  const user = await getCurrentUser();
  if (!user) return apiError("Please log in.", 401);
  const body = await req.json().catch(() => null);
  const parsed = schema.safeParse(body);
  if (!parsed.success) return apiError("Invalid profile data.", 422);

  const [updated] = await db
    .update(users)
    .set(parsed.data)
    .where(eq(users.id, user.id))
    .returning();

  return apiOk({
    user: {
      id: updated.id,
      name: updated.name,
      email: updated.email,
      phone: updated.phone,
      photoUrl: updated.photoUrl,
      gender: updated.gender,
    },
  });
}
