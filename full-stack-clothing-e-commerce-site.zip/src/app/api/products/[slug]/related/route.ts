import { db } from "@/db";
import { apiOk } from "@/lib/api";
import { sql } from "drizzle-orm";

export async function GET(_req: Request, { params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const result = await db.execute(sql`
    SELECT p2.id, p2.name, p2.slug, p2.brand, p2.price, p2.mrp, p2.rating_avg as "ratingAvg",
      p2.rating_count as "ratingCount",
      (SELECT pi.url FROM product_images pi WHERE pi.product_id = p2.id ORDER BY pi.position ASC LIMIT 1) as image
    FROM products p2
    WHERE p2.is_active = true
      AND p2.category_id = (SELECT category_id FROM products WHERE slug = ${slug})
      AND p2.slug != ${slug}
    ORDER BY p2.rating_count DESC
    LIMIT 8
  `);
  return apiOk({ items: result.rows });
}
