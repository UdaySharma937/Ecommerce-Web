import { db } from "@/db";
import { orderItems, orders, products, reviews, users } from "@/db/schema";
import { apiError, apiOk } from "@/lib/api";
import { getCurrentUser } from "@/lib/current-user";
import { recomputeRating } from "@/lib/ratings";
import { and, desc, eq, sql } from "drizzle-orm";
import { z } from "zod";

export async function GET(_req: Request, { params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const [product] = await db.select({ id: products.id }).from(products).where(eq(products.slug, slug)).limit(1);
  if (!product) return apiError("Product not found.", 404);

  const rows = await db
    .select({
      id: reviews.id,
      rating: reviews.rating,
      title: reviews.title,
      body: reviews.body,
      photoUrl: reviews.photoUrl,
      createdAt: reviews.createdAt,
      userId: reviews.userId,
      userName: users.name,
    })
    .from(reviews)
    .innerJoin(users, eq(users.id, reviews.userId))
    .where(and(eq(reviews.productId, product.id), eq(reviews.isHidden, false)))
    .orderBy(desc(reviews.createdAt));

  const breakdownRows = await db.execute(sql`
    SELECT rating, COUNT(*)::int as count FROM reviews
    WHERE product_id = ${product.id} AND is_hidden = false
    GROUP BY rating
  `);
  const breakdown: Record<number, number> = { 1: 0, 2: 0, 3: 0, 4: 0, 5: 0 };
  for (const r of breakdownRows.rows as { rating: number; count: number }[]) {
    breakdown[r.rating] = r.count;
  }

  const current = await getCurrentUser();
  let canReview = false;
  let hasReviewed = false;
  if (current) {
    hasReviewed = rows.some((r) => r.userId === current.id);
    if (!hasReviewed) {
      const [delivered] = await db
        .select({ id: orders.id })
        .from(orders)
        .innerJoin(orderItems, eq(orderItems.orderId, orders.id))
        .where(
          and(eq(orders.userId, current.id), eq(orderItems.productId, product.id), eq(orders.status, "Delivered"))
        )
        .limit(1);
      canReview = !!delivered;
    }
  }

  return apiOk({
    items: rows.map((r) => ({ ...r, canEdit: current?.id === r.userId })),
    breakdown,
    canReview,
    hasReviewed,
  });
}

const schema = z.object({
  rating: z.number().int().min(1).max(5),
  title: z.string().max(150).optional(),
  body: z.string().max(2000).optional(),
  photoUrl: z.string().url().optional(),
});

export async function POST(req: Request, { params }: { params: Promise<{ slug: string }> }) {
  const current = await getCurrentUser();
  if (!current) return apiError("Please log in to write a review.", 401);

  const { slug } = await params;
  const [product] = await db.select({ id: products.id }).from(products).where(eq(products.slug, slug)).limit(1);
  if (!product) return apiError("Product not found.", 404);

  const body = await req.json().catch(() => null);
  const parsed = schema.safeParse(body);
  if (!parsed.success) return apiError("Please add a star rating.", 422);

  const [delivered] = await db
    .select({ id: orders.id })
    .from(orders)
    .innerJoin(orderItems, eq(orderItems.orderId, orders.id))
    .where(
      and(eq(orders.userId, current.id), eq(orderItems.productId, product.id), eq(orders.status, "Delivered"))
    )
    .limit(1);
  if (!delivered) {
    return apiError("You can review a product only after it has been delivered to you.", 403);
  }

  const [existing] = await db
    .select({ id: reviews.id })
    .from(reviews)
    .where(and(eq(reviews.productId, product.id), eq(reviews.userId, current.id)))
    .limit(1);
  if (existing) return apiError("You have already reviewed this product.", 409);

  await db.insert(reviews).values({
    productId: product.id,
    userId: current.id,
    orderId: delivered.id,
    rating: parsed.data.rating,
    title: parsed.data.title,
    body: parsed.data.body,
    photoUrl: parsed.data.photoUrl,
  });

  await recomputeRating(product.id);
  return apiOk({ ok: true }, 201);
}
