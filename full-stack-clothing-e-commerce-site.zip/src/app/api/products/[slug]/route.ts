import { db } from "@/db";
import { categories, productImages, products, productVariants } from "@/db/schema";
import { apiError, apiOk } from "@/lib/api";
import { and, asc, eq } from "drizzle-orm";

export async function GET(_req: Request, { params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const [product] = await db
    .select({
      id: products.id,
      name: products.name,
      slug: products.slug,
      brand: products.brand,
      description: products.description,
      price: products.price,
      mrp: products.mrp,
      ratingAvg: products.ratingAvg,
      ratingCount: products.ratingCount,
      soldCount: products.soldCount,
      tags: products.tags,
      categoryId: products.categoryId,
      categoryName: categories.name,
      categorySlug: categories.slug,
      isActive: products.isActive,
    })
    .from(products)
    .innerJoin(categories, eq(categories.id, products.categoryId))
    .where(and(eq(products.slug, slug), eq(products.isActive, true)))
    .limit(1);

  if (!product) return apiError("Product not found.", 404);

  const [images, variants] = await Promise.all([
    db
      .select({ id: productImages.id, url: productImages.url })
      .from(productImages)
      .where(eq(productImages.productId, product.id))
      .orderBy(asc(productImages.position)),
    db
      .select()
      .from(productVariants)
      .where(eq(productVariants.productId, product.id)),
  ]);

  return apiOk({ product: { ...product, images, variants } });
}
