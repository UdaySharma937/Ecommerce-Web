import { db } from "@/db";
import { apiOk } from "@/lib/api";
import { sql } from "drizzle-orm";

export async function GET(req: Request) {
  const { searchParams } = new URL(req.url);
  const search = searchParams.get("search")?.trim() || "";
  const categorySlugs = searchParams.getAll("category").flatMap((c) => c.split(",")).filter(Boolean);
  const sizes = searchParams.getAll("size").flatMap((c) => c.split(",")).filter(Boolean);
  const colors = searchParams.getAll("color").flatMap((c) => c.split(",")).filter(Boolean);
  const minPrice = searchParams.get("minPrice");
  const maxPrice = searchParams.get("maxPrice");
  const minRating = searchParams.get("rating");
  const minDiscount = searchParams.get("discount");
  const featured = searchParams.get("featured");
  const trending = searchParams.get("trending");
  const sort = searchParams.get("sort") || "relevance";
  const page = Math.max(1, parseInt(searchParams.get("page") || "1", 10) || 1);
  const limit = Math.min(48, Math.max(1, parseInt(searchParams.get("limit") || "24", 10) || 24));
  const offset = (page - 1) * limit;

  const conditions: ReturnType<typeof sql>[] = [sql`p.is_active = true`];

  if (search) {
    conditions.push(sql`(p.name ILIKE ${"%" + search + "%"} OR p.tags ILIKE ${"%" + search + "%"} OR p.brand ILIKE ${"%" + search + "%"})`);
  }
  if (categorySlugs.length) {
    conditions.push(sql`c.slug = ANY(${categorySlugs})`);
  }
  if (minPrice) conditions.push(sql`p.price >= ${minPrice}`);
  if (maxPrice) conditions.push(sql`p.price <= ${maxPrice}`);
  if (minRating) conditions.push(sql`p.rating_avg >= ${minRating}`);
  if (minDiscount) {
    conditions.push(sql`((p.mrp - p.price) / NULLIF(p.mrp,0)) * 100 >= ${minDiscount}`);
  }
  if (featured === "true") conditions.push(sql`p.is_featured = true`);
  if (trending === "true") conditions.push(sql`p.is_trending = true`);
  if (sizes.length) {
    conditions.push(
      sql`EXISTS (SELECT 1 FROM product_variants pv WHERE pv.product_id = p.id AND pv.size = ANY(${sizes}) AND pv.stock > 0)`
    );
  }
  if (colors.length) {
    conditions.push(
      sql`EXISTS (SELECT 1 FROM product_variants pv WHERE pv.product_id = p.id AND pv.color = ANY(${colors}) AND pv.stock > 0)`
    );
  }

  const whereClause = sql.join(conditions, sql` AND `);

  let orderBy = sql`p.rating_count DESC, p.created_at DESC`;
  if (sort === "price-asc") orderBy = sql`p.price ASC`;
  else if (sort === "price-desc") orderBy = sql`p.price DESC`;
  else if (sort === "newest") orderBy = sql`p.created_at DESC`;
  else if (sort === "popularity") orderBy = sql`p.sold_count DESC`;
  else if (sort === "rating") orderBy = sql`p.rating_avg DESC`;

  const itemsQuery = sql`
    SELECT p.id, p.name, p.slug, p.brand, p.price, p.mrp, p.rating_avg as "ratingAvg",
      p.rating_count as "ratingCount", p.sold_count as "soldCount", p.is_featured as "isFeatured",
      p.is_trending as "isTrending", c.slug as "categorySlug", c.name as "categoryName",
      (SELECT pi.url FROM product_images pi WHERE pi.product_id = p.id ORDER BY pi.position ASC LIMIT 1) as image
    FROM products p
    JOIN categories c ON c.id = p.category_id
    WHERE ${whereClause}
    ORDER BY ${orderBy}
    LIMIT ${limit} OFFSET ${offset}
  `;

  const countQuery = sql`
    SELECT COUNT(*)::int as count
    FROM products p
    JOIN categories c ON c.id = p.category_id
    WHERE ${whereClause}
  `;

  const [itemsResult, countResult] = await Promise.all([
    db.execute(itemsQuery),
    db.execute(countQuery),
  ]);

  const total = (countResult.rows[0] as { count: number } | undefined)?.count ?? 0;

  return apiOk({
    items: itemsResult.rows,
    page,
    limit,
    total,
    totalPages: Math.max(1, Math.ceil(total / limit)),
  });
}
