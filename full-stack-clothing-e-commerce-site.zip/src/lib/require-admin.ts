import { getCurrentAdmin } from "@/lib/current-user";
import { apiError } from "@/lib/api";

export async function requireAdmin() {
  const admin = await getCurrentAdmin();
  if (!admin) {
    return { admin: null, errorResponse: apiError("Admin login required.", 401) };
  }
  return { admin, errorResponse: null };
}
