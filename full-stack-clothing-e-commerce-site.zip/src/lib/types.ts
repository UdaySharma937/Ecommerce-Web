export type ProductCard = {
  id: number;
  name: string;
  slug: string;
  brand: string;
  price: string;
  mrp: string;
  ratingAvg: string;
  ratingCount: number;
  image: string | null;
  isWishlisted?: boolean;
};

export type Variant = {
  id: number;
  size: string;
  color: string;
  colorHex: string;
  stock: number;
  sku: string;
};

export type ProductDetail = ProductCard & {
  description: string;
  tags: string;
  categoryId: number;
  categoryName?: string;
  categorySlug?: string;
  images: { id: number; url: string }[];
  variants: Variant[];
};

export type CartLine = {
  id: number;
  productId: number;
  variantId: number;
  quantity: number;
  product: {
    name: string;
    slug: string;
    price: string;
    mrp: string;
    image: string | null;
  };
  variant: { size: string; color: string; stock: number };
};

export type Address = {
  id: number;
  label: string;
  fullName: string;
  phone: string;
  line1: string;
  line2: string | null;
  city: string;
  state: string;
  pincode: string;
  isDefault: boolean;
};

export type OrderSummary = {
  id: number;
  orderNumber: string;
  status: string;
  total: string;
  createdAt: string;
  itemCount: number;
  firstImage: string | null;
};

export type ReviewItem = {
  id: number;
  rating: number;
  title: string | null;
  body: string | null;
  photoUrl: string | null;
  createdAt: string;
  userName: string;
  canEdit?: boolean;
};
