import { db } from "@/db";
import { emailOtps } from "@/db/schema";
import { and, eq, isNull, gt } from "drizzle-orm";
import { hashSecret, verifySecret } from "./password";

const OTP_TTL_MS = 5 * 60 * 1000;
const MAX_ATTEMPTS = 3;

export function generateOtpCode(): string {
  return String(Math.floor(100000 + Math.random() * 900000));
}

export async function issueOtp(identifier: string, purpose: string) {
  const code = generateOtpCode();
  const codeHash = await hashSecret(code);
  const expiresAt = new Date(Date.now() + OTP_TTL_MS);
  await db.insert(emailOtps).values({ identifier, purpose, codeHash, expiresAt });
  // In a production system this would be sent via SMTP / SMS gateway.
  // Since no SMTP credentials are configured in this sandbox, we log it
  // server-side and return it in the API response so the flow is testable.
  console.log(`[OTP] ${purpose} code for ${identifier}: ${code}`);
  return code;
}

export async function verifyOtp(identifier: string, purpose: string, code: string) {
  const [record] = await db
    .select()
    .from(emailOtps)
    .where(
      and(
        eq(emailOtps.identifier, identifier),
        eq(emailOtps.purpose, purpose),
        isNull(emailOtps.consumedAt),
        gt(emailOtps.expiresAt, new Date())
      )
    )
    .orderBy(emailOtps.id)
    .limit(1);

  if (!record) return { ok: false, reason: "expired" as const };
  if (record.attempts >= MAX_ATTEMPTS) return { ok: false, reason: "locked" as const };

  const match = await verifySecret(code, record.codeHash);
  if (!match) {
    await db
      .update(emailOtps)
      .set({ attempts: record.attempts + 1 })
      .where(eq(emailOtps.id, record.id));
    return { ok: false, reason: "invalid" as const };
  }

  await db
    .update(emailOtps)
    .set({ consumedAt: new Date() })
    .where(eq(emailOtps.id, record.id));
  return { ok: true as const };
}
