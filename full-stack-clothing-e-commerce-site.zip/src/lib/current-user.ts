import { db } from "@/db";
import { admins, users } from "@/db/schema";
import { eq } from "drizzle-orm";
import { getAdminIdFromSession, getUserIdFromSession } from "./auth";

export async function getCurrentUser() {
  const userId = await getUserIdFromSession();
  if (!userId) return null;
  const [user] = await db.select().from(users).where(eq(users.id, userId)).limit(1);
  return user ?? null;
}

export async function getCurrentAdmin() {
  const adminId = await getAdminIdFromSession();
  if (!adminId) return null;
  const [admin] = await db.select().from(admins).where(eq(admins.id, adminId)).limit(1);
  return admin ?? null;
}
