"use client";

import { useEffect, useState } from "react";

export type MeResponse = {
  id: number;
  name: string | null;
  email: string | null;
  phone: string | null;
  photoUrl: string | null;
  gender: string | null;
} | null;

export function useCurrentUser() {
  const [user, setUser] = useState<MeResponse>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let active = true;
    fetch("/api/me")
      .then((r) => (r.ok ? r.json() : null))
      .then((data) => {
        if (active) setUser(data?.user ?? null);
      })
      .finally(() => {
        if (active) setLoading(false);
      });
    return () => {
      active = false;
    };
  }, []);

  return { user, loading, setUser };
}
