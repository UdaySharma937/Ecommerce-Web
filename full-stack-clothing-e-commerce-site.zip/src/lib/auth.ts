import { SignJWT, jwtVerify } from "jose";
import { cookies } from "next/headers";

const USER_COOKIE = "vh_session";
const ADMIN_COOKIE = "vh_admin_session";

function getSecret(name: "user" | "admin") {
  const raw =
    name === "user"
      ? process.env.SESSION_SECRET
      : process.env.ADMIN_SESSION_SECRET;
  if (!raw) throw new Error(`Missing secret for ${name} session`);
  return new TextEncoder().encode(raw);
}

export async function createUserSession(userId: number) {
  const token = await new SignJWT({ userId })
    .setProtectedHeader({ alg: "HS256" })
    .setIssuedAt()
    .setExpirationTime("30d")
    .sign(getSecret("user"));
  const store = await cookies();
  store.set(USER_COOKIE, token, {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "lax",
    path: "/",
    maxAge: 60 * 60 * 24 * 30,
  });
}

export async function clearUserSession() {
  const store = await cookies();
  store.delete(USER_COOKIE);
}

export async function getUserIdFromSession(): Promise<number | null> {
  const store = await cookies();
  const token = store.get(USER_COOKIE)?.value;
  if (!token) return null;
  try {
    const { payload } = await jwtVerify(token, getSecret("user"));
    return typeof payload.userId === "number" ? payload.userId : null;
  } catch {
    return null;
  }
}

export async function createAdminSession(adminId: number) {
  const token = await new SignJWT({ adminId })
    .setProtectedHeader({ alg: "HS256" })
    .setIssuedAt()
    .setExpirationTime("7d")
    .sign(getSecret("admin"));
  const store = await cookies();
  store.set(ADMIN_COOKIE, token, {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "lax",
    path: "/",
    maxAge: 60 * 60 * 24 * 7,
  });
}

export async function clearAdminSession() {
  const store = await cookies();
  store.delete(ADMIN_COOKIE);
}

export async function getAdminIdFromSession(): Promise<number | null> {
  const store = await cookies();
  const token = store.get(ADMIN_COOKIE)?.value;
  if (!token) return null;
  try {
    const { payload } = await jwtVerify(token, getSecret("admin"));
    return typeof payload.adminId === "number" ? payload.adminId : null;
  } catch {
    return null;
  }
}
