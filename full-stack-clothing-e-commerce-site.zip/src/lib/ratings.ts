import { db } from "@/db";
import { products, reviews } from "@/db/schema";
import { eq, sql } from "drizzle-orm";

export async function recomputeRating(productId: number) {
  const agg = await db.execute(sql`
    SELECT COALESCE(AVG(rating), 0)::numeric(3,2) as avg, COUNT(*)::int as count
    FROM reviews WHERE product_id = ${productId} AND is_hidden = false
  `);
  const row = agg.rows[0] as { avg: string; count: number };
  await db
    .update(products)
    .set({ ratingAvg: row.avg, ratingCount: row.count })
    .where(eq(products.id, productId));
}
