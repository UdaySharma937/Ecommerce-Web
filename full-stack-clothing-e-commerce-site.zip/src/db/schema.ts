import {
  pgTable,
  serial,
  text,
  varchar,
  integer,
  numeric,
  boolean,
  timestamp,
  jsonb,
  uniqueIndex,
  index,
} from "drizzle-orm/pg-core";

// ============================= USERS =============================
export const users = pgTable(
  "users",
  {
    id: serial("id").primaryKey(),
    name: varchar("name", { length: 120 }),
    email: varchar("email", { length: 160 }),
    phone: varchar("phone", { length: 20 }),
    passwordHash: varchar("password_hash", { length: 200 }),
    photoUrl: text("photo_url"),
    gender: varchar("gender", { length: 20 }),
    authProvider: varchar("auth_provider", { length: 20 }).notNull().default("email"),
    emailVerified: boolean("email_verified").notNull().default(false),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (t) => ({
    emailIdx: uniqueIndex("users_email_idx").on(t.email),
    phoneIdx: uniqueIndex("users_phone_idx").on(t.phone),
  })
);

// ============================= ADMINS =============================
export const admins = pgTable("admins", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 120 }).notNull(),
  email: varchar("email", { length: 160 }).notNull().unique(),
  passwordHash: varchar("password_hash", { length: 200 }).notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

// ============================= OTPS =============================
export const emailOtps = pgTable(
  "email_otps",
  {
    id: serial("id").primaryKey(),
    identifier: varchar("identifier", { length: 160 }).notNull(),
    purpose: varchar("purpose", { length: 30 }).notNull().default("login"),
    codeHash: varchar("code_hash", { length: 200 }).notNull(),
    attempts: integer("attempts").notNull().default(0),
    expiresAt: timestamp("expires_at").notNull(),
    consumedAt: timestamp("consumed_at"),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (t) => ({
    idIdx: index("email_otps_identifier_idx").on(t.identifier),
  })
);

// ============================= ADDRESSES =============================
export const addresses = pgTable(
  "addresses",
  {
    id: serial("id").primaryKey(),
    userId: integer("user_id").notNull(),
    label: varchar("label", { length: 20 }).notNull().default("Home"),
    fullName: varchar("full_name", { length: 120 }).notNull(),
    phone: varchar("phone", { length: 20 }).notNull(),
    line1: varchar("line1", { length: 200 }).notNull(),
    line2: varchar("line2", { length: 200 }),
    city: varchar("city", { length: 80 }).notNull(),
    state: varchar("state", { length: 80 }).notNull(),
    pincode: varchar("pincode", { length: 10 }).notNull(),
    isDefault: boolean("is_default").notNull().default(false),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (t) => ({
    userIdx: index("addresses_user_idx").on(t.userId),
  })
);

// ============================= CATEGORIES =============================
export const categories = pgTable("categories", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 80 }).notNull(),
  slug: varchar("slug", { length: 80 }).notNull().unique(),
  image: text("image"),
  icon: varchar("icon", { length: 10 }),
  position: integer("position").notNull().default(0),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

// ============================= PRODUCTS =============================
export const products = pgTable(
  "products",
  {
    id: serial("id").primaryKey(),
    name: varchar("name", { length: 200 }).notNull(),
    slug: varchar("slug", { length: 220 }).notNull().unique(),
    categoryId: integer("category_id").notNull(),
    brand: varchar("brand", { length: 80 }).notNull().default("Vastrahaus"),
    description: text("description").notNull().default(""),
    price: numeric("price", { precision: 10, scale: 2 }).notNull(),
    mrp: numeric("mrp", { precision: 10, scale: 2 }).notNull(),
    ratingAvg: numeric("rating_avg", { precision: 3, scale: 2 }).notNull().default("0"),
    ratingCount: integer("rating_count").notNull().default(0),
    soldCount: integer("sold_count").notNull().default(0),
    tags: text("tags").notNull().default(""),
    isFeatured: boolean("is_featured").notNull().default(false),
    isTrending: boolean("is_trending").notNull().default(false),
    isActive: boolean("is_active").notNull().default(true),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (t) => ({
    catIdx: index("products_category_idx").on(t.categoryId),
  })
);

export const productImages = pgTable(
  "product_images",
  {
    id: serial("id").primaryKey(),
    productId: integer("product_id").notNull(),
    url: text("url").notNull(),
    position: integer("position").notNull().default(0),
  },
  (t) => ({
    prodIdx: index("product_images_product_idx").on(t.productId),
  })
);

export const productVariants = pgTable(
  "product_variants",
  {
    id: serial("id").primaryKey(),
    productId: integer("product_id").notNull(),
    size: varchar("size", { length: 20 }).notNull(),
    color: varchar("color", { length: 40 }).notNull(),
    colorHex: varchar("color_hex", { length: 10 }).notNull().default("#999999"),
    stock: integer("stock").notNull().default(0),
    sku: varchar("sku", { length: 60 }).notNull(),
  },
  (t) => ({
    prodIdx: index("product_variants_product_idx").on(t.productId),
  })
);

// ============================= CART / WISHLIST =============================
export const cartItems = pgTable(
  "cart_items",
  {
    id: serial("id").primaryKey(),
    userId: integer("user_id").notNull(),
    productId: integer("product_id").notNull(),
    variantId: integer("variant_id").notNull(),
    quantity: integer("quantity").notNull().default(1),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (t) => ({
    userIdx: index("cart_items_user_idx").on(t.userId),
    uq: uniqueIndex("cart_items_user_variant_idx").on(t.userId, t.variantId),
  })
);

export const wishlistItems = pgTable(
  "wishlist_items",
  {
    id: serial("id").primaryKey(),
    userId: integer("user_id").notNull(),
    productId: integer("product_id").notNull(),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (t) => ({
    uq: uniqueIndex("wishlist_user_product_idx").on(t.userId, t.productId),
  })
);

// ============================= ORDERS =============================
export const orders = pgTable(
  "orders",
  {
    id: serial("id").primaryKey(),
    orderNumber: varchar("order_number", { length: 30 }).notNull().unique(),
    userId: integer("user_id").notNull(),
    status: varchar("status", { length: 30 }).notNull().default("Placed"),
    paymentMethod: varchar("payment_method", { length: 20 }).notNull().default("COD"),
    paymentStatus: varchar("payment_status", { length: 20 }).notNull().default("Pending"),
    subtotal: numeric("subtotal", { precision: 10, scale: 2 }).notNull(),
    discount: numeric("discount", { precision: 10, scale: 2 }).notNull().default("0"),
    deliveryFee: numeric("delivery_fee", { precision: 10, scale: 2 }).notNull().default("0"),
    total: numeric("total", { precision: 10, scale: 2 }).notNull(),
    couponCode: varchar("coupon_code", { length: 40 }),
    address: jsonb("address").notNull(),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (t) => ({
    userIdx: index("orders_user_idx").on(t.userId),
  })
);

export const orderItems = pgTable(
  "order_items",
  {
    id: serial("id").primaryKey(),
    orderId: integer("order_id").notNull(),
    productId: integer("product_id").notNull(),
    name: varchar("name", { length: 200 }).notNull(),
    image: text("image"),
    price: numeric("price", { precision: 10, scale: 2 }).notNull(),
    quantity: integer("quantity").notNull(),
    size: varchar("size", { length: 20 }),
    color: varchar("color", { length: 40 }),
  },
  (t) => ({
    orderIdx: index("order_items_order_idx").on(t.orderId),
  })
);

export const orderStatusHistory = pgTable(
  "order_status_history",
  {
    id: serial("id").primaryKey(),
    orderId: integer("order_id").notNull(),
    status: varchar("status", { length: 30 }).notNull(),
    note: text("note"),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (t) => ({
    orderIdx: index("order_status_history_order_idx").on(t.orderId),
  })
);

// ============================= REVIEWS =============================
export const reviews = pgTable(
  "reviews",
  {
    id: serial("id").primaryKey(),
    productId: integer("product_id").notNull(),
    userId: integer("user_id").notNull(),
    orderId: integer("order_id"),
    rating: integer("rating").notNull(),
    title: varchar("title", { length: 150 }),
    body: text("body"),
    photoUrl: text("photo_url"),
    isHidden: boolean("is_hidden").notNull().default(false),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (t) => ({
    prodIdx: index("reviews_product_idx").on(t.productId),
    uq: uniqueIndex("reviews_user_product_idx").on(t.userId, t.productId),
  })
);

// ============================= COUPONS =============================
export const coupons = pgTable("coupons", {
  id: serial("id").primaryKey(),
  code: varchar("code", { length: 40 }).notNull().unique(),
  type: varchar("type", { length: 10 }).notNull().default("percent"), // percent | flat
  value: numeric("value", { precision: 10, scale: 2 }).notNull(),
  minOrderValue: numeric("min_order_value", { precision: 10, scale: 2 }).notNull().default("0"),
  maxDiscount: numeric("max_discount", { precision: 10, scale: 2 }),
  expiresAt: timestamp("expires_at"),
  usageLimit: integer("usage_limit").notNull().default(1000),
  usedCount: integer("used_count").notNull().default(0),
  isActive: boolean("is_active").notNull().default(true),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

// ============================= BANNERS =============================
export const banners = pgTable("banners", {
  id: serial("id").primaryKey(),
  title: varchar("title", { length: 150 }).notNull(),
  subtitle: varchar("subtitle", { length: 200 }),
  image: text("image").notNull(),
  link: varchar("link", { length: 200 }),
  position: integer("position").notNull().default(0),
  isActive: boolean("is_active").notNull().default(true),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});
