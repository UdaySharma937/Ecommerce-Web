"use client";

import Link from "next/link";
import { useState } from "react";
import { discountPct, formatINR } from "@/lib/format";
import { StarRating } from "./star-rating";
import { useToast } from "./toast";

export type ProductCardData = {
  id: number;
  name: string;
  slug: string;
  brand?: string;
  price: string;
  mrp: string;
  ratingAvg: string;
  ratingCount: number;
  image: string | null;
};

export function ProductCard({
  product,
  wishlisted,
  onToggleWishlist,
}: {
  product: ProductCardData;
  wishlisted?: boolean;
  onToggleWishlist?: (id: number, next: boolean) => void;
}) {
  const [busy, setBusy] = useState(false);
  const [liked, setLiked] = useState(!!wishlisted);
  const { show } = useToast();
  const pct = discountPct(product.price, product.mrp);

  async function toggleWishlist(e: React.MouseEvent) {
    e.preventDefault();
    e.stopPropagation();
    if (busy) return;
    setBusy(true);
    try {
      const res = await fetch("/api/wishlist", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ productId: product.id }),
      });
      if (res.status === 401) {
        show("Please log in to save items to your wishlist.", "error");
        return;
      }
      const data = await res.json();
      setLiked(data.wishlisted);
      onToggleWishlist?.(product.id, data.wishlisted);
      show(data.wishlisted ? "Added to wishlist" : "Removed from wishlist", "success");
    } catch {
      show("Something went wrong. Please try again.", "error");
    } finally {
      setBusy(false);
    }
  }

  return (
    <Link
      href={`/products/${product.slug}`}
      className="card group flex flex-col overflow-hidden transition-shadow hover:shadow-md"
    >
      <div className="relative aspect-[3/4] overflow-hidden" style={{ background: "var(--color-accent-soft)" }}>
        {product.image ? (
          // eslint-disable-next-line @next/next/no-img-element
          <img
            src={product.image}
            alt={product.name}
            className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-105"
            loading="lazy"
          />
        ) : (
          <div className="h-full w-full flex items-center justify-center text-sm">No image</div>
        )}
        <button
          onClick={toggleWishlist}
          aria-label={liked ? "Remove from wishlist" : "Add to wishlist"}
          aria-pressed={liked}
          className="absolute top-2 right-2 h-8 w-8 rounded-full flex items-center justify-center shadow-sm"
          style={{ background: "var(--color-surface)" }}
        >
          <svg
            width="16"
            height="16"
            viewBox="0 0 24 24"
            fill={liked ? "var(--color-accent)" : "none"}
            stroke={liked ? "var(--color-accent)" : "currentColor"}
            strokeWidth="2"
          >
            <path d="M12 21s-7.5-4.6-10-9.3C.5 8.2 2.3 5 5.6 5c2 0 3.4 1 4.4 2.4C11 6 12.4 5 14.4 5c3.3 0 5.1 3.2 3.6 6.7C19.5 16.4 12 21 12 21z" />
          </svg>
        </button>
        {pct > 0 && (
          <span className="badge badge-accent absolute left-2 top-2">{pct}% OFF</span>
        )}
      </div>
      <div className="flex flex-1 flex-col gap-1 p-3">
        {product.brand && (
          <span className="text-[11px] font-bold uppercase tracking-wide" style={{ color: "var(--color-ink-soft)" }}>
            {product.brand}
          </span>
        )}
        <h3 className="text-sm font-medium leading-snug line-clamp-2">{product.name}</h3>
        <div className="flex items-baseline gap-2 mt-0.5">
          <span className="font-bold">{formatINR(product.price)}</span>
          {pct > 0 && (
            <span className="text-xs line-through" style={{ color: "var(--color-ink-soft)" }}>
              {formatINR(product.mrp)}
            </span>
          )}
        </div>
        {Number(product.ratingCount) > 0 ? (
          <div className="flex items-center gap-1 mt-0.5">
            <StarRating value={parseFloat(product.ratingAvg)} size={12} />
            <span className="text-[11px]" style={{ color: "var(--color-ink-soft)" }}>
              ({product.ratingCount})
            </span>
          </div>
        ) : (
          <span className="text-[11px]" style={{ color: "var(--color-ink-soft)" }}>
            No ratings yet
          </span>
        )}
      </div>
    </Link>
  );
}
