"use client";

import { useRef, useState } from "react";

export function AdminImageUploader({ images, onChange }: { images: string[]; onChange: (urls: string[]) => void }) {
  const [uploading, setUploading] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  async function handleFiles(files: FileList | null) {
    if (!files || !files.length) return;
    setUploading(true);
    try {
      const uploaded: string[] = [];
      for (const file of Array.from(files)) {
        const formData = new FormData();
        formData.append("file", file);
        const res = await fetch("/api/admin/upload", { method: "POST", body: formData });
        if (res.ok) {
          const d = await res.json();
          uploaded.push(d.url);
        }
      }
      onChange([...images, ...uploaded]);
    } finally {
      setUploading(false);
      if (inputRef.current) inputRef.current.value = "";
    }
  }

  return (
    <div>
      <div className="flex flex-wrap gap-3 mb-3">
        {images.map((url, i) => (
          <div key={url + i} className="relative h-24 w-20">
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img src={url} alt="" className="h-full w-full object-cover rounded-lg" />
            <button
              type="button"
              onClick={() => onChange(images.filter((_, idx) => idx !== i))}
              className="absolute -top-2 -right-2 h-5 w-5 rounded-full text-xs flex items-center justify-center"
              style={{ background: "var(--color-danger)", color: "#fff" }}
              aria-label="Remove image"
            >
              ✕
            </button>
          </div>
        ))}
      </div>
      <input ref={inputRef} type="file" accept="image/*" multiple onChange={(e) => handleFiles(e.target.files)} className="text-sm" />
      {uploading && <p className="text-xs mt-1" style={{ color: "var(--color-ink-soft)" }}>Uploading...</p>}
    </div>
  );
}
