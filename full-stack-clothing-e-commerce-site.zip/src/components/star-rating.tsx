export function StarRating({ value, size = 14 }: { value: number; size?: number }) {
  const rounded = Math.round(value * 2) / 2;
  return (
    <span className="inline-flex items-center" aria-label={`${value.toFixed(1)} out of 5 stars`}>
      {[1, 2, 3, 4, 5].map((n) => {
        const fill = rounded >= n ? 1 : rounded >= n - 0.5 ? 0.5 : 0;
        return (
          <svg key={n} width={size} height={size} viewBox="0 0 24 24" aria-hidden="true">
            <defs>
              <linearGradient id={`star-grad-${n}-${value}`}>
                <stop offset={`${fill * 100}%`} stopColor="var(--color-gold)" />
                <stop offset={`${fill * 100}%`} stopColor="var(--color-border)" />
              </linearGradient>
            </defs>
            <path
              fill={`url(#star-grad-${n}-${value})`}
              d="M12 2l2.9 6.3 6.9.8-5.1 4.8 1.4 6.9-6.1-3.5-6.1 3.5 1.4-6.9-5.1-4.8 6.9-.8z"
            />
          </svg>
        );
      })}
    </span>
  );
}
