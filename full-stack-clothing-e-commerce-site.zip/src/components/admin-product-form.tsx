"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { AdminImageUploader } from "./admin-image-uploader";

type Category = { id: number; name: string };
type Variant = { size: string; color: string; colorHex: string; stock: number };

export type ProductFormData = {
  name: string;
  categoryId: number | "";
  brand: string;
  description: string;
  price: string;
  mrp: string;
  tags: string;
  isFeatured: boolean;
  isTrending: boolean;
  isActive: boolean;
  images: string[];
  variants: Variant[];
};

const EMPTY: ProductFormData = {
  name: "",
  categoryId: "",
  brand: "Vastrahaus",
  description: "",
  price: "",
  mrp: "",
  tags: "",
  isFeatured: false,
  isTrending: false,
  isActive: true,
  images: [],
  variants: [{ size: "M", color: "Black", colorHex: "#1c1c1c", stock: 10 }],
};

export function AdminProductForm({
  initial,
  submitLabel,
  onSubmit,
}: {
  initial?: Partial<ProductFormData>;
  submitLabel: string;
  onSubmit: (data: ProductFormData) => Promise<void>;
}) {
  const [form, setForm] = useState<ProductFormData>({ ...EMPTY, ...initial });
  const [categories, setCategories] = useState<Category[]>([]);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const router = useRouter();

  useEffect(() => {
    fetch("/api/admin/categories").then((r) => r.json()).then((d) => setCategories(d.items || []));
  }, []);

  function updateVariant(i: number, patch: Partial<Variant>) {
    setForm((f) => ({ ...f, variants: f.variants.map((v, idx) => (idx === i ? { ...v, ...patch } : v)) }));
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError("");
    if (!form.name || !form.categoryId || !form.price || !form.mrp || form.images.length === 0) {
      setError("Please fill name, category, price, MRP and add at least one image.");
      return;
    }
    setBusy(true);
    try {
      await onSubmit(form);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Something went wrong.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <form onSubmit={handleSubmit} className="flex flex-col gap-5 max-w-3xl">
      {error && <p className="text-sm p-3 rounded-lg" style={{ background: "var(--color-danger-soft)", color: "var(--color-danger)" }}>{error}</p>}

      <div className="card p-5">
        <h2 className="font-semibold mb-3 text-sm">Basic details</h2>
        <div className="grid sm:grid-cols-2 gap-3">
          <div className="sm:col-span-2">
            <label className="label">Product name</label>
            <input className="input" value={form.name} onChange={(e) => setForm((f) => ({ ...f, name: e.target.value }))} />
          </div>
          <div>
            <label className="label">Category</label>
            <select className="input" value={form.categoryId} onChange={(e) => setForm((f) => ({ ...f, categoryId: Number(e.target.value) }))}>
              <option value="">Select category</option>
              {categories.map((c) => (
                <option key={c.id} value={c.id}>{c.name}</option>
              ))}
            </select>
          </div>
          <div>
            <label className="label">Brand</label>
            <input className="input" value={form.brand} onChange={(e) => setForm((f) => ({ ...f, brand: e.target.value }))} />
          </div>
          <div>
            <label className="label">Price (₹)</label>
            <input type="number" className="input" value={form.price} onChange={(e) => setForm((f) => ({ ...f, price: e.target.value }))} />
          </div>
          <div>
            <label className="label">MRP (₹)</label>
            <input type="number" className="input" value={form.mrp} onChange={(e) => setForm((f) => ({ ...f, mrp: e.target.value }))} />
          </div>
          <div className="sm:col-span-2">
            <label className="label">Tags (comma separated, used for search)</label>
            <input className="input" value={form.tags} onChange={(e) => setForm((f) => ({ ...f, tags: e.target.value }))} />
          </div>
          <div className="sm:col-span-2">
            <label className="label">Description</label>
            <textarea className="input" rows={4} value={form.description} onChange={(e) => setForm((f) => ({ ...f, description: e.target.value }))} />
          </div>
        </div>
        <div className="flex gap-5 mt-3">
          <label className="flex items-center gap-2 text-sm"><input type="checkbox" checked={form.isFeatured} onChange={(e) => setForm((f) => ({ ...f, isFeatured: e.target.checked }))} /> Featured</label>
          <label className="flex items-center gap-2 text-sm"><input type="checkbox" checked={form.isTrending} onChange={(e) => setForm((f) => ({ ...f, isTrending: e.target.checked }))} /> Trending</label>
          <label className="flex items-center gap-2 text-sm"><input type="checkbox" checked={form.isActive} onChange={(e) => setForm((f) => ({ ...f, isActive: e.target.checked }))} /> Active (visible to customers)</label>
        </div>
      </div>

      <div className="card p-5">
        <h2 className="font-semibold mb-3 text-sm">Images</h2>
        <AdminImageUploader images={form.images} onChange={(images) => setForm((f) => ({ ...f, images }))} />
      </div>

      <div className="card p-5">
        <h2 className="font-semibold mb-3 text-sm">Sizes, colors &amp; stock</h2>
        <div className="flex flex-col gap-2">
          {form.variants.map((v, i) => (
            <div key={i} className="grid grid-cols-[1fr_1fr_80px_80px_32px] gap-2 items-center">
              <input className="input" placeholder="Size (S/M/L..)" value={v.size} onChange={(e) => updateVariant(i, { size: e.target.value })} />
              <input className="input" placeholder="Color name" value={v.color} onChange={(e) => updateVariant(i, { color: e.target.value })} />
              <input className="input" type="color" value={v.colorHex} onChange={(e) => updateVariant(i, { colorHex: e.target.value })} />
              <input className="input" type="number" placeholder="Stock" value={v.stock} onChange={(e) => updateVariant(i, { stock: Number(e.target.value) })} />
              <button type="button" className="btn btn-ghost btn-sm" onClick={() => setForm((f) => ({ ...f, variants: f.variants.filter((_, idx) => idx !== i) }))}>✕</button>
            </div>
          ))}
        </div>
        <button
          type="button"
          className="btn btn-outline btn-sm mt-3"
          onClick={() => setForm((f) => ({ ...f, variants: [...f.variants, { size: "M", color: "Black", colorHex: "#1c1c1c", stock: 10 }] }))}
        >
          + Add variant
        </button>
      </div>

      <div className="flex gap-3">
        <button className="btn btn-primary" disabled={busy}>{busy ? "Saving..." : submitLabel}</button>
        <button type="button" className="btn btn-outline" onClick={() => router.push("/admin/products")}>Cancel</button>
      </div>
    </form>
  );
}
