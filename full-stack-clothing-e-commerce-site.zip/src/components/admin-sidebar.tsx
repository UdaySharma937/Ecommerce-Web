"use client";

import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";

const LINKS = [
  { href: "/admin", label: "Dashboard", icon: "📊" },
  { href: "/admin/products", label: "Products", icon: "👕" },
  { href: "/admin/categories", label: "Categories", icon: "🗂️" },
  { href: "/admin/orders", label: "Orders", icon: "📦" },
  { href: "/admin/customers", label: "Customers", icon: "👥" },
  { href: "/admin/reviews", label: "Reviews", icon: "⭐" },
  { href: "/admin/coupons", label: "Coupons", icon: "🏷️" },
  { href: "/admin/banners", label: "Banners", icon: "🖼️" },
];

export function AdminSidebar({ adminName }: { adminName: string }) {
  const pathname = usePathname();
  const router = useRouter();

  async function logout() {
    await fetch("/api/admin/logout", { method: "POST" });
    router.push("/admin/login");
    router.refresh();
  }

  return (
    <aside
      className="w-56 shrink-0 h-screen sticky top-0 flex flex-col"
      style={{ background: "var(--color-ink)", color: "var(--color-bg)" }}
    >
      <div className="p-5" style={{ borderBottom: "1px solid #3a332c" }}>
        <div style={{ fontFamily: "var(--font-display)", color: "var(--color-accent-dark)" }} className="text-lg font-bold">
          Vastrahaus
        </div>
        <div className="text-xs" style={{ color: "#a89b8e" }}>Admin Console</div>
      </div>
      <nav className="flex-1 overflow-y-auto py-3">
        {LINKS.map((link) => {
          const active = link.href === "/admin" ? pathname === "/admin" : pathname.startsWith(link.href);
          return (
            <Link
              key={link.href}
              href={link.href}
              className="flex items-center gap-3 px-5 py-2.5 text-sm font-medium"
              style={{
                background: active ? "rgba(193,81,45,0.18)" : "transparent",
                color: active ? "var(--color-accent-dark)" : "#d8cfc4",
                borderRight: active ? "3px solid var(--color-accent)" : "3px solid transparent",
              }}
            >
              <span>{link.icon}</span>
              {link.label}
            </Link>
          );
        })}
      </nav>
      <div className="p-4" style={{ borderTop: "1px solid #3a332c" }}>
        <div className="text-xs mb-2" style={{ color: "#a89b8e" }}>{adminName}</div>
        <button className="btn btn-outline btn-sm btn-block" style={{ color: "var(--color-bg)", borderColor: "#5a5048" }} onClick={logout}>
          Log out
        </button>
      </div>
    </aside>
  );
}
