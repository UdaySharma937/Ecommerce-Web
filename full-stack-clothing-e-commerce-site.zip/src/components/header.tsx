"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useEffect, useRef, useState } from "react";
import { useCurrentUser } from "@/lib/use-current-user";

export function Header() {
  const [query, setQuery] = useState("");
  const [suggestions, setSuggestions] = useState<{ name: string; slug: string }[]>([]);
  const [showSuggest, setShowSuggest] = useState(false);
  const [cartCount, setCartCount] = useState(0);
  const router = useRouter();
  const boxRef = useRef<HTMLDivElement>(null);
  const { user } = useCurrentUser();

  useEffect(() => {
    function refreshCount() {
      fetch("/api/cart")
        .then((r) => (r.ok ? r.json() : { items: [] }))
        .then((d) => setCartCount((d.items || []).reduce((s: number, i: { quantity: number }) => s + i.quantity, 0)))
        .catch(() => {});
    }
    refreshCount();
    window.addEventListener("cart:updated", refreshCount);
    return () => window.removeEventListener("cart:updated", refreshCount);
  }, []);

  useEffect(() => {
    function onClick(e: MouseEvent) {
      if (boxRef.current && !boxRef.current.contains(e.target as Node)) {
        setShowSuggest(false);
      }
    }
    document.addEventListener("click", onClick);
    return () => document.removeEventListener("click", onClick);
  }, []);

  useEffect(() => {
    if (query.trim().length < 2) {
      setSuggestions([]);
      return;
    }
    const t = setTimeout(() => {
      fetch(`/api/products?search=${encodeURIComponent(query)}&limit=5`)
        .then((r) => r.json())
        .then((d) =>
          setSuggestions((d.items || []).map((p: { name: string; slug: string }) => ({ name: p.name, slug: p.slug })))
        )
        .catch(() => {});
    }, 220);
    return () => clearTimeout(t);
  }, [query]);

  function submitSearch(e: React.FormEvent) {
    e.preventDefault();
    setShowSuggest(false);
    router.push(`/products?search=${encodeURIComponent(query)}`);
  }

  return (
    <header
      style={{ borderBottom: "1px solid var(--color-border)", background: "var(--color-surface)" }}
      className="sticky top-0 z-40"
    >
      <div className="container-page flex items-center gap-4 py-3">
        <Link href="/" className="shrink-0 flex items-baseline gap-1" aria-label="Vastrahaus home">
          <span style={{ fontFamily: "var(--font-display)", fontSize: "1.5rem", fontWeight: 700, color: "var(--color-accent)" }}>
            Vastrahaus
          </span>
        </Link>

        <div ref={boxRef} className="relative flex-1 hidden sm:block">
          <form onSubmit={submitSearch} role="search">
            <input
              className="input"
              placeholder="Search for kurtas, sarees, jackets and more"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              onFocus={() => setShowSuggest(true)}
              aria-label="Search products"
            />
          </form>
          {showSuggest && suggestions.length > 0 && (
            <div
              className="card absolute left-0 right-0 mt-1 overflow-hidden"
              style={{ zIndex: 50 }}
            >
              {suggestions.map((s) => (
                <Link
                  key={s.slug}
                  href={`/products/${s.slug}`}
                  className="block px-4 py-2 text-sm hover:bg-[var(--color-accent-soft)]"
                  onClick={() => setShowSuggest(false)}
                >
                  {s.name}
                </Link>
              ))}
            </div>
          )}
        </div>

        <nav className="flex items-center gap-3 ml-auto">
          <Link href="/wishlist" className="hidden sm:flex items-center gap-1 text-sm font-semibold hover:text-[var(--color-accent)]" aria-label="Wishlist">
            <HeartIcon /> <span className="hidden md:inline">Wishlist</span>
          </Link>
          <Link href={user ? "/profile" : "/login"} className="hidden sm:flex items-center gap-1 text-sm font-semibold hover:text-[var(--color-accent)]">
            <UserIcon /> <span className="hidden md:inline">{user ? user.name?.split(" ")[0] || "Account" : "Login"}</span>
          </Link>
          <Link href="/cart" className="relative flex items-center gap-1 text-sm font-semibold hover:text-[var(--color-accent)]" aria-label="Cart">
            <CartIcon />
            <span className="hidden md:inline">Cart</span>
            {cartCount > 0 && (
              <span
                className="absolute -top-2 -right-3 text-[10px] font-bold text-white rounded-full flex items-center justify-center"
                style={{ background: "var(--color-accent)", width: 18, height: 18 }}
              >
                {cartCount > 9 ? "9+" : cartCount}
              </span>
            )}
          </Link>
        </nav>
      </div>
      <div className="sm:hidden border-t" style={{ borderColor: "var(--color-border)" }}>
        <form onSubmit={submitSearch} className="container-page py-2" role="search">
          <input
            className="input"
            placeholder="Search Vastrahaus"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            aria-label="Search products"
          />
        </form>
      </div>
    </header>
  );
}

function HeartIcon() {
  return (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
      <path d="M12 21s-7.5-4.6-10-9.3C.5 8.2 2.3 5 5.6 5c2 0 3.4 1 4.4 2.4C11 6 12.4 5 14.4 5c3.3 0 5.1 3.2 3.6 6.7C19.5 16.4 12 21 12 21z" />
    </svg>
  );
}
function UserIcon() {
  return (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
      <circle cx="12" cy="8" r="4" />
      <path d="M4 20c1.5-4 5-6 8-6s6.5 2 8 6" />
    </svg>
  );
}
function CartIcon() {
  return (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
      <circle cx="9" cy="21" r="1" />
      <circle cx="19" cy="21" r="1" />
      <path d="M1 1h4l2.7 13.4a2 2 0 002 1.6h9.2a2 2 0 002-1.6L23 6H6" />
    </svg>
  );
}
