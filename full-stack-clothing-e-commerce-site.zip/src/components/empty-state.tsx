import Link from "next/link";
import type { ReactNode } from "react";

export function EmptyState({
  icon,
  title,
  message,
  ctaHref,
  ctaLabel,
}: {
  icon?: ReactNode;
  title: string;
  message: string;
  ctaHref?: string;
  ctaLabel?: string;
}) {
  return (
    <div className="flex flex-col items-center justify-center text-center py-16 px-4">
      <div className="mb-4 text-5xl" aria-hidden="true">
        {icon ?? "🛍️"}
      </div>
      <h2 className="text-lg font-semibold mb-1">{title}</h2>
      <p style={{ color: "var(--color-ink-soft)" }} className="max-w-sm mb-5 text-sm">
        {message}
      </p>
      {ctaHref && ctaLabel && (
        <Link href={ctaHref} className="btn btn-primary">
          {ctaLabel}
        </Link>
      )}
    </div>
  );
}
